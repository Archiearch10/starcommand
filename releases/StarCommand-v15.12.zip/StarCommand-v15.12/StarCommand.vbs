' Starts StarCommand with no console window and opens it in its own window.
' Add the word "background" after the file name to start it without opening the window (used for start-with-Windows).
' Quit it from Settings > Quit StarCommand.
Set fso = CreateObject("Scripting.FileSystemObject")
d = fso.GetParentFolderName(WScript.ScriptFullName)
a = ""
If WScript.Arguments.Count > 0 Then a = " " & WScript.Arguments(0)
CreateObject("WScript.Shell").Run Chr(34) & d & "\start_hidden.bat" & Chr(34) & a, 0, False
