@echo off
cd /d "%~dp0"
echo StarCommand is starting. You can close this window to stop it.
where python >nul 2>nul && (python launcher.py --console) || (py launcher.py --console)
pause
