"""StarCommand tools: everything an agent can use to reach the outside world.
Pure functions: server.py decides who is allowed to call them and asks for approval."""
import json,os,re,time,base64,threading,queue,urllib.request,urllib.parse,urllib.error,html,importlib.util,sys,subprocess

UA="Mozilla/5.0 (StarCommand/8)"
EP={"ddg":"https://html.duckduckgo.com/html/","reddit":"https://www.reddit.com","trends":"https://trends.google.com/trending/rss",
    "etsy":"https://openapi.etsy.com","printify":"https://api.printify.com","pollinations":"https://image.pollinations.ai","openai":"https://api.openai.com","suggest":"https://suggestqueries.google.com"}
try:EP.update(json.loads(os.environ.get("STARCOMMAND_ENDPOINTS","{}")))
except Exception:pass
INSTALL_MSG=("The browser tool is only half installed (the browser itself is missing or out of date). In StarCommand open Settings, "
             "find BROWSER TOOL and press 'Repair browser tool'. It downloads about 150 MB once, then try again.")

class ToolError(Exception):pass

def _get(url,headers=None,data=None,timeout=30,method=None,raw=False,limit=2000000):
    h={"User-Agent":UA};h.update(headers or {})
    req=urllib.request.Request(url,data,h,method=method)
    try:
        with urllib.request.urlopen(req,timeout=timeout) as r:
            b=r.read(limit);return b if raw else b.decode("utf8","ignore")
    except urllib.error.HTTPError as e:
        raise ToolError("HTTP %s from %s: %s"%(e.code,urllib.parse.urlparse(url).netloc,e.read().decode("utf8","ignore")[:300]))
    except Exception as e:raise ToolError("Network error: %s"%e)

def strip_html(t):
    t=re.sub(r"<script.*?</script>|<style.*?</style>|<noscript.*?</noscript>","",t,flags=re.S|re.I)
    t=html.unescape(re.sub(r"<[^>]+>"," ",t));return re.sub(r"\s+"," ",t).strip()

# ---------------------------------------------------------------- research
def http_get(url):
    if not re.match(r"^https?://",str(url)):raise ToolError("URL must start with http:// or https://")
    return strip_html(_get(url,limit=400000))[:4500] or "(page had no readable text)"

def web_search(q,n=8):
    h=_get(EP["ddg"],data=urllib.parse.urlencode({"q":q}).encode(),headers={"Content-Type":"application/x-www-form-urlencoded"})
    res=re.findall(r'<a[^>]*class="result__a"[^>]*href="([^"]+)"[^>]*>(.*?)</a>',h,re.S)
    sn=re.findall(r'class="result__snippet"[^>]*>(.*?)</(?:a|td|div)>',h,re.S)
    out=[]
    for i,(u,t) in enumerate(res[:n]):
        q2=urllib.parse.parse_qs(urllib.parse.urlparse(u).query).get("uddg")
        if q2:u=q2[0]
        elif u.startswith("//"):u="https:"+u
        out.append("%d. %s\n   %s\n   %s"%(i+1,strip_html(t),u,strip_html(sn[i]) if i<len(sn) else ""))
    return "\n".join(out) or ("No results came back (the search engine may be blocking requests). "
                              "Try reddit_top, trends_daily, or http_get on a specific website instead.")

def reddit_top(sub,period="week",limit=12):
    sub=re.sub(r"[^A-Za-z0-9_+]","",str(sub).replace("r/",""))
    if not sub:raise ToolError("Give a subreddit name, e.g. 'etsy' or 'printondemand'.")
    period=period if period in("hour","day","week","month","year","all") else "week"
    d=json.loads(_get("%s/r/%s/top.json?t=%s&limit=%d"%(EP["reddit"],sub,period,max(1,min(25,int(limit)))),headers={"User-Agent":"StarCommand/8 personal research tool"}))
    out=[]
    for c in d.get("data",{}).get("children",[]):
        x=c.get("data",{});out.append("- %s (score %s, %s comments) https://reddit.com%s"%(x.get("title"),x.get("score"),x.get("num_comments"),x.get("permalink","")))
    return "\n".join(out) or "No posts found."

def trends_daily(geo="US"):
    geo=re.sub(r"[^A-Za-z-]","",str(geo))[:6] or "US"
    x=_get("%s?geo=%s"%(EP["trends"],geo))
    out=[]
    for it in re.findall(r"<item>(.*?)</item>",x,re.S)[:25]:
        t=re.search(r"<title>(.*?)</title>",it,re.S);tr=re.search(r"<ht:approx_traffic>(.*?)</ht:approx_traffic>",it,re.S)
        nw=re.search(r"<ht:news_item_title>(.*?)</ht:news_item_title>",it,re.S)
        out.append("- %s%s%s"%(strip_html(t.group(1)) if t else "?"," (%s searches)"%strip_html(tr.group(1)) if tr else "",(" | "+strip_html(nw.group(1))[:90]) if nw else ""))
    return "\n".join(out) or "No trending data returned."

def trends_interest(keywords,geo="US"):
    if importlib.util.find_spec("pytrends") is None:
        raise ToolError("trends_interest needs the optional 'pytrends' package (pip install pytrends). trends_daily works without it.")
    from pytrends.request import TrendReq
    kw=[str(k) for k in (keywords if isinstance(keywords,list) else [keywords])][:5]
    p=TrendReq(hl="en-US",tz=0);p.build_payload(kw,timeframe="today 3-m",geo=geo if geo!="US" else "US")
    df=p.interest_over_time()
    if df is None or df.empty:return "No data for those keywords."
    lines=["%s: average interest %.0f/100, last week %.0f/100"%(k,df[k].mean(),df[k].tail(7).mean()) for k in kw if k in df]
    return "Google Trends, last 3 months:\n"+"\n".join(lines)

def etsy_search(key,kw,limit=10):
    if not key:raise ToolError("No Etsy key saved. Add your Etsy API keystring under API keys (etsy). Free keys: etsy.com/developers.")
    u="%s/v3/application/listings/active?%s"%(EP["etsy"],urllib.parse.urlencode({"keywords":kw,"limit":max(1,min(25,int(limit))),"sort_on":"score"}))
    d=json.loads(_get(u,headers={"x-api-key":key}))
    out=[]
    for r in d.get("results",[]):
        p=r.get("price") or {};price="%.2f %s"%(float(p.get("amount",0))/float(p.get("divisor",100) or 100),p.get("currency_code","")) if p else "?"
        out.append("- %s | %s | %s favorites | %s views | tags: %s | %s"%(r.get("title","")[:90],price,r.get("num_favorers","?"),r.get("views","?"),", ".join((r.get("tags") or [])[:6]),r.get("url","")))
    return "Etsy results for '%s' (%s total):\n%s"%(kw,d.get("count","?"),"\n".join(out)) if out else "No Etsy listings found."

# ---------------------------------------------------------------- printify
def pf(tok,method,path,body=None):
    if not tok:raise ToolError("No Printify token saved. In Printify: Account > Connections > API tokens. Then add it under API keys (printify).")
    data=json.dumps(body).encode() if body is not None else None
    r=_get(EP["printify"]+"/v1"+path,headers={"Authorization":"Bearer "+tok,"Content-Type":"application/json"},data=data,method=method,timeout=60)
    return json.loads(r) if r.strip() else {}

def printify_shops(tok):
    d=pf(tok,"GET","/shops.json")
    return "\n".join("%s | %s | %s"%(s.get("id"),s.get("title"),s.get("sales_channel","")) for s in d) or "No shops connected."

def printify_catalog(tok,q):
    d=pf(tok,"GET","/catalog/blueprints.json");words=str(q).lower().split()
    rows=[b for b in d if all(w in (str(b.get("title",""))+" "+str(b.get("brand",""))+" "+str(b.get("model",""))).lower() for w in words)]
    return "blueprint_id | title | brand\n"+"\n".join("%s | %s | %s"%(b["id"],b.get("title"),b.get("brand","")) for b in rows[:15]) if rows else "No product matched. Try a simpler word such as 'tee' or 'mug'."

def printify_options(tok,bp,pp=None):
    if not pp:
        d=pf(tok,"GET","/catalog/blueprints/%s/print_providers.json"%bp)
        return "Print providers (use print_provider_id):\n"+"\n".join("%s | %s | %s"%(p.get("id"),p.get("title"),(p.get("location") or {}).get("country","")) for p in d[:15])
    d=pf(tok,"GET","/catalog/blueprints/%s/print_providers/%s/variants.json"%(bp,pp));v=d.get("variants",[])
    return "%d variants. First 12:\n"%len(v)+"\n".join("%s | %s"%(x.get("id"),x.get("title")) for x in v[:12])

def printify_shop_id(tok,setting):
    if setting:return str(setting)
    d=pf(tok,"GET","/shops.json")
    if not d:raise ToolError("No Printify shop found. Connect your Etsy shop inside Printify first.")
    return str(d[0]["id"])

def printify_create(tok,shop,a,img):
    for k in("title","description","blueprint_id","print_provider_id","price_usd"):
        if a.get(k) in(None,""):raise ToolError("Missing argument: %s"%k)
    price=float(a["price_usd"])
    if not 1<=price<=500:raise ToolError("price_usd must be between 1 and 500")
    b64=base64.b64encode(open(img,"rb").read()).decode()
    up=pf(tok,"POST","/uploads/images.json",{"file_name":os.path.basename(img),"contents":b64})
    vs=pf(tok,"GET","/catalog/blueprints/%s/print_providers/%s/variants.json"%(a["blueprint_id"],a["print_provider_id"])).get("variants",[])[:int(a.get("max_variants",16))]
    if not vs:raise ToolError("That blueprint/provider has no variants.")
    ids=[v["id"] for v in vs]
    body={"title":str(a["title"])[:140],"description":str(a["description"]),"blueprint_id":int(a["blueprint_id"]),"print_provider_id":int(a["print_provider_id"]),
          "tags":[str(t)[:20] for t in (a.get("tags") or [])][:13],
          "variants":[{"id":i,"price":int(round(price*100)),"is_enabled":True} for i in ids],
          "print_areas":[{"variant_ids":ids,"placeholders":[{"position":a.get("position","front"),"images":[{"id":up["id"],"x":0.5,"y":0.5,"scale":1,"angle":0}]}]}]}
    r=pf(tok,"POST","/shops/%s/products.json"%shop,body)
    return "Created Printify product id %s ('%s', %d variants, $%.2f). It is NOT published yet."%(r.get("id"),r.get("title"),len(ids),price)

def printify_publish(tok,shop,pid):
    pf(tok,"POST","/shops/%s/products/%s/publish.json"%(shop,pid),{"title":True,"description":True,"images":True,"variants":True,"tags":True,"keyvalues":True,"shipping_template":True})
    return "Publish requested for product %s. Printify pushes it to the connected store (e.g. Etsy). Check the shop in a minute."%pid

# ---------------------------------------------------------------- images
def gen_image(prov,key,prompt,dest,w=1024,h=1024):
    os.makedirs(os.path.dirname(dest),exist_ok=True);w=max(256,min(2048,int(w)));h=max(256,min(2048,int(h)))
    if prov=="openai":
        if not key:raise ToolError("Image provider is OpenAI but no openai key is saved.")
        size="1024x1024" if abs(w-h)<100 else ("1536x1024" if w>h else "1024x1536")
        d=json.loads(_get(EP["openai"]+"/v1/images/generations",headers={"Authorization":"Bearer "+key,"Content-Type":"application/json"},data=json.dumps({"model":"gpt-image-1","prompt":prompt,"size":size}).encode(),timeout=180))
        it=d["data"][0];b=base64.b64decode(it["b64_json"]) if it.get("b64_json") else _get(it["url"],raw=True,limit=15000000)
    else:
        u="%s/prompt/%s?%s"%(EP["pollinations"],urllib.parse.quote(str(prompt)[:900]),urllib.parse.urlencode({"width":w,"height":h,"nologo":"true","seed":int(time.time())%100000}))
        b=_get(u,raw=True,timeout=180,limit=15000000)
    if len(b)<100 or not(b[:4]==b"\x89PNG" or b[:3]==b"\xff\xd8\xff" or b[:4]==b"RIFF"):raise ToolError("The image service did not return an image.")
    open(dest,"wb").write(b);return len(b)

# ---------------------------------------------------------------- browser (optional, needs playwright)
JS_NUM="""()=>{let n=0,out=[];document.querySelectorAll('a[href],button,input:not([type=hidden]),select,textarea,[role=button]').forEach(e=>{const r=e.getBoundingClientRect();if(r.width<2||r.height<2)return;n++;e.setAttribute('data-sc',n);if(out.length<40){const t=(e.innerText||e.value||e.placeholder||e.getAttribute('aria-label')||e.name||'').trim().replace(/\\s+/g,' ').slice(0,60);out.push('['+n+'] '+e.tagName.toLowerCase()+(e.type?'('+e.type+')':'')+' '+t)}});return out}"""
def _summary(pg):
    try:pg.wait_for_load_state("domcontentloaded",timeout=5000)
    except Exception:pass
    els=pg.evaluate(JS_NUM);txt=re.sub(r"\s+"," ",pg.inner_text("body"))
    return "URL: %s\nTITLE: %s\nTEXT: %s\nCLICKABLE / TYPEABLE (use the number):\n%s"%(pg.url,pg.title(),txt[:3000],"\n".join(els))
def b_open(pg,url):pg.goto(url,wait_until="domcontentloaded",timeout=30000);return _summary(pg)
def b_text(pg):return _summary(pg)
def b_click(pg,t):
    t=str(t)
    if t.isdigit():pg.click('[data-sc="%s"]'%t,timeout=8000)
    else:pg.get_by_text(t,exact=False).first.click(timeout=8000)
    return _summary(pg)
def b_type(pg,t,text,enter=False):
    sel='[data-sc="%s"]'%t if str(t).isdigit() else str(t)
    pg.fill(sel,str(text),timeout=8000)
    if enter:pg.keyboard.press("Enter")
    return _summary(pg)
def b_shot(pg,dest):pg.screenshot(path=dest);return dest

def _pw_dirs():
    e=os.environ.get("PLAYWRIGHT_BROWSERS_PATH")
    if e and e!="0":return [e]
    h=os.path.expanduser("~");ds=[os.path.join(h,".cache","ms-playwright"),os.path.join(h,"Library","Caches","ms-playwright")]
    if os.environ.get("LOCALAPPDATA"):ds.insert(0,os.path.join(os.environ["LOCALAPPDATA"],"ms-playwright"))
    try:
        import playwright;ds.append(os.path.join(os.path.dirname(playwright.__file__),"driver","package",".local-browsers"))
    except Exception:pass
    return ds
def chromium_ok():
    "True when Playwright's Chromium browser has actually been downloaded (not just the Python package)."
    for d in _pw_dirs():
        try:
            for n in os.listdir(d):
                if re.match(r"chromium-\d+$",n) and os.listdir(os.path.join(d,n)):return True
        except Exception:pass
    return False
class Browser:
    ALL=[]
    def __init__(s):s.q=queue.Queue();s.th=None;s.lock=threading.Lock();s.visible=False;s.err="";Browser.ALL.append(s)
    def avail(s):return importlib.util.find_spec("playwright") is not None
    def ready(s):return s.avail() and chromium_ok() and not ("Executable doesn't exist" in s.err or "playwright install" in s.err)
    def reset(s):
        with s.lock:
            try:s.q.put((None,(),{"ev":threading.Event()}))
            except Exception:pass
            s.q=queue.Queue();s.th=None;s.err=""
    def _loop(s,q):
        try:
            from playwright.sync_api import sync_playwright
            pw=sync_playwright().start();br=pw.chromium.launch(headless=not s.visible)
            pg=br.new_context(viewport={"width":1280,"height":800}).new_page()
        except Exception as e:
            s.err=str(e)
            while True:
                f,a,res=q.get()
                if f is None:return
                res["err"]=s.err;res["ev"].set()
        while True:
            f,a,res=q.get()
            if f is None:break
            try:res["val"]=f(pg,*a)
            except Exception as e:res["err"]=str(e)
            res["ev"].set()
        try:br.close();pw.stop()
        except Exception:pass
    def call(s,f,*a,timeout=60):
        if not s.avail():raise ToolError(INSTALL_MSG)
        with s.lock:
            if not s.th:s.th=threading.Thread(target=s._loop,args=(s.q,),daemon=True);s.th.start()
            q=s.q
        res={"ev":threading.Event()};q.put((f,a,res))
        if not res["ev"].wait(timeout):raise ToolError("The browser took too long to respond.")
        if "err" in res:
            m=res["err"]
            if s.err:
                with s.lock:
                    if s.q is q:
                        try:q.put((None,(),{"ev":threading.Event()}))
                        except Exception:pass
                        s.q=queue.Queue();s.th=None
            if "Executable doesn't exist" in m or "playwright install" in m:raise ToolError(INSTALL_MSG)
            raise ToolError(m.split("\n")[0][:300])
        return res["val"]
BR=Browser()

INSTALL={"running":False,"log":[],"done":False};RESTART=[None]
def install_browser():
    if INSTALL["running"]:return
    INSTALL.update(running=True,log=["Installing the browser tool (about 150 MB, one time)..."],done=False)
    def run():
        ok=True
        for cmd in([sys.executable,"-m","pip","install","playwright"],[sys.executable,"-m","playwright","install","chromium"]):
            try:
                p=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
                for line in p.stdout:INSTALL["log"].append(line.rstrip()[:200]);INSTALL["log"]=INSTALL["log"][-40:]
                if p.wait()!=0:ok=False;break
            except Exception as e:INSTALL["log"].append("Error: %s"%e);ok=False;break
        loaded="playwright" in sys.modules
        INSTALL["log"].append(("Browser tool ready."+(" StarCommand will restart in a few seconds to start using it." if loaded else "")) if ok else "Install failed. Check your internet connection, then try again.")
        for b in Browser.ALL:b.reset()
        INSTALL.update(running=False,done=ok,restart=bool(ok and loaded))
        if ok and loaded and RESTART[0]:
            time.sleep(3);RESTART[0]()
    threading.Thread(target=run,daemon=True).start()


# ---------------------------------------------------------------- v8: keywords, SEO, risk, shop stats
def keyword_ideas(q,expand=True):
    """Real search suggestions (what people actually type). Free, no key."""
    q=str(q).strip()
    if not q:raise ToolError("Give a keyword or phrase.")
    seen=[];qs=[q]+([q+" "+c for c in "abcdefghimnprstw"] if expand else [])
    for x in qs:
        try:
            d=json.loads(_get("%s/complete/search?%s"%(EP["suggest"],urllib.parse.urlencode({"client":"firefox","q":x})),timeout=10))
            for t in d[1]:
                if t.lower() not in [z.lower() for z in seen]:seen.append(t)
        except Exception:continue
        if len(seen)>=40:break
    if not seen:raise ToolError("No suggestions came back (the suggestion service may be unreachable).")
    return "Search suggestions for '%s' (real autocomplete, a rough demand signal):\n"%q+"\n".join("- "+t for t in seen[:40])

def seo_check(title,tags,description=""):
    """Etsy listing rules: title <=140 chars, exactly 13 tags, each <=20 chars, no duplicates."""
    if isinstance(tags,str):tags=[t.strip() for t in tags.split(",") if t.strip()]
    tags=[str(t).strip() for t in (tags or [])];title=str(title or "");p=[]
    if not title:p.append("Title is empty.")
    if len(title)>140:p.append("Title is %d chars; Etsy allows 140."%len(title))
    if len(title)<40:p.append("Title is short (%d chars); use more of the 140 for keywords."%len(title))
    if len(tags)!=13:p.append("Has %d tags; Etsy allows 13 and you should use all 13."%len(tags))
    for t in tags:
        if len(t)>20:p.append("Tag '%s' is %d chars; the limit is 20."%(t,len(t)))
    low=[t.lower() for t in tags]
    for t in set(low):
        if low.count(t)>1:p.append("Tag '%s' is duplicated."%t)
    if description and len(str(description))<160:p.append("Description is very short; put keywords in the first 160 characters.")
    return "OK: passes the Etsy listing rules." if not p else "PROBLEMS:\n- "+"\n- ".join(p)

RISKY=("disney","marvel","pixar","nike","adidas","gucci","louis vuitton","chanel","pokemon","pok\u00e9mon","nintendo","mario","zelda","star wars","harry potter","hogwarts","taylor swift","barbie","hello kitty","sanrio","coca-cola","coca cola","starbucks","lego","minecraft","fortnite","spiderman","spider-man","batman","superman","mickey","bluey","peppa","stanley cup","yeti","nfl","nba","mlb","fifa","carhartt","the north face","patagonia","playboy","budweiser","jack daniel","gucci","versace","prada","hermes","tiffany","dr seuss","simpsons","south park","spongebob","naruto","one piece","ghibli","totoro","sesame street","grinch")
def risk_check(text):
    t=" "+re.sub(r"[^a-z0-9\u00e9 \-]"," ",str(text).lower())+" ";return [w for w in RISKY if " "+w+" " in t or (len(w)>5 and w in t)]

def etsy_shop_stats(key,shop):
    """Public stats of your own shop's active listings (views, favourites, stock). Needs the Etsy keystring + shop name."""
    if not key:raise ToolError("No Etsy key saved. Add your Etsy API keystring under API keys (etsy).")
    if not shop:raise ToolError("No Etsy shop name set. Open Settings and enter it under 'Etsy shop name'.")
    d=json.loads(_get("%s/v3/application/shops?%s"%(EP["etsy"],urllib.parse.urlencode({"shop_name":shop})),headers={"x-api-key":key}))
    rs=d.get("results") or []
    if not rs:raise ToolError("Etsy found no shop called '%s'."%shop)
    sid=rs[0]["shop_id"]
    d=json.loads(_get("%s/v3/application/shops/%s/listings/active?limit=100"%(EP["etsy"],sid),headers={"x-api-key":key}))
    L=[{"id":r.get("listing_id"),"title":r.get("title","")[:90],"views":r.get("views",0),"favs":r.get("num_favorers",0),"qty":r.get("quantity"),"tags":(r.get("tags") or [])[:13]} for r in d.get("results",[])]
    return L
