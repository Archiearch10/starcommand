"""StarCommand updater (runs inside the app): find a newer version, download it and check it carefully.

It never touches the running files. A checked update is placed in <data>/updates/pending and the launcher
installs it after the app exits (see launcher.py), with a backup and automatic rollback.
"""
import os,re,io,json,time,zipfile,hashlib,shutil,urllib.request,urllib.parse
OK_EXT=(".py",".js",".html",".bat",".vbs",".sh",".txt",".ico",".png",".webmanifest")
MUST=("server.py","launcher.py","index.html","gfx.js")
MAX_ZIP=60_000_000;MAX_FILE=25_000_000
class UpdateError(Exception):pass
def vtuple(v):return tuple(int(x) for x in re.findall(r"\d+",str(v))) or (0,)
def is_newer(a,b):return vtuple(a)>vtuple(b)
def _url_ok(u):
    p=urllib.parse.urlparse(u)
    if p.scheme=="https" and p.netloc:return True
    return bool(os.environ.get("STARCOMMAND_UPDATE_ALLOW_HTTP")) and p.scheme=="http" and p.hostname in("127.0.0.1","localhost")
def fetch(u,limit,timeout=40):
    if not _url_ok(u):raise UpdateError("The update address must start with https://")
    r=urllib.request.urlopen(urllib.request.Request(u,headers={"User-Agent":"StarCommand-updater"}),timeout=timeout)
    d=r.read(limit+1)
    if len(d)>limit:raise UpdateError("The update file is larger than allowed.")
    return d
def check(version_url):
    """-> {"version","url","sha256","notes"} from the version.json file"""
    try:d=json.loads(fetch(version_url,200000).decode("utf8"))
    except UpdateError:raise
    except Exception as e:raise UpdateError("Could not read the version file: %s"%str(e)[:120])
    if not d.get("version") or not d.get("url"):raise UpdateError("The version file needs a version and a url.")
    d["url"]=urllib.parse.urljoin(version_url,str(d["url"]))
    return d
def stage(info,data_dir):
    """Download, unpack and check an update. Returns the list of files placed in pending/."""
    pend=os.path.join(data_dir,"updates","pending");shutil.rmtree(pend,ignore_errors=True);os.makedirs(pend)
    try:
        raw=fetch(info["url"],MAX_ZIP,timeout=120)
        sh=str(info.get("sha256","")).lower().strip()
        if sh and hashlib.sha256(raw).hexdigest()!=sh:raise UpdateError("The download is damaged (checksum does not match).")
        try:z=zipfile.ZipFile(io.BytesIO(raw))
        except Exception:raise UpdateError("The download is not a valid zip file.")
        ents=[i for i in z.infolist() if not i.is_dir()]
        tops={i.filename.replace("\\","/").split("/")[0] for i in ents if "/" in i.filename.replace("\\","/")}
        strip=len(tops)==1 and all("/" in i.filename.replace("\\","/") for i in ents)
        names=[]
        for i in ents:
            n=i.filename.replace("\\","/")
            if strip:n=n.split("/",1)[1]
            if n.endswith("/") or "/" in n:continue          # only flat files are used; folders are ignored
            if ".." in n or n.startswith(".") or not n.lower().endswith(OK_EXT) or len(n)>80:continue
            if i.file_size>MAX_FILE:raise UpdateError("%s is too large."%n)
            open(os.path.join(pend,n),"wb").write(z.read(i));names.append(n)
        for m in MUST:
            if m not in names:raise UpdateError("The update is missing %s."%m)
        for n in names:
            if n.endswith(".py"):
                try:compile(open(os.path.join(pend,n),encoding="utf8").read(),n,"exec")
                except Exception as e:raise UpdateError("%s has an error (%s)."%(n,str(e)[:80]))
        m=re.search(r'^VER\s*=\s*"([^"]+)"',open(os.path.join(pend,"server.py"),encoding="utf8").read(),re.M)
        if not m or m.group(1)!=str(info["version"]):raise UpdateError("The update's version number does not match its version file.")
        json.dump({"version":str(info["version"]),"files":sorted(names),"notes":str(info.get("notes",""))[:300],"t":time.time()},open(os.path.join(pend,"manifest.json"),"w",encoding="utf8"))
        return names
    except Exception:
        shutil.rmtree(pend,ignore_errors=True);raise
