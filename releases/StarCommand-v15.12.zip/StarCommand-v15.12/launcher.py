"""StarCommand launcher.

Start StarCommand with this file (the desktop icon, start.bat and the Windows start-up shortcut all do).
It keeps the app running, opens it in its own window, and installs updates safely:

  1. The app downloads and checks a new version into  <data folder>/updates/pending  and quits with code 42.
  2. This launcher backs up the current app files, copies the new ones in and starts the app.
  3. If the new version does not become healthy within 90 seconds, the backup is put straight back,
     the bad version is remembered so it is not tried again, and the old version starts again.

Your data folder (agents, chats, files, keys) is never touched by an update.
Only standard-library Python is used so that this file keeps working even if everything else breaks.
"""
import os,sys,re,json,time,shutil,socket,subprocess,webbrowser,urllib.request
B=os.path.dirname(os.path.abspath(__file__))
DATA=os.environ.get("STARCOMMAND_DATA") or os.path.join(os.path.expanduser("~"),"StarCommand-data")
PORT=int(os.environ.get("STARCOMMAND_PORT") or 8766)
URL="http://127.0.0.1:%d"%PORT
WIN=os.name=="nt"
NOWIN=0x08000000 if WIN else 0
UPD=os.path.join(DATA,"updates");PEND=os.path.join(UPD,"pending");STATE=os.path.join(UPD,"state.json");BADF=os.path.join(UPD,"bad.json")
BK=os.path.join(DATA,"app-backups");LOG=os.path.join(DATA,"server.log");CFG=os.path.join(DATA,"launcher.json")
OK_EXT=(".py",".js",".html",".bat",".vbs",".sh",".txt",".ico",".png",".webmanifest")
os.makedirs(DATA,exist_ok=True);os.makedirs(UPD,exist_ok=True);os.makedirs(BK,exist_ok=True)
def jread(p,d=None):
    try:return json.load(open(p,encoding="utf8"))
    except Exception:return d
def jwrite(p,o):
    t=p+".tmp";json.dump(o,open(t,"w",encoding="utf8"),indent=1);os.replace(t,p)
def note(msg):
    try:open(os.path.join(DATA,"launcher.log"),"a",encoding="utf8").write("%s  %s\n"%(time.strftime("%Y-%m-%d %H:%M:%S"),msg))
    except Exception:pass
def app_ver():
    try:return re.search(r'^VER\s*=\s*"([^"]+)"',open(os.path.join(B,"server.py"),encoding="utf8").read(),re.M).group(1)
    except Exception:return "?"
def ping():
    try:
        r=json.load(urllib.request.urlopen(URL+"/api/ping",timeout=1.5))
        return r if r.get("starcommand") else None
    except Exception:return None
def box(title,text):
    note("message: "+text)
    if WIN:
        try:
            import ctypes;ctypes.windll.user32.MessageBoxW(0,text,title,0x40)
        except Exception:pass
    else:print(title+": "+text)
def port_busy():
    c=socket.socket();c.settimeout(.5)
    try:return c.connect_ex(("127.0.0.1",PORT))==0
    finally:c.close()
def stop_old():
    """We hold the launcher lock, so no other launcher exists. Anything still answering on the port is an old
    StarCommand (from before this launcher) or one whose launcher was killed: ask it to quit."""
    if not port_busy():return True
    try:urllib.request.urlopen(urllib.request.Request(URL+"/api/quit",b"{}",method="POST"),timeout=5)
    except Exception:pass
    for _ in range(24):
        if not port_busy():return True
        time.sleep(.5)
    return False
# ---------------------------------------------------------------- window
def window_exes():
    e=os.environ.get;out=[]
    for base in (e("ProgramFiles(x86)"),e("ProgramFiles"),e("LocalAppData")):
        if base:
            out.append(os.path.join(base,"Microsoft","Edge","Application","msedge.exe"))
            out.append(os.path.join(base,"Google","Chrome","Application","chrome.exe"))
    return [x for x in out if os.path.exists(x)]
def focus_window():
    """Bring an already-open StarCommand window to the front instead of opening a second one. Windows only."""
    if not WIN:return False
    try:
        import ctypes
        from ctypes import wintypes
        u=ctypes.windll.user32;found=[]
        PROC=ctypes.WINFUNCTYPE(ctypes.c_bool,wintypes.HWND,wintypes.LPARAM)
        def cb(h,_):
            if u.IsWindowVisible(h):
                n=u.GetWindowTextLengthW(h)
                if n:
                    b=ctypes.create_unicode_buffer(n+1);u.GetWindowTextW(h,b,n+1)
                    if re.match(r"^(\(\d+\)\s*)?StarCommand v\d",b.value):
                        c=ctypes.create_unicode_buffer(64);u.GetClassNameW(h,c,64)
                        if c.value.startswith("Chrome_WidgetWin"):found.append(h)
            return True
        u.EnumWindows(PROC(cb),0)
        if not found:return False
        h=found[0]
        if u.IsIconic(h):u.ShowWindow(h,9)
        u.SetForegroundWindow(h);return True
    except Exception:return False
def open_window():
    """Open StarCommand in its own app-style window. It uses its own private browser profile, so it never
    restores old tabs or shows the browser's start page, and it does not touch your normal Edge or Chrome."""
    if os.environ.get("STARCOMMAND_NO_WINDOW"):return
    prof=os.path.join(DATA,"browser-profile")
    for exe in window_exes():
        try:
            subprocess.Popen([exe,"--app="+URL,"--window-size=1440,900","--user-data-dir="+prof,"--no-first-run","--no-default-browser-check"],creationflags=NOWIN);return
        except Exception:pass
    try:webbrowser.open(URL)
    except Exception:pass
def show_window():
    if not focus_window():open_window()
# ---------------------------------------------------------------- one launcher at a time
def take_lock():
    s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    try:
        s.setsockopt(socket.SOL_SOCKET,socket.SO_EXCLUSIVEADDRUSE,1) if WIN else None
        s.bind(("127.0.0.1",PORT+1000));s.listen(1);return s
    except OSError:return None
# ---------------------------------------------------------------- shortcuts (Windows)
def _ps(script):
    return subprocess.run(["powershell","-NoProfile","-ExecutionPolicy","Bypass","-Command",script],capture_output=True,text=True,timeout=60,creationflags=NOWIN)
def _q(s):return "'"+str(s).replace("'","''")+"'"
def startup_path():return os.path.join(os.environ.get("APPDATA",""),"Microsoft","Windows","Start Menu","Programs","Startup","StarCommand.lnk")
def make_shortcuts(startup=None):
    """Desktop + Start menu shortcuts with the StarCommand icon. startup=True/False adds/removes the start-with-Windows one."""
    if not WIN:return "Shortcuts are only made on Windows."
    vbs=os.path.join(B,"StarCommand.vbs");ico=os.path.join(B,"icon.ico")
    ps=("$w=New-Object -COM WScript.Shell;"
        "function mk($p,$a){$s=$w.CreateShortcut($p);$s.TargetPath=$env:WINDIR+'\\System32\\wscript.exe';$s.Arguments=$a;$s.WorkingDirectory=%s;$s.IconLocation=%s;$s.Description='StarCommand';$s.Save()};"
        "$v='\"'+%s+'\"';"
        "mk (([Environment]::GetFolderPath('Desktop'))+'\\StarCommand.lnk') $v;"
        "mk (([Environment]::GetFolderPath('Programs'))+'\\StarCommand.lnk') $v;")%(_q(B),_q(ico),_q(vbs))
    if startup is True:ps+="mk (([Environment]::GetFolderPath('Startup'))+'\\StarCommand.lnk') ($v+' background');"
    r=_ps(ps)
    if startup is False:
        try:os.remove(startup_path())
        except OSError:pass
    return (r.stderr or "ok").strip()[:300]
def first_run_setup():
    c=jread(CFG,{})
    if WIN and (not c.get("shortcuts_v14") or os.path.normcase(c.get("shortcuts_dir",""))!=os.path.normcase(B)):
        try:
            make_shortcuts(True if os.path.exists(startup_path()) else None);c["shortcuts_v14"]=True;c["shortcuts_dir"]=B;jwrite(CFG,c);note("shortcuts point to "+B)
        except Exception as e:note("shortcuts failed: %s"%e)
# ---------------------------------------------------------------- updates
def safe_name(n):
    return bool(n) and "/" not in n and "\\" not in n and ".." not in n and not n.startswith(".") and n.lower().endswith(OK_EXT) and len(n)<80
def copy_over(src,dst):
    t=dst+".new";shutil.copyfile(src,t);os.replace(t,dst)
def restore(bdir,names):
    for n in names:
        s=os.path.join(bdir,n)
        if os.path.isfile(s):
            try:copy_over(s,os.path.join(B,n))
            except Exception as e:note("restore %s failed: %s"%(n,e))
def apply_pending():
    """Install a staged update. Returns the state dict if one was installed, else None."""
    man=jread(os.path.join(PEND,"manifest.json"))
    if not man:
        shutil.rmtree(PEND,ignore_errors=True);return None
    new=str(man.get("version"));names=[n for n in man.get("files",[]) if safe_name(n)]
    ok=names and all(os.path.isfile(os.path.join(PEND,n)) for n in names) and "server.py" in names and "launcher.py" in names
    if not ok:
        note("staged update %s is incomplete, ignored"%new);shutil.rmtree(PEND,ignore_errors=True);return None
    old=app_ver();bdir=os.path.join(BK,"v%s-%s"%(old,time.strftime("%Y%m%d-%H%M%S")));os.makedirs(bdir,exist_ok=True)
    for n in os.listdir(B):
        if safe_name(n) and os.path.isfile(os.path.join(B,n)):shutil.copy2(os.path.join(B,n),os.path.join(bdir,n))
    dj=os.path.join(DATA,"data.json")
    if os.path.isfile(dj):shutil.copy2(dj,os.path.join(bdir,"data.json"))
    try:
        for n in names:copy_over(os.path.join(PEND,n),os.path.join(B,n))
    except Exception as e:
        note("install failed (%s), restoring"%e);restore(bdir,names);shutil.rmtree(PEND,ignore_errors=True)
        jwrite(STATE,{"status":"rolled_back","version":new,"prev":old,"error":"could not copy files: %s"%e,"t":time.time(),"seen":False});return None
    shutil.rmtree(PEND,ignore_errors=True)
    st={"status":"trying","version":new,"prev":old,"backup":bdir,"files":names,"notes":str(man.get("notes",""))[:300],"t":time.time(),"seen":False}
    jwrite(STATE,st);note("installed %s over %s"%(new,old));return st
def log_tail(n=300):
    """the last error line of the app's log (or its last line)"""
    try:
        ls=[x.strip() for x in open(LOG,"rb").read()[-6000:].decode("utf8","ignore").splitlines() if x.strip()]
        for x in reversed(ls):
            if re.match(r"^[A-Za-z_.]*(Error|Exception)\b",x):return x[:n]
        return ls[-1][:n] if ls else ""
    except Exception:return ""
def prune_backups(keep=3):
    try:
        ds=sorted([d for d in os.listdir(BK) if os.path.isdir(os.path.join(BK,d))])
        for d in ds[:-keep]:shutil.rmtree(os.path.join(BK,d),ignore_errors=True)
    except Exception:pass
# ---------------------------------------------------------------- running the app
def rotate_log():
    try:
        if os.path.getsize(LOG)>1500000:os.replace(LOG,LOG+".1")
    except OSError:pass
def start_server(console):
    env=dict(os.environ,STARCOMMAND_SUPERVISED="1",STARCOMMAND_NOBROWSER="1",STARCOMMAND_PORT=str(PORT),PYTHONUTF8="1")
    cmd=[sys.executable,os.path.join(B,"server.py")]
    if console:return subprocess.Popen(cmd,cwd=B,env=env)
    lf=open(LOG,"ab")
    return subprocess.Popen(cmd,cwd=B,env=env,stdout=lf,stderr=lf,stdin=subprocess.DEVNULL,creationflags=NOWIN)
def wait_healthy(p,want,timeout=90):
    t0=time.time()
    while time.time()-t0<timeout:
        if p.poll() is not None:return False,"the new version stopped straight away (exit code %s). %s"%(p.returncode,log_tail())
        r=ping()
        if r and (not want or str(r.get("ver"))==str(want)):return True,""
        time.sleep(.7)
    return False,"the new version did not start within %d seconds. %s"%(timeout,log_tail())
def kill(p):
    try:
        p.kill();p.wait(10)
    except Exception:pass
def rollback(st,why):
    note("rolling back %s: %s"%(st["version"],why))
    restore(st["backup"],st.get("files",[]))
    bad=jread(BADF,[])
    if st["version"] not in bad:bad.append(st["version"]);jwrite(BADF,bad)
    jwrite(STATE,{"status":"rolled_back","version":st["version"],"prev":st["prev"],"error":why[:600],"t":time.time(),"seen":False})
def main():
    console="--console" in sys.argv;background="background" in sys.argv
    if "--shortcuts" in sys.argv:
        print(make_shortcuts(True if "--startup" in sys.argv else None));return 0
    if "--startup-on" in sys.argv:make_shortcuts(True);return 0
    if "--startup-off" in sys.argv:make_shortcuts(False);return 0
    lock=take_lock()
    if not lock:                                   # StarCommand is already running: just show its window
        for _ in range(20):
            if ping():break
            time.sleep(.5)
        if not background:show_window()
        return 0
    if not stop_old():
        box("StarCommand","Something is already using the StarCommand address (port %d). If an older StarCommand is open, choose Settings > Quit StarCommand in it, then start StarCommand again."%PORT);return 1
    rotate_log();first_run_setup()
    trying=apply_pending();opened=background;fast=[];after_rb=None
    while True:
        want=trying["version"] if trying else None
        p=start_server(console)
        ok,why=wait_healthy(p,want)
        if trying:
            if not ok:                              # the new version is broken: put the old one back
                kill(p);after_rb=trying["backup"];rollback(trying,why);trying=None;continue
            st=jread(STATE,{});st.update(status="ok");jwrite(STATE,st);prune_backups();trying=None;note("update healthy")
        elif after_rb:
            if not ok:                              # the old version cannot read the new data either: put the data back too
                kill(p);dj=os.path.join(after_rb,"data.json");after_rb=None
                if os.path.isfile(dj):shutil.copy2(dj,os.path.join(DATA,"data.json"));note("data.json restored from backup")
                continue
            after_rb=None
        if ok and not opened:open_window();opened=True
        if not ok and p.poll() is None:kill(p)      # started but never answered: treat as a crash
        code=p.wait()
        if code==0:break                            # Quit StarCommand in Settings
        if code==43:time.sleep(1);continue           # the app asked for a plain restart (e.g. after installing the browser tool)
        if code==42:                                # the app asked to install an update
            trying=apply_pending();fast.clear();continue
        fast=[t for t in fast if time.time()-t<180]+[time.time()]
        note("app stopped with code %s: %s"%(code,log_tail(300)))
        if len(fast)>=4:
            box("StarCommand","StarCommand keeps stopping. Details are in the file server.log in your StarCommand-data folder.\n\n"+log_tail(300));break
        time.sleep(2)
    return 0
if __name__=="__main__":
    try:sys.exit(main())
    except SystemExit:raise
    except Exception as e:
        import traceback;note("launcher crashed: "+traceback.format_exc());box("StarCommand","The launcher hit a problem: %s"%e);sys.exit(1)
