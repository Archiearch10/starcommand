"""StarCommand Vinted station: photo analysis, listing packs, and a form filler that
stops before Publish. No Vinted API is used (there is none); the filler drives a
normal browser window that YOU log into. It never clicks Publish."""
import os,re,io,json,time,uuid,base64,random,threading,subprocess,sys,urllib.request,urllib.error
import tools_ext as X

CTX={}          # filled in by server.init(): S, P, models, DATA, W, post, save
CONDS=["New with tags","New without tags","Very good","Good","Satisfactory"]
PARCELS=["Small","Medium","Large"]
def init(**k):CTX.update(k);os.makedirs(vdir(),exist_ok=True)
def vdir():return os.path.join(CTX["W"],"vinted","items")
def idir(i):
    i=re.sub(r"[^A-Za-z0-9_\-]","",str(i))
    if not i:raise X.ToolError("no item id")
    return os.path.join(vdir(),i)
def _json_load(p,d=None):
    try:return json.load(open(p,encoding="utf8"))
    except Exception:return d
def get_item(i):
    it=_json_load(os.path.join(idir(i),"item.json"))
    if not it:raise X.ToolError("no such Vinted item: %s"%i)
    return it
def put_item(it):
    d=idir(it["id"]);os.makedirs(d,exist_ok=True);tmp=os.path.join(d,"item.json.tmp")
    json.dump(it,open(tmp,"w",encoding="utf8"),indent=1);os.replace(tmp,os.path.join(d,"item.json"))
def list_items():
    out=[]
    if os.path.isdir(vdir()):
        for n in sorted(os.listdir(vdir()),reverse=True):
            it=_json_load(os.path.join(vdir(),n,"item.json"))
            if it and it.get("status")!="archived":out.append(it)
    return out

# ---------------------------------------------------------------- photos (iPhone HEIC -> JPEG)
_PIL={"tried":False,"ok":False,"heif":False,"htried":False,"err":""}
def _pip(*pk):
    r=subprocess.run([sys.executable,"-m","pip","install",*pk],capture_output=True,text=True,timeout=300)
    _PIL["err"]=((r.stdout or "")+(r.stderr or "")).strip()[-260:]
def ensure_pil():
    if _PIL["ok"]:return True
    try:import PIL.Image;_PIL["ok"]=True;return True
    except Exception:pass
    if not _PIL["tried"]:
        _PIL["tried"]=True
        try:_pip("pillow");import importlib;importlib.invalidate_caches();import PIL.Image;_PIL["ok"]=True
        except Exception as e:_PIL["err"]=_PIL["err"] or str(e)[:200]
    return _PIL["ok"]
def ensure_heif():
    """iPhone HEIC decoder (pillow-heif). Installed automatically the first time it is needed."""
    if _PIL["heif"]:return True
    def reg():
        from pillow_heif import register_heif_opener;register_heif_opener();_PIL["heif"]=True
    try:reg();return True
    except Exception:pass
    if not _PIL["htried"]:
        _PIL["htried"]=True
        try:_pip("pillow-heif");import importlib;importlib.invalidate_caches();reg();return True
        except Exception as e:_PIL["err"]=_PIL["err"] or str(e)[:200]
    return False
def is_heic(raw,name):
    return name.lower().endswith((".heic",".heif")) or (raw[4:8]==b"ftyp" and raw[8:12] in(b"heic",b"heix",b"hevc",b"heim",b"heis",b"mif1",b"msf1"))
def to_jpeg(raw,name):
    """returns jpeg bytes, max 1600px on the long side, rotated upright"""
    heic=is_heic(raw,name)
    if heic and not ensure_heif():
        raise X.ToolError("%s is an iPhone HEIC photo and the converter could not be installed automatically. Fix: open a Command Prompt and run   python -m pip install pillow-heif   then restart StarCommand and try again. (Or use JPG: iPhone Settings > Camera > Formats > Most Compatible.) Detail: %s"%(name,_PIL["err"] or "no details"))
    if not ensure_pil():
        if name.lower().endswith((".jpg",".jpeg")):return raw
        raise X.ToolError("%s needs the Pillow image tool, which could not be installed. Run   python -m pip install pillow pillow-heif   then restart. JPG photos work without it. Detail: %s"%(name,_PIL["err"]))
    from PIL import Image,ImageOps
    try:im=Image.open(io.BytesIO(raw));im=ImageOps.exif_transpose(im).convert("RGB");im.thumbnail((1600,1600))
    except Exception:raise X.ToolError("Could not read %s as a photo. Try a JPG or PNG picture."%name)
    b=io.BytesIO();im.save(b,"JPEG",quality=88);return b.getvalue()
def new_item(files,notes=""):
    """files: [{name,data(base64)}] -> item dict"""
    if not files:raise X.ToolError("add at least one photo")
    i="v"+time.strftime("%Y%m%d-%H%M%S")+"-"+uuid.uuid4().hex[:3];d=idir(i);os.makedirs(os.path.join(d,"photos"),exist_ok=True);names=[]
    for n,f in enumerate(files[:20],1):
        raw=base64.b64decode(f.get("data","").split(",")[-1]);jb=to_jpeg(raw,str(f.get("name","x.jpg")))
        nm="%02d.jpg"%n;open(os.path.join(d,"photos",nm),"wb").write(jb);names.append(nm)
    it={"id":i,"created":time.strftime("%d %b %Y %H:%M"),"status":"new","notes":str(notes)[:600],"photos":names,"pack":{},"report":"","looked":None}
    put_item(it);return it

# ---------------------------------------------------------------- vision
VDEF={"gemini":["gemini-2.5-flash","gemini-2.5-flash-lite","gemini-2.0-flash"],"groq":["qwen/qwen3.8-27b","meta-llama/llama-4-scout-17b-16e-instruct","meta-llama/llama-4-maverick-17b-128e-instruct"],
      "openai":["gpt-4o-mini","gpt-4.1-mini"],"openrouter":[]}
VHINT=re.compile(r"vision|scout|maverick|llama-4|qwen3\.\d|qwen.*vl|\bvl\b|-vl|omni|pixtral|llava|gemma-3|gemini.*flash|gpt-4o|gpt-4\.1",re.I)
VBAD=re.compile(r"tts|audio|embed|image-gen|imagen|live|whisper|guard|transcribe|search",re.I)
MAXIMG={"groq":3}
LOOK_PROMPT=("You are inspecting photos of ONE second-hand clothing item for a UK Vinted listing. Reply ONLY with JSON: "
 '{"item_type":"e.g. polo shirt","gender_or_fit":"men|women|unisex|kids|unknown","brand":"exact brand if a label or logo shows it, else null","brand_evidence":"where you saw it",'
 '"size_label":"size exactly as printed on the label, else null","size_evidence":"","colours":["main colours"],"pattern":"plain|striped|logo|graphic|checked|other","material_label":"fabric % if a label shows it, else null",'
 '"condition_visible":"new with tags|new without tags|very good|good|satisfactory","flaws":["every visible flaw: bobbling, stains, fading, holes, cracking print, missing buttons"],'
 '"details":["notable features: collar, zip, hood, embroidery, pockets"],"text_seen":["any readable text on labels or tags"],"unclear":["things you could NOT determine from the photos"]}. '
 "Never guess a brand or size you cannot read. Put anything uncertain in unclear.")
def _or_free_vision():
    """free OpenRouter models that accept images (read from OpenRouter's public model list)"""
    try:
        d=json.load(urllib.request.urlopen(urllib.request.Request("https://openrouter.ai/api/v1/models",headers={"User-Agent":"StarCommand"}),timeout=20))["data"]
        out=[m["id"] for m in d if "image" in ((m.get("architecture") or {}).get("input_modalities") or []) and str((m.get("pricing") or {}).get("prompt","1"))in("0","0.0") and str((m.get("pricing") or {}).get("completion","1")) in("0","0.0")]
        return out[:6]
    except Exception:return []
def _candidates():
    """every (provider, model) worth trying, best first: last one that worked, the user's choice, known good models, then discovered ones"""
    S,P=CTX["S"],CTX["P"];st=S["settings"];want=st.get("vision_provider","")
    order=[p for p in ([want] if want else [])+["gemini","groq","openrouter","openai"] if p in P and S["keys"].get(p)]
    order=list(dict.fromkeys(order));out=[]
    ok=st.get("vision_ok","")
    if "/" in ok and ok.split("/",1)[0] in order:out.append(tuple(ok.split("/",1)))
    for p in order:
        ms=[]
        if st.get("vision_model") and (not want or p==want):ms.append(st["vision_model"])
        ms+=VDEF.get(p,[])
        try:
            if p=="openrouter":ms+=_or_free_vision()
            else:ms+=[m for m in CTX["models"](p) if VHINT.search(m) and not VBAD.search(m)][:6]
        except Exception:pass
        for m in ms:
            m=m.replace("models/","")
            if (p,m) not in out:out.append((p,m))
    return out
def _pick_provider():
    c=_candidates();return c[0][0] if c else None
def _call(prov,model,msgs,timeout=120):
    P,S=CTX["P"],CTX["S"]
    h={"Content-Type":"application/json","Authorization":"Bearer "+S["keys"].get(prov,""),"User-Agent":"StarCommand/12"}
    body=json.dumps({"model":model,"messages":msgs,"temperature":0.2,"max_tokens":1400}).encode()
    r=json.load(urllib.request.urlopen(urllib.request.Request(P[prov][0],body,h),timeout=timeout))
    return r["choices"][0]["message"]["content"] or ""
def _parse(t):
    t=t.strip();m=re.search(r"\{.*\}",t,re.S)
    if not m:raise X.ToolError("the vision model did not return JSON")
    return json.loads(m.group(0))
def look(item_id,cache=False):
    it=get_item(item_id);d=idir(item_id)
    if cache and it.get("looked"):return it["looked"]
    if os.environ.get("STARCOMMAND_FAKE_VISION"):
        o={"item_type":"polo shirt","gender_or_fit":"men","brand":"Ralph Lauren","brand_evidence":"embroidered logo","size_label":"M","size_evidence":"care label","colours":["navy"],"pattern":"plain","material_label":"100% cotton","condition_visible":"very good","flaws":["slight fading on collar"],"details":["embroidered pony logo","two-button placket"],"text_seen":["M","100% cotton"],"unclear":[]}
        it["looked"]=o;put_item(it);return o
    cands=_candidates()
    if not cands:raise X.ToolError("No key that can read photos is set. Add a free Gemini key (aistudio.google.com/apikey) or a Groq or OpenRouter key in Settings > API keys.")
    def pics(n):
        out=[]
        for nm in it["photos"][:n]:
            raw=open(os.path.join(d,"photos",nm),"rb").read()
            try:
                from PIL import Image;im=Image.open(io.BytesIO(raw));im.thumbnail((1024,1024));bb=io.BytesIO();im.convert("RGB").save(bb,"JPEG",quality=82);raw=bb.getvalue()
            except Exception:pass
            out.append({"type":"image_url","image_url":{"url":"data:image/jpeg;base64,"+base64.b64encode(raw).decode()}})
        return out
    note="\nThe seller's own notes: "+it["notes"] if it.get("notes") else ""
    tried=[];deadp=set();t0=time.time()
    for prov,model in cands[:14]:
        if prov in deadp or time.time()-t0>240:continue
        msgs=[{"role":"user","content":[{"type":"text","text":LOOK_PROMPT+note}]+pics(MAXIMG.get(prov,5))}]
        for attempt in range(2):
            try:
                o=_parse(_call(prov,model,msgs))
                it["looked"]=o;it["vision"]=prov+"/"+model;put_item(it)
                CTX["S"]["settings"]["vision_ok"]=prov+"/"+model
                return o
            except urllib.error.HTTPError as e:
                body=e.read().decode("utf8","ignore")[:160];tried.append("%s/%s: %s"%(prov,model,e.code))
                if e.code in(401,403):deadp.add(prov)
                if e.code==429 and attempt==0:time.sleep(6);continue
                break
            except Exception as e:
                tried.append("%s/%s: %s"%(prov,model,str(e)[:80]));break
    raise X.ToolError("No photo-reading model worked. Tried: %s. The easiest fix is a free Gemini key (aistudio.google.com/apikey) in Settings > API keys."%"; ".join(tried[-8:]))

# ---------------------------------------------------------------- listing pack
def clean_pack(p):
    p=p if isinstance(p,dict) else {}
    def s(k,n):return str(p.get(k) or "").strip()[:n]
    cond=s("condition",40);m=[c for c in CONDS if c.lower()==cond.lower()]
    col=p.get("colours") or p.get("colors") or []
    if isinstance(col,str):col=[x.strip() for x in col.split(",")]
    try:price=round(float(str(p.get("price_gbp") or p.get("price") or 0).replace("£","")),2)
    except Exception:price=0.0
    tags=p.get("hashtags") or []
    if isinstance(tags,str):tags=re.findall(r"#?\w+",tags)
    q=p.get("questions") or []
    return {"title":s("title",100),"description":s("description",2000),"category":s("category",120),"brand":s("brand",60),"size":s("size",30),
      "condition":m[0] if m else (cond if cond else ""),"colours":[str(x)[:20] for x in col if str(x).strip()][:2],"material":s("material",60),
      "price_gbp":price,"parcel_size":next((x for x in PARCELS if x.lower()==s("parcel_size",12).lower()),"Small"),
      "hashtags":["#"+t.lstrip("#") for t in tags if str(t).strip()][:8],"questions":[str(x)[:200] for x in q if str(x).strip()][:8]}
def save_pack(item_id,pack,by_user=False):
    it=get_item(item_id);pk=clean_pack(pack);it["pack"]=pk
    miss=[k for k in("title","description","category","size","condition","price_gbp") if not pk[k]]
    if by_user:it["status"]="ready" if not miss else "analysed"
    else:it["status"]="analysed"
    it["missing"]=miss;put_item(it);return it

# ---------------------------------------------------------------- the form filler (never publishes)
VURL=lambda:os.environ.get("STARCOMMAND_VINTED_URL") or "https://www.vinted.co.uk/items/new"
def _sleep(a=.25,b=.7):time.sleep(random.uniform(a,b))
def _first(pg,cands,timeout=1500):
    for c in cands:
        try:
            l=(c(pg) if callable(c) else pg.locator(c)).first;l.wait_for(state="visible",timeout=timeout);return l
        except Exception:continue
    return None
def _rx(t):return re.compile(t,re.I)
FIELDS={"title":{"ids":["title--input","title"],"labels":[r"^\s*title"],"css":['input[name="title"]','input#title']},
 "description":{"ids":["description--input","description"],"labels":[r"describe|description"],"css":['textarea[name="description"]','textarea#description']},
 "price":{"ids":["price-input--input","price"],"labels":[r"^\s*price"],"css":['input[name="price"]','input#price']}}
DROP={"category":{"ids":["category-select-dropdown-input","catalog-select-dropdown-input"],"labels":[r"^\s*category"]},
 "brand":{"ids":["brand-select-dropdown-input"],"labels":[r"^\s*brand"]},"size":{"ids":["size-select-dropdown-input"],"labels":[r"^\s*size"]},
 "condition":{"ids":["status-select-dropdown-input","condition-select-dropdown-input"],"labels":[r"^\s*condition"]},
 "colour":{"ids":["color-select-dropdown-input","colors-select-dropdown-input"],"labels":[r"^\s*colou?r"]}}
def _text_field(pg,name,value):
    f=FIELDS[name];c=[lambda p,i=i:p.get_by_test_id(i) for i in f["ids"]]+list(f["css"])+[lambda p,l=l:p.get_by_label(_rx(l)) for l in f["labels"]]
    el=_first(pg,c)
    if not el:return "NOT FOUND - fill %s yourself"%name
    el.click();el.fill("");_sleep(.1,.3);el.fill(str(value));_sleep();return "ok"
def _choose_in_open(pg,text,exact=False):
    """pick an option by visible text in whatever list or dialog just opened"""
    opts=[lambda p:p.get_by_role("option",name=_rx("^%s$"%re.escape(text))),lambda p:p.get_by_role("option",name=_rx(re.escape(text))),
          lambda p:p.get_by_text(_rx("^\\s*%s\\s*$"%re.escape(text))),lambda p:p.get_by_text(_rx(re.escape(text)))]
    if exact:opts=opts[:1]+opts[2:3]
    o=_first(pg,opts,1200)
    if not o:return False
    o.click();_sleep();return True
def _dropdown(pg,name,values,search=False):
    d=DROP[name];trig=_first(pg,[lambda p,i=i:p.get_by_test_id(i) for i in d["ids"]]+[lambda p,l=l:p.get_by_label(_rx(l)) for l in d["labels"]]+[lambda p,l=l:p.get_by_text(_rx(l+"\\s*$")) for l in d["labels"]])
    if not trig:return "NOT FOUND - choose %s yourself"%name
    got=[]
    for v in values:
        try:
            trig.click();_sleep(.4,.8)
            if search:
                box=_first(pg,['input[type="text"]:focus','[role="dialog"] input[type="text"]','input[type="search"]'],800)
                if box:box.fill(str(v));_sleep(.5,.9)
            if _choose_in_open(pg,str(v)):got.append(str(v))
            else:pg.keyboard.press("Escape")
        except Exception:pass
    return "ok (%s)"%", ".join(got) if got else "COULD NOT SET '%s' - choose it yourself"%", ".join(values)
def _category(pg,path):
    trig=_first(pg,[lambda p,i=i:p.get_by_test_id(i) for i in DROP["category"]["ids"]]+[lambda p:p.get_by_label(_rx("^\\s*category")),lambda p:p.get_by_text(_rx("category\\s*$"))])
    if not trig:return "NOT FOUND - choose category yourself"
    trig.click();_sleep(.5,.9);done=[]
    for seg in [x.strip() for x in re.split(r">|/",path) if x.strip()]:
        if _choose_in_open(pg,seg):done.append(seg);_sleep(.4,.7)
        else:break
    return "ok (%s)"%" > ".join(done) if done else "COULD NOT SET '%s' - choose it yourself"%path
def _parcel(pg,size):
    el=_first(pg,[lambda p:p.get_by_role("radio",name=_rx(size)),lambda p:p.get_by_label(_rx("^\\s*%s"%size)),lambda p:p.get_by_text(_rx("^\\s*%s\\b"%size))],1000)
    if not el:return "NOT FOUND - choose the parcel size yourself"
    el.click();_sleep();return "ok"
def logged_in(pg):
    if re.search(r"/(member/)?(login|signup|session)",pg.url):return False
    try:
        if pg.get_by_role("button",name=_rx("^(log in|sign up)")).first.is_visible(timeout=800) and not pg.locator('input[type=file]').count():return False
    except Exception:pass
    return True
def _guard(pg):
    host=re.sub(r"^https?://([^/]+).*","\\1",pg.url)
    if not (host.endswith("vinted.co.uk") or os.environ.get("STARCOMMAND_VINTED_URL")):raise X.ToolError("Refusing to fill a page that is not vinted.co.uk (%s)"%host)
def f_fill(pg,pack,photos,shot):
    pg.goto(VURL(),wait_until="domcontentloaded",timeout=40000);_sleep(1.5,2.5);cookies(pg)
    if not logged_in(pg):return "NOT_LOGGED_IN: log in to Vinted in the window that just opened, then ask me to fill it again."
    _guard(pg);rep=[]
    try:
        inp=pg.locator('input[type="file"]').first;inp.set_input_files(photos,timeout=15000);rep.append(("photos","ok (%d)"%len(photos)));_sleep(2,3)
    except Exception as e:rep.append(("photos","COULD NOT ADD - add them yourself (%s)"%str(e).split("\n")[0][:80]))
    steps=[("title",lambda:_text_field(pg,"title",pack["title"])),("description",lambda:_text_field(pg,"description",pack["description"])),
     ("category",lambda:_category(pg,pack["category"]) if pack["category"] else "skipped (no category in the pack)"),
     ("brand",lambda:_dropdown(pg,"brand",[pack["brand"]],True) if pack["brand"] else "skipped (no brand: choose 'No brand' yourself)"),
     ("size",lambda:_dropdown(pg,"size",[pack["size"]]) if pack["size"] else "skipped (no size)"),
     ("condition",lambda:_dropdown(pg,"condition",[pack["condition"]]) if pack["condition"] else "skipped"),
     ("colour",lambda:_dropdown(pg,"colour",pack["colours"]) if pack["colours"] else "skipped"),
     ("price",lambda:_text_field(pg,"price",("%.2f"%pack["price_gbp"]).rstrip("0").rstrip(".")) if pack["price_gbp"] else "skipped (no price)"),
     ("parcel size",lambda:_parcel(pg,pack["parcel_size"]))]
    for nm,fn in steps:
        try:rep.append((nm,fn()))
        except Exception as e:rep.append((nm,"ERROR "+str(e).split("\n")[0][:100]))
    try:pg.screenshot(path=shot,full_page=True)
    except Exception:pass
    return "FILLED"+"\n"+"\n".join("%s: %s"%r for r in rep)
def f_inspect(pg,dest):
    pg.goto(VURL(),wait_until="domcontentloaded",timeout=40000);_sleep(1.5,2.5);cookies(pg)
    if not logged_in(pg):return "NOT_LOGGED_IN: log in to Vinted in the window, then try again."
    js="""()=>[...document.querySelectorAll('input,textarea,select,button,[role=combobox],[data-testid]')].map(e=>({tag:e.tagName,type:e.type||'',testid:e.getAttribute('data-testid')||'',name:e.getAttribute('name')||'',id:e.id||'',aria:e.getAttribute('aria-label')||'',placeholder:e.getAttribute('placeholder')||'',text:(e.innerText||'').slice(0,40)})).filter(o=>o.testid||o.name||o.aria||o.placeholder||o.text).slice(0,400)"""
    data=pg.evaluate(js);json.dump({"url":pg.url,"fields":data},open(dest,"w",encoding="utf8"),indent=1)
    return "Saved %d form elements to %s - send that file to Claude so the filler can be tuned."%(len(data),dest)

def cookies(pg):
    "Vinted greys the page out behind a cookie box until it is answered. Answer it with 'Reject all' (only necessary cookies) so the page can be used."
    for sel in("#onetrust-reject-all-handler","button:has-text('Reject all')","#onetrust-accept-btn-handler","button:has-text('Accept all')"):
        try:
            b=pg.locator(sel).first
            if b.is_visible(timeout=800):b.click(timeout=3000);_sleep(.5,1);return True
        except Exception:pass
    return False
class VBrowser(X.Browser):
    """own persistent, visible browser profile so you stay logged in to Vinted"""
    def _loop(s,q):
        try:
            from playwright.sync_api import sync_playwright
            pw=sync_playwright().start();hl=bool(os.environ.get("STARCOMMAND_VINTED_HEADLESS"));ctx=None;last=None
            close_login()
            for name in("vinted-profile","vinted-profile-2"):
                prof=os.path.join(CTX["DATA"],name);os.makedirs(prof,exist_ok=True)
                # use the real Chrome or Edge on this computer when possible (Google login works there and the window fits the screen);
                # fall back to the browser that came with the browser tool
                for ch in(("chrome","msedge",None) if not hl else (None,)):
                    o=dict(headless=hl,ignore_default_args=["--enable-automation"])
                    if ch:o["channel"]=ch
                    if hl:o["viewport"]={"width":1280,"height":900}
                    else:o.update(no_viewport=True,args=["--start-maximized"])
                    try:ctx=pw.chromium.launch_persistent_context(prof,**o);s.prof=prof;s.channel=ch;break
                    except Exception as e:last=e
                if ctx:break
            if ctx is None:raise last
            pg=ctx.pages[0] if ctx.pages else ctx.new_page()
        except Exception as e:
            s.err=str(e)
            while True:
                f,a,res=q.get()
                if f is None:return
                res["err"]=s.err;res["ev"].set()
        while True:
            f,a,res=q.get()
            if f is None:break
            try:
                if pg.is_closed():pg=ctx.new_page()
                res["val"]=f(pg,*a)
            except Exception as e:res["err"]=str(e)
            res["ev"].set()
        try:ctx.close();pw.stop()
        except Exception:pass
VB=VBrowser()
def fill(item_id):
    it=get_item(item_id);pk=it.get("pack") or {}
    if not pk.get("title"):raise X.ToolError("This item has no listing pack yet. Ask the Appraiser to analyse it first.")
    d=idir(item_id);photos=[os.path.join(d,"photos",n) for n in it["photos"]];shot=os.path.join(d,"form.png")
    r=VB.call(f_fill,pk,photos,shot,timeout=240)
    it=get_item(item_id);it["status"]="filled" if r.startswith("FILLED") else it["status"];it["report"]=r;put_item(it)
    if r.startswith("FILLED"):r+="\nThe form is open in the Vinted window and NOT published. Check every field, then press the upload button yourself."
    return r
LOGIN=[None]
def close_login():
    """The normal login window shares the form filler's profile, so it must be shut first. Edge/Chrome often keep running in the
    background after the window is closed, so close it for the user (the login is already saved in the profile)."""
    p=LOGIN[0]
    if p is None or p.poll() is not None:return
    try:
        if os.name=="nt":
            import subprocess;subprocess.run(["taskkill","/PID",str(p.pid),"/T","/F"],capture_output=True,timeout=15,creationflags=0x08000000)
        else:p.terminate()
        p.wait(10)
    except Exception:pass
    LOGIN[0]=None;time.sleep(1.5)
def browser_exes():
    "Real Chrome / Edge on this computer, in the same order the form filler tries them (Chrome first)."
    e=os.environ.get;out=[]
    for rel in(("Google","Chrome","Application","chrome.exe"),("Microsoft","Edge","Application","msedge.exe")):
        for base in(e("ProgramFiles"),e("ProgramFiles(x86)"),e("LocalAppData")):
            if base and os.path.exists(os.path.join(base,*rel)):out.append(os.path.join(base,*rel));break
    import shutil
    for n in("google-chrome","google-chrome-stable","microsoft-edge","chromium","chromium-browser"):
        w=shutil.which(n)
        if w:out.append(w)
    mac=["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome","/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"]
    return out+[m for m in mac if os.path.exists(m)]
def login_window():
    """Open Vinted's login page in a NORMAL browser window (not controlled by StarCommand), using the form filler's own profile.
    Google blocks 'Continue with Google' in automated windows, but allows it here. Once logged in, the form filler reuses the login."""
    import subprocess
    VB.reset();time.sleep(2.5)
    prof=getattr(VB,"prof",None) or os.path.join(CTX["DATA"],"vinted-profile");os.makedirs(prof,exist_ok=True)
    exes=browser_exes()
    ch=getattr(VB,"channel","x")
    if ch=="msedge":exes=sorted(exes,key=lambda x:0 if "edge" in x.lower() else 1)
    if not exes:raise X.ToolError("Could not find Google Chrome or Microsoft Edge on this computer.")
    base=re.match(r"https?://[^/]+",VURL()).group(0)
    LOGIN[0]=subprocess.Popen([exes[0],"--user-data-dir="+prof,"--no-first-run","--no-default-browser-check","--start-maximized",base+"/member/login"])
    return "A normal browser window has opened on the Vinted login page. Log in there (Continue with Google works in this window), then press Test browser in StarCommand (it closes the login window for you and checks the login is saved)."
def test():
    "Open the Vinted window and report what happened (used by Settings > Test browser)."
    def f(pg):
        pg.goto(VURL(),wait_until="domcontentloaded",timeout=40000);_sleep(1.5,2.5);cookies(pg);pg.bring_to_front();return "OK: the Vinted window opened (%s). %s"%(pg.title()[:60] or pg.url,"You are logged in." if logged_in(pg) else "You are NOT logged in yet: press 'Log in to Vinted' in Settings (Google login is blocked in the test window).")
    return VB.call(f,timeout=90)
def inspect():return VB.call(f_inspect,os.path.join(CTX["W"],"vinted","form-inspect.json"),timeout=120)
