"""Where StarCommand keeps things (standard library only).

DATA  = your agents, chats, files and keys. Normally  <your user folder>/StarCommand-data.
        If you chose "Keep StarCommand in my OneDrive", it is  <OneDrive>/StarCommand-data  instead, so it follows you
        to any computer where you sign in with the same account.
LOCAL = things that belong to this one computer (browser logins, downloaded updates, logs). Same as DATA normally;
        kept out of OneDrive when DATA is in OneDrive.
"""
import os,json,time,socket
HOME_DATA=os.path.join(os.path.expanduser("~"),"StarCommand-data")
def onedrive():
    for k in("OneDriveCommercial","OneDrive","OneDriveConsumer"):
        p=os.environ.get(k)
        if p and os.path.isdir(p):return p
    return ""
def cloud_data():
    od=onedrive();return os.path.join(od,"StarCommand-data") if od else ""
def data_dir():
    e=os.environ.get("STARCOMMAND_DATA")
    if e:return e
    c=cloud_data()
    if c and os.path.isfile(os.path.join(c,"data.json")):return c
    return HOME_DATA
def in_cloud(data):
    c=cloud_data();return bool(c) and os.path.normcase(os.path.abspath(data))==os.path.normcase(os.path.abspath(c))
def local_dir(data):
    if not in_cloud(data):return data
    base=os.environ.get("LOCALAPPDATA") or os.path.join(os.path.expanduser("~"),".local","share")
    p=os.path.join(base,"StarCommand");os.makedirs(p,exist_ok=True);return p
# ---- "open on another computer" check, so two computers never write to the same OneDrive copy at once
def host():return socket.gethostname()
def lock_file(data):return os.path.join(data,"in-use.json")
def other_user(data,fresh=180):
    "Name of another computer that has this StarCommand open right now, else ''."
    if not in_cloud(data):return ""
    try:d=json.load(open(lock_file(data),encoding="utf8"))
    except Exception:return ""
    if d.get("host")!=host() and time.time()-float(d.get("t",0))<fresh:return str(d.get("host") or "another computer")
    return ""
def beat(data):
    if not in_cloud(data):return
    try:
        p=lock_file(data);t=p+".tmp";json.dump({"host":host(),"t":time.time()},open(t,"w",encoding="utf8"));os.replace(t,p)
    except Exception:pass
def release(data):
    try:
        d=json.load(open(lock_file(data),encoding="utf8"))
        if d.get("host")==host():os.remove(lock_file(data))
    except Exception:pass
