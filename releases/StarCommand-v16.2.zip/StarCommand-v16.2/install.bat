@echo off
setlocal
cd /d "%~dp0"
title StarCommand installer
echo.
echo  StarCommand installer
echo  ---------------------
where python >nul 2>nul
if errorlevel 1 (
  where py >nul 2>nul
  if errorlevel 1 (
    echo Python was not found. Installing Python 3.12 using Windows' built-in installer...
    winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements
    echo.
    echo Python is installed. Please close this window and double-click install.bat once more.
    pause
    exit /b
  )
)
set "PY=python"
where python >nul 2>nul || set "PY=py"
echo Creating the StarCommand icon on your desktop and in the Start menu...
%PY% launcher.py --shortcuts
echo.
choice /c YN /m "Also start StarCommand automatically when you sign in to Windows"
if errorlevel 2 goto go
%PY% launcher.py --shortcuts --startup
:go
echo.
echo Starting StarCommand. It opens in its own window in a few seconds.
echo.
echo To pin it to your taskbar: press the Windows key, type StarCommand,
echo right-click the StarCommand result and choose "Pin to taskbar".
echo (Do not pin the open window itself, only the Start menu result.)
start "" wscript "%~dp0StarCommand.vbs"
timeout /t 8 >nul
