/* ======================================================================
   StarCommand v10 graphics engine - part 1: helpers, space backdrop,
   floor materials, walls, doors, lighting.
   Everything is drawn procedurally (no image files).
   ====================================================================== */
"use strict";
const SCN=false; /* Scandinavian theme: off (archived) */
/* ---- v13 performance controller: render resolution adapts to the computer's speed ----
   mode "auto" (default): starts sharp, lowers the resolution if frames get slow, raises it again when there is headroom
   "high": always full sharpness   "fast": lowest resolution and lighter effects */
const PERF={mode:"auto",rs:1,avg:16.7,last:0,lowT:0,hiT:0,lite:false};
try{PERF.mode=localStorage.getItem("sc_gfx")||"auto"}catch(e){}
function perfMax(){return Math.min(devicePixelRatio||1,2)}
function perfSet(m){PERF.mode=m;try{localStorage.setItem("sc_gfx",m)}catch(e){}PERF.rs=m=="fast"?1:perfMax();PERF.lite=m=="fast";PERF.lowT=PERF.hiT=0}
perfSet(PERF.mode);
function RDPR(){return PERF.rs}
function perfTick(now){
 const d=now-PERF.last;PERF.last=now;if(d>0&&d<400)PERF.avg=PERF.avg*.93+d*.07;
 if(PERF.mode!="auto")return;
 if(PERF.avg>25){if(!PERF.lowT)PERF.lowT=now;else if(now-PERF.lowT>1500){if(PERF.rs>1)PERF.rs=Math.max(1,Math.round((PERF.rs-.25)*4)/4);else PERF.lite=true;PERF.lowT=now}}else PERF.lowT=0;
 if(PERF.avg<18.5){if(!PERF.hiT)PERF.hiT=now;else if(now-PERF.hiT>8000){if(PERF.lite)PERF.lite=false;else if(PERF.rs<perfMax())PERF.rs=Math.min(perfMax(),PERF.rs+.25);PERF.hiT=now}}else PERF.hiT=0}
/* soft round glow sprites, one per colour, instead of building gradients every frame */
const GLOW={};
function glowSprite(col){let g=GLOW[col];if(g)return g;g=mk(64,64);const x=g.getContext("2d"),q=x.createRadialGradient(32,32,0,32,32,32);q.addColorStop(0,rgba(col,1));q.addColorStop(1,rgba(col,0));x.fillStyle=q;x.fillRect(0,0,64,64);return GLOW[col]=g}
const mk=(w,h)=>{const c=document.createElement("canvas");c.width=Math.max(1,Math.round(w));c.height=Math.max(1,Math.round(h));return c};
const hx=h=>{if(!h||h[0]!="#")return[128,128,128];if(h.length==4)h="#"+h[1]+h[1]+h[2]+h[2]+h[3]+h[3];const n=parseInt(h.slice(1,7),16);return[n>>16,n>>8&255,n&255]};
const rgba=(h,a)=>{const[r,g,b]=hx(h);return"rgba("+r+","+g+","+b+","+a+")"};
const mixc=(a,b,t)=>{const A=hx(a),B=hx(b);return"#"+[0,1,2].map(i=>Math.round(A[i]+(B[i]-A[i])*t).toString(16).padStart(2,"0")).join("")};
function R32(seed){let s=(seed>>>0)||1;return()=>{s^=s<<13;s>>>=0;s^=s>>>17;s^=s<<5;s>>>=0;return s/4294967296}}
/* v14.4 white "plan" look: used when the app theme is light */
const OFFICE=()=>typeof S!="undefined"&&S.settings&&(S.settings.layout_style||"office")=="office";
const WL=()=>document.documentElement.dataset.theme=="light"||OFFICE();
const SHA=a=>WL()?a*.28:a; /* shadows are much softer on white */
const LSP=new WeakMap();
function LS(s){/* a lighter copy of a dark prop sprite, for the white look */if(!WL()||!s)return s;let o=LSP.get(s);if(o)return o;o=mk(s.width,s.height);const g=o.getContext("2d");g.drawImage(s,0,0);g.globalCompositeOperation="source-atop";g.fillStyle="rgba(246,248,251,.58)";g.fillRect(0,0,o.width,o.height);g.globalCompositeOperation="source-over";["pad","wu","hu"].forEach(k=>{if(k in s)o[k]=s[k]});LSP.set(s,o);return o}
function planGrid(){if(BG.grid)return BG.grid;const c=mk(64,64),g=c.getContext("2d");g.fillStyle="#c9d1dc";g.fillRect(31,31,2,2);BG.grid=c;return c}
const TS=2; /* floor/wall texture scale: tile canvases are 64px for a 32px tile */
const HW=28,HLOW=8,HV=14; /* wall heights (tall north walls, low walls, vertical walls) */

/* ---------------------------------------------------------------- backdrop */
const BG={ready:false};
function mkBackdrop(){
 const tile=(n,sz,sd,cols)=>{const c=mk(sz,sz),g=c.getContext("2d"),r=R32(sd);for(let i=0;i<n;i++){const x=r()*sz,y=r()*sz,s=r(),rad=s<.9?.5+r()*.6:1+r()*.9;g.fillStyle=rgba(cols[(r()*cols.length)|0],.35+r()*.65);g.beginPath();g.arc(x,y,rad,0,7);g.fill();if(s>.97){const gr=g.createRadialGradient(x,y,0,x,y,5);gr.addColorStop(0,"rgba(190,220,255,.5)");gr.addColorStop(1,"rgba(190,220,255,0)");g.fillStyle=gr;g.fillRect(x-5,y-5,10,10)}}return c};
 BG.far=tile(260,512,11,["#ffffff","#9bd7ff","#ffd9a0","#c8b8ff"]);BG.mid=tile(110,512,23,["#ffffff","#bfe3ff","#ffe2b8"]);BG.near=tile(36,512,37,["#ffffff","#cfeaff"]);
 /* nebula */
 const n=mk(1400,900),g=n.getContext("2d");g.fillStyle="#03050c";g.fillRect(0,0,1400,900);
 [[420,300,520,"#4b2f9a",.5],[1020,560,560,"#0d5d8f",.45],[760,150,380,"#8a2a62",.32],[240,700,420,"#12708a",.28],[1180,180,300,"#3a2d8a",.3]].forEach(([x,y,r,c,a])=>{const gr=g.createRadialGradient(x,y,0,x,y,r);gr.addColorStop(0,rgba(c,a));gr.addColorStop(.5,rgba(c,a*.35));gr.addColorStop(1,rgba(c,0));g.fillStyle=gr;g.fillRect(0,0,1400,900)});
 const rr=R32(5);for(let i=0;i<60;i++){const x=rr()*1400,y=rr()*900,r=60+rr()*160,gr=g.createRadialGradient(x,y,0,x,y,r);gr.addColorStop(0,rgba(rr()<.5?"#6a5acd":"#2aa5c9",.05));gr.addColorStop(1,"rgba(0,0,0,0)");g.fillStyle=gr;g.fillRect(x-r,y-r,r*2,r*2)}
 BG.neb=n;
 /* planet */
 const P=mk(700,700),p=P.getContext("2d"),cx=350,cy=350,R=250;
 let gr=p.createRadialGradient(cx,cy,R*.9,cx,cy,R*1.35);gr.addColorStop(0,"rgba(90,170,255,.55)");gr.addColorStop(.35,"rgba(60,120,255,.18)");gr.addColorStop(1,"rgba(60,120,255,0)");p.fillStyle=gr;p.fillRect(0,0,700,700);
 p.save();p.beginPath();p.arc(cx,cy,R,0,7);p.clip();
 gr=p.createRadialGradient(cx-90,cy-90,20,cx,cy,R);gr.addColorStop(0,"#5aa7d8");gr.addColorStop(.45,"#2a6aa8");gr.addColorStop(1,"#0b2a55");p.fillStyle=gr;p.fillRect(0,0,700,700);
 const pr=R32(77);p.filter="blur("+Math.round(R*.03)+"px)";for(let i=0;i<60;i++){const x=cx+(pr()-.5)*R*2,y=cy+(pr()-.5)*R*1.6,w=R*(.12+pr()*.3),h=R*(.015+pr()*.04);p.fillStyle=pr()<.6?"rgba(235,245,255,.10)":"rgba(40,140,90,.16)";p.beginPath();p.ellipse(x,y,w,h,(pr()-.5)*.25,0,7);p.fill()}p.filter="none"
 gr=p.createRadialGradient(cx-110,cy-110,R*.2,cx+40,cy+40,R*1.25);gr.addColorStop(0,"rgba(255,255,255,0)");gr.addColorStop(.55,"rgba(0,5,25,.35)");gr.addColorStop(1,"rgba(0,3,15,.95)");p.fillStyle=gr;p.fillRect(0,0,700,700);
 for(let i=0;i<70;i++){const a=pr()*6.28,d=R*(.2+pr()*.7),x=cx+Math.cos(a)*d,y=cy+Math.sin(a)*d;if(x+y>cx+cy-30){p.fillStyle="rgba(255,214,140,.8)";p.fillRect(x,y,1.6,1.6)}}
 p.restore();
 p.strokeStyle="rgba(140,200,255,.55)";p.lineWidth=2.2;p.beginPath();p.arc(cx,cy,R,Math.PI*1.1,Math.PI*1.75);p.stroke();
 BG.planet=P;BG.ready=true}
function drawBackdropRaw(c,now){
 if(WL()){c.fillStyle="#eef1f5";c.fillRect(0,0,WW,WH);const z=Math.max(.15,cam.z),st=64*z;if(st>=10){const pat=c.createPattern(planGrid(),"repeat"),m=new DOMMatrix([z,0,0,z,-(cam.x*z)%st,-(cam.y*z)%st]);pat.setTransform(m);c.fillStyle=pat;c.fillRect(0,0,WW,WH)}return}
 if(!BG.ready)mkBackdrop();
 c.fillStyle="#02040a";c.fillRect(0,0,WW,WH);
 const cz=Math.max(.15,cam.z),px=cam.x*cz,py=cam.y*cz,dr=(wx,wy,ax,ay)=>{};
 /* nebula (very slow parallax) */
 const nx=-((px*.03)%1400+1400)%1400,ny=-((py*.03)%900+900)%900;
 c.globalAlpha=.9;for(let X=nx-1400;X<WW;X+=1400)for(let Y=ny-900;Y<WH;Y+=900)if(X<WW&&Y<WH&&X+1400>0&&Y+900>0)c.drawImage(BG.neb,X,Y);c.globalAlpha=1;
 /* planet + sun glow */
 const ppx=WW*.80-px*.045,ppy=WH*.22-py*.045,ps=Math.max(260,Math.min(WW,WH)*.62);
 c.drawImage(BG.planet,ppx-ps/2,ppy-ps/2,ps,ps);
 const sg=c.createRadialGradient(WW*.08-px*.02,WH*.1-py*.02,0,WW*.08-px*.02,WH*.1-py*.02,Math.max(WW,WH)*.45);sg.addColorStop(0,"rgba(255,240,210,.20)");sg.addColorStop(.25,"rgba(255,200,140,.07)");sg.addColorStop(1,"rgba(255,200,140,0)");c.fillStyle=sg;c.fillRect(0,0,WW,WH);
 /* three star layers */
 [[BG.far,.05,.75],[BG.mid,.12,.9],[BG.near,.24,1]].forEach(([t,k,a],i)=>{const ox=-((px*k)%512+512)%512,oy=-((py*k)%512+512)%512;c.globalAlpha=a*(.85+.15*Math.sin(now/1300+i*2));
  for(let X=ox-512;X<WW;X+=512)for(let Y=oy-512;Y<WH;Y+=512)c.drawImage(t,X,Y)});
 c.globalAlpha=1}

/* ---------------------------------------------------------------- floor materials */
const TC=new Map();
function tcache(key,w,h,fn){let c=TC.get(key);if(c)return c;c=mk(w,h);const g=c.getContext("2d");g.scale(TS,TS);fn(g);if(TC.size>900)TC.clear();TC.set(key,c);return c}
function rivet(g,x,y,r){const q=g.createRadialGradient(x-.3,y-.3,0,x,y,r);q.addColorStop(0,"#b6c2da");q.addColorStop(.6,"#5a6683");q.addColorStop(1,"#232a3b");g.fillStyle=q;g.beginPath();g.arc(x,y,r,0,7);g.fill();g.fillStyle="rgba(0,0,0,.35)";g.beginPath();g.arc(x+.3,y+.5,r*.9,Math.PI*.2,Math.PI*1.1);g.stroke()}
function paintMetal(g,v,col,seed){
 const r=R32(seed*7919+v*131+1);
 let q=g.createLinearGradient(0,0,32,32);q.addColorStop(0,"#566178");q.addColorStop(1,"#3d4659");g.fillStyle=q;g.fillRect(0,0,32,32);
 /* panel seams */
 g.fillStyle="#141925";g.fillRect(0,31,32,1);g.fillRect(31,0,1,32);g.fillStyle="rgba(255,255,255,.14)";g.fillRect(0,0,32,1);g.fillRect(0,0,1,32);
 g.fillStyle="rgba(0,0,0,.18)";g.fillRect(0,30,32,1);g.fillRect(30,0,1,32);
 /* recessed plate */
 g.beginPath();g.roundRect(3,3,26,26,2.2);q=g.createLinearGradient(3,3,29,29);q.addColorStop(0,"#4a5469");q.addColorStop(1,"#394255");g.fillStyle=q;g.fill();
 g.lineWidth=.9;g.strokeStyle="rgba(0,0,0,.42)";g.stroke();g.beginPath();g.roundRect(3.7,3.7,24.6,24.6,1.8);g.strokeStyle="rgba(255,255,255,.09)";g.stroke();
 /* brushed grain */
 for(let i=0;i<30;i++){const y=3+r()*26,x=3+r()*16,w=4+r()*12;g.fillStyle="rgba("+(r()<.5?"255,255,255":"0,0,0")+","+(.02+r()*.045)+")";g.fillRect(x,y,w,.45)}
 for(let i=0;i<46;i++){g.fillStyle="rgba("+(r()<.5?"255,255,255":"0,0,0")+","+(.03+r()*.05)+")";g.fillRect(3+r()*25,3+r()*25,.6,.6)}
 [[5.2,5.2],[26.8,5.2],[5.2,26.8],[26.8,26.8]].forEach(p=>rivet(g,p[0],p[1],1.15));
 if(v==1){/* vent */g.fillStyle="#10141d";g.beginPath();g.roundRect(8,9,16,14,1.5);g.fill();for(let i=0;i<5;i++){g.fillStyle="#232a3a";g.fillRect(9,10.2+i*2.6,14,1.5);g.fillStyle="rgba(255,255,255,.07)";g.fillRect(9,10.2+i*2.6,14,.35)}g.fillStyle="rgba(110,231,255,.06)";g.fillRect(8,22,16,2)}
 else if(v==2){/* hazard corner */g.save();g.beginPath();g.rect(3,22,26,7);g.clip();g.fillStyle="#d9a21b";g.fillRect(3,22,26,7);g.fillStyle="#15181f";for(let i=-2;i<12;i++){g.beginPath();g.moveTo(3+i*4.4,29);g.lineTo(3+i*4.4+2.4,29);g.lineTo(3+i*4.4+7,22);g.lineTo(3+i*4.4+4.6,22);g.fill()}g.restore();g.fillStyle="rgba(0,0,0,.35)";g.fillRect(3,28.4,26,.8)}
 else if(v==3){/* stencil arrow */g.fillStyle="rgba(255,255,255,.17)";g.beginPath();g.moveTo(16,8);g.lineTo(23,17);g.lineTo(18.5,17);g.lineTo(18.5,24);g.lineTo(13.5,24);g.lineTo(13.5,17);g.lineTo(9,17);g.closePath();g.fill()}
 else if(v==4){/* scuffs + scratches */for(let i=0;i<7;i++){g.strokeStyle="rgba(0,0,0,"+(.12+r()*.12)+")";g.lineWidth=.5;g.beginPath();const x=6+r()*18,y=6+r()*18;g.moveTo(x,y);g.lineTo(x+r()*7-3,y+r()*7-3);g.stroke()}g.fillStyle="rgba(0,0,0,.10)";g.beginPath();g.ellipse(18,20,7,3,.5,0,7);g.fill()}
 else if(v==5){/* light status square */g.fillStyle="#0e1219";g.fillRect(13,13,6,6);g.fillStyle=rgba(col,.9);g.fillRect(14,14,4,4);g.fillStyle="rgba(255,255,255,.35)";g.fillRect(14,14,4,1)}
 g.fillStyle=rgba(col,.085);g.fillRect(0,0,32,32)}
function paintWood(g,v,col,seed){
 const r=R32(seed*31337+v*17+3),tones=["#8a5f3a","#7d5632","#946a41","#704e2e","#876038"];
 for(let i=0;i<4;i++){const y=i*8,off=((seed+i*3)%5)*5;let t=tones[(r()*5)|0];
  for(let seg=0;seg<2;seg++){const x0=seg==0?0:(10+off)%24+4,x1=seg==0?(10+off)%24+4:32;let q=g.createLinearGradient(0,y,0,y+8);q.addColorStop(0,mixc(t,"#ffffff",.08));q.addColorStop(.5,t);q.addColorStop(1,mixc(t,"#000000",.28));g.fillStyle=q;g.fillRect(x0,y,x1-x0,8);
   for(let k=0;k<5;k++){g.strokeStyle="rgba(40,22,8,"+(.07+r()*.09)+")";g.lineWidth=.4;g.beginPath();const yy=y+1+r()*6;g.moveTo(x0,yy);g.bezierCurveTo(x0+8,yy+(r()-.5)*1.4,x1-8,yy+(r()-.5)*1.4,x1,yy);g.stroke()}
   g.fillStyle="rgba(0,0,0,.55)";g.fillRect(x0,y+7.4,x1-x0,.6);g.fillRect(x0,y,.6,8);t=tones[(r()*5)|0]}
  g.fillStyle="rgba(255,255,255,.07)";g.fillRect(0,y,32,.5)}
 if(v==1){g.fillStyle="rgba(30,14,4,.55)";g.beginPath();g.ellipse(14,12,2.2,1.4,0,0,7);g.fill()}
 g.fillStyle=rgba(col,.05);g.fillRect(0,0,32,32)}
function paintHub(g,v,col,seed){
 let q=g.createLinearGradient(0,0,32,32);q.addColorStop(0,"#3b3562");q.addColorStop(1,"#26214a");g.fillStyle=q;g.fillRect(0,0,32,32);
 /* hexagon plating */
 g.strokeStyle="rgba(0,0,0,.45)";g.lineWidth=.8;g.beginPath();g.moveTo(0,16);g.lineTo(8,3);g.lineTo(24,3);g.lineTo(32,16);g.lineTo(24,29);g.lineTo(8,29);g.closePath();g.stroke();
 g.strokeStyle="rgba(255,255,255,.09)";g.beginPath();g.moveTo(.5,16.8);g.lineTo(8.5,3.8);g.lineTo(23.5,3.8);g.stroke();
 g.strokeStyle=rgba("#a78bfa",v==1?.55:.22);g.lineWidth=.9;g.beginPath();g.moveTo(10,3);g.lineTo(6,10);g.moveTo(22,29);g.lineTo(26,22);g.stroke();
 q=g.createLinearGradient(0,0,0,32);q.addColorStop(0,"rgba(255,255,255,.10)");q.addColorStop(.5,"rgba(255,255,255,0)");g.fillStyle=q;g.fillRect(0,0,32,32);
 const r=R32(seed+9);for(let i=0;i<30;i++){g.fillStyle="rgba(255,255,255,"+(.03+r()*.05)+")";g.fillRect(r()*32,r()*32,.6,.6)}
 g.fillStyle="#151227";g.fillRect(0,31,32,1);g.fillRect(31,0,1,32)}
function paintHall(g,v,col,seed){
 let q=g.createLinearGradient(0,0,32,32);q.addColorStop(0,"#3c4558");q.addColorStop(1,"#2c3444");g.fillStyle=q;g.fillRect(0,0,32,32);
 /* diamond plate */
 g.strokeStyle="rgba(255,255,255,.07)";g.lineWidth=.5;for(let i=-32;i<64;i+=4){g.beginPath();g.moveTo(i,0);g.lineTo(i+32,32);g.stroke()}
 g.strokeStyle="rgba(0,0,0,.20)";for(let i=-32;i<64;i+=4){g.beginPath();g.moveTo(i+32,0);g.lineTo(i,32);g.stroke()}
 g.fillStyle="#111622";g.fillRect(0,31,32,1);g.fillRect(31,0,1,32);g.fillStyle="rgba(255,255,255,.11)";g.fillRect(0,0,32,.8);g.fillRect(0,0,.8,32);
 if(v==1){g.fillStyle="rgba(110,231,255,.0)";g.fillStyle=rgba("#6ee7ff",.5);g.fillRect(14.5,6,3,1.4);g.fillRect(14.5,24.6,3,1.4);g.fillStyle=rgba("#6ee7ff",.14);g.fillRect(13,5,6,4);g.fillRect(13,23.6,6,4)}}
function paintPlan(g,kind,v,col){
 const base=kind=="hub"?"#f7f6ff":kind=="hall"?"#f1f3f6":kind=="wood"?"#fbfbfc":"#ffffff";
 g.fillStyle=base;g.fillRect(0,0,32,32);g.fillStyle=kind=="hub"?"rgba(124,92,240,.10)":"rgba(16,24,40,.07)";g.fillRect(0,31.4,32,.6);g.fillRect(31.4,0,.6,32);
 if(kind=="metal"||kind=="wood"){g.fillStyle=rgba(col,.035);g.fillRect(0,0,32,32)}
 if(kind=="hall"&&v==1){g.fillStyle="rgba(16,24,40,.10)";g.fillRect(15,6,2,4);g.fillRect(15,22,2,4)}}
function floorCanvas(kind,v,col,seed){
 if(WL()){const kk="P"+kind+v+col;return tcache(kk,32*TS,32*TS,g=>paintPlan(g,kind,v,col))}
 const k=kind+v+col+(kind=="hub"?"":seed%4);
 return tcache(k,32*TS,32*TS,g=>{if(kind=="hub")paintHub(g,v,col,seed);else if(kind=="wood")paintWood(g,v,col,seed);else if(kind=="hall")paintHall(g,v,col,seed);else paintMetal(g,v,col,seed)})}

/* ---------------------------------------------------------------- wall pieces */
function paintWallPlan(g,v,col,tall){const H=tall?HW:HLOW,W=32;
 g.fillStyle="#d7dde6";g.fillRect(0,0,W,8);g.fillStyle="rgba(255,255,255,.9)";g.fillRect(0,0,W,.8);g.fillStyle="rgba(16,24,40,.12)";g.fillRect(0,7.3,W,.7);
 let q=g.createLinearGradient(0,8,0,8+H);q.addColorStop(0,"#f4f6f9");q.addColorStop(1,"#e4e8ee");g.fillStyle=q;g.fillRect(0,8,W,H);
 if(tall&&v==1){g.fillStyle="#d5e3f3";g.beginPath();g.roundRect(5,11,22,13,2);g.fill();g.strokeStyle="#b9c6d6";g.lineWidth=.8;g.stroke();g.fillStyle="rgba(255,255,255,.7)";g.beginPath();g.moveTo(8,24);g.lineTo(15,11);g.lineTo(18,11);g.lineTo(11,24);g.fill()}
 else if(tall&&v==3){g.fillStyle="#ffffff";g.beginPath();g.roundRect(7,12,18,12,1.5);g.fill();g.strokeStyle="#c8d0db";g.lineWidth=.8;g.stroke();g.fillStyle=rgba(col,.85);for(let i=0;i<3;i++)g.fillRect(9.5,14.6+i*2.7,5+i*3.5,1.1)}
 else if(tall){g.fillStyle="rgba(16,24,40,.05)";g.fillRect(15.7,8,.6,H)}
 g.fillStyle=rgba(col,.9);g.fillRect(0,8+H-2.2,W,1.4);g.fillStyle="rgba(16,24,40,.10)";g.fillRect(0,8+H-.8,W,.8)}
function paintWallTall(g,v,col){/* 32 x (8+HW) logical, drawn at TS scale */
 const H=HW,W=32;
 /* cap (top surface) */
 let q=g.createLinearGradient(0,0,0,8);q.addColorStop(0,"#b4c0d8");q.addColorStop(1,"#7f8dab");g.fillStyle=q;g.fillRect(0,0,W,8);
 g.fillStyle="rgba(255,255,255,.55)";g.fillRect(0,0,W,.9);g.fillStyle="rgba(0,0,0,.28)";g.fillRect(0,7.1,W,.9);
 g.fillStyle="rgba(0,0,0,.18)";for(let x=15.5;x<W;x+=16)g.fillRect(x,0.9,.6,6);
 /* face */
 q=g.createLinearGradient(0,8,0,8+H);q.addColorStop(0,"#5d6a87");q.addColorStop(.55,"#44506b");q.addColorStop(1,"#242c42");g.fillStyle=q;g.fillRect(0,8,W,H);
 g.fillStyle="rgba(255,255,255,.12)";g.fillRect(0,8,W,.7);
 g.fillStyle="rgba(10,14,26,.55)";g.fillRect(0,8,.8,H);g.fillStyle="rgba(255,255,255,.08)";g.fillRect(W-1,8,.8,H);
 /* horizontal rails */
 g.fillStyle="rgba(0,0,0,.32)";g.fillRect(0,8+9,W,.8);g.fillRect(0,8+H-7,W,.8);g.fillStyle="rgba(255,255,255,.08)";g.fillRect(0,8+9.8,W,.5);
 if(v==1){/* window to space */
  g.fillStyle="#0b0f1c";g.beginPath();g.roundRect(4,11,24,15,2);g.fill();
  const sq=g.createLinearGradient(4,11,28,26);sq.addColorStop(0,"#06102a");sq.addColorStop(1,"#0a1a3a");g.fillStyle=sq;g.beginPath();g.roundRect(5,12,22,13,1.5);g.fill();
  const r=R32(col.length*97+3);for(let i=0;i<14;i++){g.fillStyle="rgba(255,255,255,"+(.4+r()*.6)+")";g.fillRect(5.5+r()*21,12.5+r()*12,.7,.7)}
  g.fillStyle="rgba(120,180,255,.20)";g.beginPath();g.ellipse(21,22,9,5,-.3,0,7);g.fill();
  g.save();g.beginPath();g.roundRect(5,12,22,13,1.5);g.clip();g.fillStyle="rgba(255,255,255,.13)";g.beginPath();g.moveTo(6,25);g.lineTo(15,12);g.lineTo(19,12);g.lineTo(10,25);g.fill();g.restore();
  g.strokeStyle="#8d9ab8";g.lineWidth=1;g.beginPath();g.roundRect(4,11,24,15,2);g.stroke();g.fillStyle="#2a3247";g.fillRect(15.4,12,1.2,13)}
 else if(v==2){/* vent + pipes */
  g.fillStyle="#141a28";g.fillRect(6,12,20,10);for(let i=0;i<4;i++){g.fillStyle="#2c3550";g.fillRect(7,13+i*2.3,18,1.3)}
  g.strokeStyle="#7886a6";g.lineWidth=1;g.strokeRect(6,12,20,10);
  g.fillStyle="#38425e";g.fillRect(0,25.4,W,2.2);g.fillStyle="rgba(255,255,255,.25)";g.fillRect(0,25.4,W,.5)}
 else if(v==3){/* wall display */
  g.fillStyle="#0b0f1c";g.beginPath();g.roundRect(7,12,18,12,1.5);g.fill();g.fillStyle=rgba(col,.22);g.beginPath();g.roundRect(8,13,16,10,1);g.fill();
  g.fillStyle=rgba(col,.9);for(let i=0;i<3;i++)g.fillRect(9.5,14.6+i*2.7,5+i*3.5,1.1);g.strokeStyle="#7886a6";g.lineWidth=.8;g.beginPath();g.roundRect(7,12,18,12,1.5);g.stroke()}
 else{/* plain panel with vertical seams and bolts */
  g.fillStyle="rgba(0,0,0,.22)";g.fillRect(15.6,8,.8,H);g.fillStyle="rgba(255,255,255,.07)";g.fillRect(16.4,8,.5,H);
  [[3,11],[29,11],[3,8+H-10],[29,8+H-10]].forEach(p=>rivet(g,p[0],p[1],1))}
 /* skirting with glowing accent */
 g.fillStyle="#171c2c";g.fillRect(0,8+H-5,W,5);g.fillStyle="rgba(255,255,255,.10)";g.fillRect(0,8+H-5,W,.6);
 g.fillStyle=rgba(col,.95);g.fillRect(0,8+H-2.6,W,1.1);const gl=g.createLinearGradient(0,8+H-8,0,8+H);gl.addColorStop(0,rgba(col,0));gl.addColorStop(1,rgba(col,.28));g.fillStyle=gl;g.fillRect(0,8+H-8,W,8);
 /* ambient occlusion where wall meets floor */
 g.fillStyle="rgba(0,0,0,.30)";g.fillRect(0,8+H-1.2,W,1.2)}
function paintWallLow(g,v,col){
 let q=g.createLinearGradient(0,0,0,8);q.addColorStop(0,"#b0bcd4");q.addColorStop(1,"#7a88a6");g.fillStyle=q;g.fillRect(0,0,32,8);g.fillStyle="rgba(255,255,255,.5)";g.fillRect(0,0,32,.9);g.fillStyle="rgba(0,0,0,.25)";g.fillRect(0,7.2,32,.8);
 q=g.createLinearGradient(0,8,0,8+HLOW);q.addColorStop(0,"#566380");q.addColorStop(1,"#232b40");g.fillStyle=q;g.fillRect(0,8,32,HLOW);
 g.fillStyle=rgba(col,.9);g.fillRect(0,8+HLOW-2.4,32,1);g.fillStyle="rgba(0,0,0,.35)";g.fillRect(0,8+HLOW-1,32,1)}
function wallCanvas(tall,v,col){if(WL())return tcache("PW"+(tall?"T":"L")+v+col,32*TS,(8+(tall?HW:HLOW))*TS,g=>paintWallPlan(g,v,col,tall));return tcache("w"+(tall?"T":"L")+v+col,32*TS,(8+(tall?HW:HLOW))*TS,g=>tall?paintWallTall(g,v,col):paintWallLow(g,v,col))}
function jambCanvas(col){if(WL())return tcache("Pjamb"+col,8*TS,(8+HW)*TS,g=>{g.fillStyle="#dfe4eb";g.fillRect(0,0,8,8+HW);g.fillStyle="rgba(255,255,255,.9)";g.fillRect(0,0,8,.8);g.fillStyle=rgba(col,.9);g.fillRect(3.4,10,1.2,HW-6);g.fillStyle="rgba(16,24,40,.12)";g.fillRect(7.3,0,.7,8+HW)});return tcache("jamb"+col,8*TS,(8+HW)*TS,g=>{let q=g.createLinearGradient(0,0,8,0);q.addColorStop(0,"#8794b2");q.addColorStop(.5,"#6c7a9a");q.addColorStop(1,"#3a4560");g.fillStyle=q;g.fillRect(0,0,8,8+HW);g.fillStyle="rgba(255,255,255,.5)";g.fillRect(0,0,8,.9);g.fillStyle=rgba(col,.95);g.fillRect(3.4,10,1.2,HW-6);g.fillStyle="rgba(0,0,0,.35)";g.fillRect(0,8+HW-1,8,1)})}

/* ---------------------------------------------------------------- map build: walls, doors, lightmap */
let LGT=null,LB={x:0,y:0,w:1,h:1};
const roomColorAt=(c)=>{if(c>1&&MAP&&MAP.R[c-2])return MAP.R[c-2].color;return"#6ee7ff"};
function paintMap(){
 const M=MAP;M.doors=[];M.hr=[];M.vr=[];M.hdoor=[];M.vdoor=[];
 /* horizontal edges (between cell above and cell below) */
 for(let y=0;y<=HT;y++){let run=null;
  for(let x=0;x<=WT;x++){let a=0,b=0,t=null;if(x<WT){a=cd(x,y-1);b=cd(x,y);if(a!=b)t=edgeType(a,b)}
   const tall=t=="wall"&&!!b&&!a;
   if(t=="wall"){const col=roomColorAt(b||a),k=(tall?"T":"L")+col;if(run&&run.k==k&&run.x1==x)run.x1=x+1;else{if(run)M.hr.push(run);run={x0:x,x1:x+1,y,tall,col,k}}}
   else{if(run){M.hr.push(run);run=null}if(t=="door"){const d={x,y,px:x*T,py:y*T,v:false,o:0,col:roomColorAt(Math.max(a,b))};M.doors.push(d);M.hdoor.push(d)}}}
  if(run)M.hr.push(run)}
 /* vertical edges (between cell left and cell right) */
 for(let x=0;x<=WT;x++){let run=null;
  for(let y=0;y<=HT;y++){let a=0,b=0,t=null;if(y<HT){a=cd(x-1,y);b=cd(x,y);if(a!=b)t=edgeType(a,b)}
   if(t=="wall"){const col=roomColorAt(Math.max(a,b)),k=col+((!a||!b)?"o":"i");if(run&&run.k==k&&run.y1==y)run.y1=y+1;else{if(run)M.vr.push(run);run={x,y0:y,y1:y+1,col,k,edge:!a||!b}}}
   else{if(run){M.vr.push(run);run=null}if(t=="door"){const d={x,y,px:x*T,py:y*T,v:true,o:0,col:roomColorAt(Math.max(a,b))};M.doors.push(d);M.vdoor.push(d)}}}
  if(run)M.vr.push(run)}
 buildLightmap()}

/* ---------------------------------------------------------------- lighting */
const LPT=8; /* lightmap pixels per tile */
const AMB=[0.50,0.57,0.72];
function buildLightmap(){
 const M=MAP;let x0=1e9,y0=1e9,x1=-1,y1=-1;
 for(let y=0;y<HT;y++)for(let x=0;x<WT;x++)if(M.own[y*WT+x]){x0=Math.min(x0,x);y0=Math.min(y0,y);x1=Math.max(x1,x);y1=Math.max(y1,y)}
 if(x1<0){LGT=null;return}
 x0=Math.max(0,x0-3);y0=Math.max(0,y0-4);x1=Math.min(WT-1,x1+3);y1=Math.min(HT-1,y1+3);
 LB={x:x0,y:y0,w:x1-x0+1,h:y1-y0+1};const W=LB.w*LPT,H=LB.h*LPT;LGT=mk(W,H);const g=LGT.getContext("2d");
 g.fillStyle="#fff";g.fillRect(0,0,W,H);
 /* ambient inside the station (floor + the wall faces rising over the void) */
 const amb="rgb("+AMB.map(v=>Math.round(v*255)).join(",")+")",P=(tx,ty)=>[(tx-LB.x)*LPT,(ty-LB.y)*LPT];
 g.fillStyle=amb;g.filter="blur(5px)";
 for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++)if(M.own[y*WT+x]){const[px,py]=P(x,y);g.fillRect(px-1,py-1,LPT+2,LPT+2);if(y>0&&!M.own[(y-1)*WT+x])g.fillRect(px-1,py-4*LPT*.9,LPT+2,4*LPT*.9)}
 g.filter="none";
 /* soft darkening at the edges of rooms (ambient occlusion) */
 g.globalCompositeOperation="multiply";g.filter="blur(4px)";g.strokeStyle="rgba(150,160,190,1)";g.lineWidth=5;
 for(const r of M.R){const[px,py]=P(r.x,r.y);g.strokeRect(px+1,py+1,r.w*LPT-2,r.h*LPT-2)}
 g.filter="none";g.globalCompositeOperation="lighter";
 /* ceiling lights */
 const lamp=(wx,wy,rad,col,a)=>{const[px,py]=P(wx,wy);const q=g.createRadialGradient(px,py,0,px,py,rad*LPT);q.addColorStop(0,rgba(col,a));q.addColorStop(.6,rgba(col,a*.4));q.addColorStop(1,rgba(col,0));g.fillStyle=q;g.fillRect(px-rad*LPT,py-rad*LPT,rad*2*LPT,rad*2*LPT)};
 for(const r of M.R){const warm=r.kind=="break",c=r.hub?"#c9b8ff":warm?"#ffd7a0":"#cfe4ff",nx=Math.max(1,Math.round(r.w/6)),ny=Math.max(1,Math.round(r.h/6));
  for(let i=0;i<nx;i++)for(let j=0;j<ny;j++)lamp(r.x+(i+.5)*r.w/nx,r.y+(j+.5)*r.h/ny,Math.max(r.w/nx,r.h/ny)*.85,c,r.hub?.62:.55)}
 for(const h of LAY.halls)for(let i=0;i<Math.max(1,Math.round(Math.max(h.w,h.h)/5));i++){const t=(i+.5)/Math.max(1,Math.round(Math.max(h.w,h.h)/5));lamp(h.w>=h.h?h.x+h.w*t:h.x+h.w/2,h.w>=h.h?h.y+h.h/2:h.y+h.h*t,3.2,"#bfe9ff",.42)}
 g.globalCompositeOperation="source-over"}
const LC=mk(8,8),GC=mk(8,8);
function lightPass(c,dpr,now,lights){
 if(WL())return;
 /* draws the multiplicative light layer then additive glows. lights = [{x,y,r,col,a}] in world px */
 const LD=PERF.lite?4:3,sw=Math.max(2,Math.round(WW*dpr/LD)),sh=Math.max(2,Math.round(WH*dpr/LD));
 if(LC.width!=sw||LC.height!=sh){LC.width=sw;LC.height=sh;GC.width=sw;GC.height=sh}
 const l=LC.getContext("2d"),k=cam.z*dpr/LD;
 l.setTransform(1,0,0,1,0,0);l.globalCompositeOperation="source-over";l.fillStyle="#fff";l.fillRect(0,0,sw,sh);
 if(LGT){l.imageSmoothingEnabled=true;l.drawImage(LGT,(LB.x*T-cam.x)*k,(LB.y*T-cam.y)*k,LB.w*T*k,LB.h*T*k)}
 l.globalCompositeOperation="lighter";
 const g=GC.getContext("2d");g.setTransform(1,0,0,1,0,0);g.globalCompositeOperation="source-over";g.clearRect(0,0,sw,sh);g.globalCompositeOperation="lighter";
 for(const L of lights){const sx=(L.x-cam.x)*k,sy=(L.y-cam.y)*k,r=L.r*k;if(sx<-r||sy<-r||sx>sw+r||sy>sh+r)continue;
  const sp=glowSprite(L.col);l.globalAlpha=Math.min(1,L.a*.7);l.drawImage(sp,sx-r,sy-r,r*2,r*2);
  if(!PERF.lite){const r2=r*.9;g.globalAlpha=Math.min(1,L.a*.55);g.drawImage(sp,sx-r2,sy-r2,r2*2,r2*2)}}
 l.globalAlpha=1;g.globalAlpha=1;
 c.save();c.setTransform(1,0,0,1,0,0);c.imageSmoothingEnabled=true;c.imageSmoothingQuality="low";
 c.globalCompositeOperation="multiply";c.drawImage(LC,0,0,WW*dpr,WH*dpr);
 if(!SCN){c.globalCompositeOperation="lighter";c.globalAlpha=.85;c.drawImage(GC,0,0,WW*dpr,WH*dpr);c.globalAlpha=1}
 c.restore()}

/* cached backdrop: re-rendered only when the camera moves or every ~150ms (twinkle) */
let BGC=null,BGK="";
function drawBackdrop(c,now){
 const k=[cam.x|0,cam.y|0,cam.z.toFixed(3),WW,WH,WL()?0:(now/700)|0,c.canvas.width,WL()].join();
 if(!BGC)BGC=mk(2,2);
 if(k!==BGK){const sc=c.canvas.width/WW;const w=Math.max(2,Math.round(WW*sc)),h=Math.max(2,Math.round(WH*sc));if(BGC.width!=w||BGC.height!=h){BGC.width=w;BGC.height=h}
  const g=BGC.getContext("2d");g.setTransform(sc,0,0,sc,0,0);drawBackdropRaw(g,now);BGK=k}
 c.save();c.setTransform(1,0,0,1,0,0);c.imageSmoothingEnabled=false;c.drawImage(BGC,0,0);c.restore()}
/* ======================================================================
   part 2: drawing the world - floors, room decor, walls, doors, and the
   main paintWorld() with depth sorting, lighting and the HUD.
   ====================================================================== */
const floorKind=cc=>{if(cc==1)return"hall";const r=MAP.R[cc-2];return r?(r.hub?"hub":r.kind=="break"?"wood":"metal"):"metal"};
function floorTile(c,M,x,y){const cc=M.own[y*WT+x];if(!cc)return false;
  const kind=floorKind(cc),h=hash(x,y),col=cc>1?M.R[cc-2].color:"#6ee7ff";let v=0;
  if(kind=="metal"){v=h%31==0?1:h%41==0?3:h%19==0?4:h%53==0?5:0}else if(kind=="hall")v=(x+y)%6==0?1:0;else if(kind=="hub")v=(x+y)%3==0?1:0;else v=h%11==0?1:0;
  c.drawImage(floorCanvas(kind,v,col,h),x*T,y*T,T+.7,T+.7);return true}
/* v13: the floor is baked into 16x16-tile chunks (one image each) instead of ~1000 tile draws per frame.
   Chunks are re-made when the station layout changes or the zoom level needs a sharper copy. */
const FCH={map:null,m:new Map()},FCS=16;
function bakeChunk(M,cx,cy,sc){const P=1,W=FCS*T+2*P,ch=mk(W*sc,W*sc),g=ch.getContext("2d");g.setTransform(sc,0,0,sc,(P-cx*FCS*T)*sc,(P-cy*FCS*T)*sc);g.imageSmoothingEnabled=true;g.imageSmoothingQuality="high";let any=false;
 for(let y=Math.max(0,cy*FCS-1);y<=Math.min(HT-1,cy*FCS+FCS);y++)for(let x=Math.max(0,cx*FCS-1);x<=Math.min(WT-1,cx*FCS+FCS);x++)if(floorTile(g,M,x,y))any=true;
 return any?ch:null}
function drawFloor(c,x0,y0,x1,y1){
 const M=MAP,z=cam.z*RDPR(),sc=z<=.55?.5:z<=1.1?1:TS;
 if(FCH.map!==M||FCH.th!==WL()){FCH.map=M;FCH.th=WL();FCH.m.clear()}
 if(FCH.m.size>90)for(const k of [...FCH.m.keys()])if(!k.endsWith(","+sc))FCH.m.delete(k);
 for(let cy=Math.floor(y0/FCS);cy<=Math.floor(y1/FCS);cy++)for(let cx=Math.floor(x0/FCS);cx<=Math.floor(x1/FCS);cx++){
  const key=cx+","+cy+","+sc;let ch=FCH.m.get(key);
  if(ch===undefined){ch=bakeChunk(M,cx,cy,sc);FCH.m.set(key,ch)}
  if(ch)c.drawImage(ch,cx*FCS*T-1,cy*FCS*T-1,FCS*T+2,FCS*T+2)}}
function rr(c,x,y,w,h,r){c.beginPath();c.roundRect(x,y,w,h,r)}
/* v14.7 white plan: rooms are drawn as clean rounded cards joined by soft corridors (no tiles, no walls) */
function drawOffice(c,now){const H=LAY.halls.find(h=>h.id=="office")||LAY.halls[0];if(!H)return drawPlan(c,now);
 const X=H.x*T,Y=H.y*T,W=H.w*T,Hh=H.h*T;
 c.save();c.shadowColor="rgba(16,24,40,.14)";c.shadowBlur=36*cam.z*RDPR();c.shadowOffsetY=10*cam.z*RDPR();rr(c,X-12,Y-12,W+24,Hh+24,20);c.fillStyle="#d7dce3";c.fill();c.restore();
 rr(c,X,Y,W,Hh,12);c.fillStyle="#fcfcfd";c.fill();
 c.save();rr(c,X,Y,W,Hh,12);c.clip();c.strokeStyle="rgba(16,24,40,.035)";c.lineWidth=1;c.beginPath();for(let x=X+2*T;x<X+W;x+=2*T){c.moveTo(x,Y);c.lineTo(x,Y+Hh)}for(let y=Y+2*T;y<Y+Hh;y+=2*T){c.moveTo(X,y);c.lineTo(X+W,y)}c.stroke();c.restore();
 c.fillStyle="#d6e4f2";for(let y=Y+3*T;y<Y+Hh-2*T;y+=4*T){rr(c,X-10,y,7,2.6*T,2);c.fill();rr(c,X+W+3,y,7,2.6*T,2);c.fill()}
 c.fillStyle="#c3cad5";rr(c,X+W/2-34,Y+Hh+3,68,8,3);c.fill();
 for(const r of MAP.R){const x=r.x*T,y=r.y*T,w=r.w*T,h=r.h*T,col=r.color;
  if(r.hub){rr(c,x-8,y-4,w+16,h+8,14);c.fillStyle="rgba(52,64,84,.045)";c.fill();c.font="600 12px 'Segoe UI',system-ui,sans-serif";c.fillStyle="#667085";c.textAlign="center";c.textBaseline="alphabetic";c.fillText("Leadership",x+w/2,y+h+16);c.textAlign="left";continue}
  rr(c,x+3,y+3,w-6,h-6,12);c.fillStyle=rgba(col,.055);c.fill();c.strokeStyle=rgba(col,.28);c.lineWidth=1.2;c.stroke();
  c.fillStyle=col;rr(c,x+14,y+11,3.5,15,1.5);c.fill();c.font="600 13px 'Segoe UI',system-ui,sans-serif";c.fillStyle="#344054";c.textAlign="left";c.textBaseline="middle";c.fillText(r.name,x+24,y+19)}}
function drawPlan(c,now){
 c.fillStyle="#e2e7ee";for(const h of LAY.halls){rr(c,h.x*T+2,h.y*T+2,h.w*T-4,h.h*T-4,7);c.fill()}
 for(const r of MAP.R){const X=r.x*T,Y=r.y*T,W=r.w*T,H=r.h*T,col=r.color,half=r.hub&&r.shape=="half";
  const path=()=>{if(half){c.beginPath();c.moveTo(X+14,Y);c.lineTo(X+W-14,Y);c.quadraticCurveTo(X+W,Y,X+W,Y+12);c.ellipse(X+W/2,Y+12,W/2,H-12,0,0,Math.PI);c.quadraticCurveTo(X,Y,X+14,Y);c.closePath()}else rr(c,X,Y,W,H,14)};
  c.save();c.shadowColor="rgba(16,24,40,.10)";c.shadowBlur=24*cam.z*RDPR();c.shadowOffsetY=6*cam.z*RDPR();path();c.fillStyle=r.hub?"#fbfaff":"#ffffff";c.fill();c.restore();
  c.save();path();c.clip();c.fillStyle=rgba(col,.04);c.fillRect(X,Y,W,H);c.fillStyle=col;c.fillRect(X,Y,W,5);c.restore();
  path();c.lineWidth=1.4;c.strokeStyle=rgba(col,.45);c.stroke()}}
function drawRoomDecor(c,r,now){
 const M=MAP,col=r.color,X=r.x*T,Y=r.y*T,W=r.w*T,H=r.h*T;
 if(X>cam.x+WW/cam.z||X+W<cam.x||Y>cam.y+WH/cam.z||Y+H<cam.y)return;
 /* rugs */
 const sl=M.slots[r.id]||[];
 if(!WL()&&!r.hub&&sl.length){let a=1e9,b=1e9,d=-1,e=-1;sl.forEach(s=>{a=Math.min(a,s.x);b=Math.min(b,s.y);d=Math.max(d,s.x);e=Math.max(e,s.y+1)});
  const rx=a*T-12,ry=b*T+2,rw=(d-a+1)*T+24,rh=(e-b+1)*T+4,base=WL()?mixc(col,"#ffffff",.9):SCN?mixc(col,"#f3ecdf",.7):mixc(col,"#10131d",.74);
  rr(c,rx,ry,rw,rh,6);let q=c.createLinearGradient(rx,ry,rx,ry+rh);q.addColorStop(0,mixc(base,"#ffffff",.08));q.addColorStop(1,mixc(base,"#000000",.2));c.fillStyle=q;c.fill();
  c.strokeStyle=rgba(col,.45);c.lineWidth=1.4;rr(c,rx+4,ry+4,rw-8,rh-8,4);c.stroke();c.strokeStyle="rgba(255,255,255,.05)";c.lineWidth=.6;for(let i=ry+8;i<ry+rh-6;i+=3){c.beginPath();c.moveTo(rx+6,i);c.lineTo(rx+rw-6,i);c.stroke()}}
 if(r.kind=="break"&&!WL()){const cx=X+W/2+T*.5,cy=Y+H/2+T*1.6,rw=Math.min(W*.5,T*5),rh=rw*.55;c.save();c.beginPath();c.ellipse(cx,cy,rw,rh,0,0,7);let q=c.createRadialGradient(cx,cy,2,cx,cy,rw);q.addColorStop(0,WL()?mixc(col,"#ffffff",.85):(SCN?mixc(col,"#efe6d4",.6):mixc(col,"#2a1a10",.55)));q.addColorStop(1,WL()?mixc(col,"#ffffff",.75):mixc(col,"#10131d",.8));c.fillStyle=q;c.fill();c.strokeStyle=rgba(col,.5);c.lineWidth=1.4;c.stroke();c.beginPath();c.ellipse(cx,cy,rw*.82,rh*.8,0,0,7);c.strokeStyle="rgba(255,255,255,.12)";c.stroke();c.restore()}
 if(r.hub&&WL()){opsWall(c,r,now)}
 if(r.hub&&!SCN&&!WL()){const half=r.shape=="half",cx=X+W/2,cy=half?Y+H*.55:Y+H/2+T*.5,k=half?Math.min(W/2,H)/(T*7):1;
  [[T*2.9*k,.10],[T*2.3*k,.22],[T*1.5*k,.30]].forEach(([rad,a],i)=>{c.beginPath();c.arc(cx,cy,rad,0,7);c.fillStyle=rgba("#a78bfa",i==2?.12:.04);c.fill();c.lineWidth=i==1?2.4:1.4;c.strokeStyle=rgba("#a78bfa",.25+a);c.stroke()});
  c.save();c.translate(cx,cy);c.rotate(now/4200);c.setLineDash([14,10]);c.lineWidth=2.2;c.strokeStyle="rgba(196,181,253,.8)";c.beginPath();c.arc(0,0,T*2.3*k,0,7);c.stroke();c.setLineDash([3,9]);c.rotate(-now/2600);c.strokeStyle="rgba(110,231,255,.7)";c.beginPath();c.arc(0,0,T*2.9*k,0,7);c.stroke();c.setLineDash([]);
  c.rotate(now/5000);for(let i=0;i<24;i++){c.rotate(Math.PI/12);c.fillStyle=i%6==0?"rgba(196,181,253,.9)":"rgba(196,181,253,.4)";c.fillRect(T*3.05*k,-.7,i%6==0?6:3,1.4)}c.restore()}
 /* inner trim line */
 if(WL()){}else if(r.hub&&r.shape=="half")halfPath(c,X,Y,W,H,7);else rr(c,X+7,Y+7,W-14,H-14,6);c.lineWidth=5;c.strokeStyle=rgba(col,.07);c.stroke();c.lineWidth=1.2;c.strokeStyle=rgba(col,.55);c.stroke();
 /* floor stencil */
 if(!WL()&&cam.z>.3&&!(r.hub&&r.shape=="half")){c.save();c.font="bold 9px Bahnschrift,'Segoe UI',system-ui,sans-serif";c.textBaseline="alphabetic";c.fillStyle=rgba(col,.2);c.letterSpacing="3px";c.fillText(r.name.toUpperCase().slice(0,Math.floor(W/9)),X+16,Y+H-13);c.restore()}}

/* ---------------------------------------------------------------- walls */
function drawVBar(c,x,top,bot,col,capEnd,glow){
 /* x = left edge of the 8px bar; cap region [top,capEnd]; face region [capEnd,bot] */
 if(WL()){c.fillStyle="#d7dde6";c.fillRect(x,top,8,capEnd-top);c.fillStyle="#e9edf2";c.fillRect(x,capEnd,8,bot-capEnd);c.fillStyle="rgba(16,24,40,.12)";c.fillRect(x+7.3,top,.7,bot-top);c.fillStyle=rgba(col,.9);c.fillRect(x+2.6,bot-HV+3,2.8,Math.max(1,HV-5));return}
 let q=c.createLinearGradient(x,0,x+8,0);q.addColorStop(0,"#a3afc8");q.addColorStop(.45,"#7684a2");q.addColorStop(1,"#3f4a66");c.fillStyle=q;c.fillRect(x,top,8,capEnd-top);
 q=c.createLinearGradient(x,0,x+8,0);q.addColorStop(0,"#5e6b89");q.addColorStop(.5,"#47526e");q.addColorStop(1,"#232b41");c.fillStyle=q;c.fillRect(x,capEnd,8,bot-capEnd);
 c.fillStyle="rgba(255,255,255,.55)";c.fillRect(x,top,8,.9);c.fillStyle="rgba(255,255,255,.35)";c.fillRect(x,top,.9,capEnd-top);c.fillStyle="rgba(0,0,0,.35)";c.fillRect(x+7.2,top,.8,bot-top);
 c.fillStyle="rgba(0,0,0,.30)";c.fillRect(x,capEnd,8,.9);
 c.fillStyle=rgba(col,.95);c.fillRect(x+2.6,bot-HV+3,2.8,Math.max(1,bot-(bot-HV+3)-2));
 if(glow){c.fillStyle=rgba(col,.2);c.fillRect(x+1,bot-HV+2,6,HV-3)}}
function drawVRun(c,r){
 const px=r.x*T,top=r.y0*T-4-HV,bot=r.y1*T+4;
 if(px-8>cam.x+WW/cam.z||px+8<cam.x||bot<cam.y||top>cam.y+WH/cam.z)return;
 drawVBar(c,px-4,top,bot,r.col,bot-HV,false);
 c.fillStyle="rgba(0,0,0,.22)";for(let y=r.y0+1;y<r.y1;y++)c.fillRect(px-4,y*T-4-HV,8,.8);
 /* soft contact shadow on the floor beside the wall */
 const q=c.createLinearGradient(px+4,0,px+14,0);q.addColorStop(0,"rgba(0,0,10,"+SHA(.30)+")");q.addColorStop(1,"rgba(0,0,10,0)");c.fillStyle=q;c.fillRect(px+4,r.y0*T,10,(r.y1-r.y0)*T)}
function drawHRun(c,r){
 const py=r.y*T,x0=r.x0*T,x1=r.x1*T,fh=8+(r.tall?HW:HLOW),top=py+4-fh;
 if(x1<cam.x||x0>cam.x+WW/cam.z||py+8<cam.y||top>cam.y+WH/cam.z)return;
 for(let x=r.x0;x<r.x1;x++){
  if(x*T+T<cam.x||x*T>cam.x+WW/cam.z)continue;
  const h=hash(x,r.y);let v=0;if(r.tall){v=h%7==0?1:h%11==3?2:h%13==5?3:0}
  c.drawImage(wallCanvas(r.tall,v,r.col),x*T,top,T+.6,fh)}
 /* floor shadow under tall walls */
 if(r.tall){const q=c.createLinearGradient(0,py+4,0,py+16);q.addColorStop(0,"rgba(0,0,10,"+SHA(.38)+")");q.addColorStop(1,"rgba(0,0,10,0)");c.fillStyle=q;c.fillRect(x0,py+4,x1-x0,12)}}
function drawWalls(c,now){
 const M=MAP;
 M.vr.forEach(r=>drawVRun(c,r));
 M.hr.forEach(r=>drawHRun(c,r));
 /* door frames */
 for(const d of M.hdoor){
  if(d.px+48<cam.x||d.px-16>cam.x+WW/cam.z||d.py+20<cam.y||d.py-48>cam.y+WH/cam.z)continue;
  const fh=8+HW,top=d.py+4-fh,col=d.col;
  /* threshold plate */
  let q=c.createLinearGradient(0,d.py-4,0,d.py+5);q.addColorStop(0,WL()?"#e6eaf0":"#6a7690");q.addColorStop(1,WL()?"#d5dbe3":"#313a50");c.fillStyle=q;c.fillRect(d.px+3,d.py-4,26,9);c.fillStyle=rgba(col,.8);for(let i=0;i<3;i++){c.beginPath();c.moveTo(d.px+9+i*6,d.py-2);c.lineTo(d.px+12+i*6,d.py+.5);c.lineTo(d.px+9+i*6,d.py+3);c.lineTo(d.px+8+i*6,d.py+3);c.lineTo(d.px+11+i*6,d.py+.5);c.lineTo(d.px+8+i*6,d.py-2);c.fill()}
  /* lintel */
  const lint=wallCanvas(true,0,col);c.drawImage(lint,0,0,32*TS,15*TS,d.px+4,top,24,15);
  c.fillStyle=rgba(col,.95);c.fillRect(d.px+5,top+14.4,22,1.3);
  c.drawImage(jambCanvas(col),d.px-4,top,8,fh);c.drawImage(jambCanvas(col),d.px+28,top,8,fh)}
 for(const d of M.vdoor){
  if(d.px+16<cam.x||d.px-16>cam.x+WW/cam.z||d.py+60<cam.y||d.py-32>cam.y+WH/cam.z)continue;
  drawVBar(c,d.px-4,d.py-4-HV,d.py+4,d.col,d.py+4-HV,true);drawVBar(c,d.px-4,d.py+T-4-HV,d.py+T+4,d.col,d.py+T+4-HV,true);
  let q=c.createLinearGradient(d.px-3,0,d.px+3,0);q.addColorStop(0,WL()?"#d5dbe3":"#3a4560");q.addColorStop(1,WL()?"#e6eaf0":"#6a7690");c.fillStyle=q;c.fillRect(d.px-3,d.py+4,6,T-8);c.fillStyle=rgba(d.col,.7);for(let i=0;i<3;i++)c.fillRect(d.px-1,d.py+9+i*6,2,3)}}
function doorLeaves(c,d,now){
 /* animated sliding leaves; opens when anyone is close */
 let near=false;const cx=d.px+(d.v?0:T/2),cy=d.py+(d.v?T/2:0);
 for(const k in SP){const s=SP[k];if(Math.hypot(s.x*T-cx,s.y*T-cy)<T*1.7){near=true;break}}
 d.o+=((near?1:0)-d.o)*.16;if(d.o<.01)d.o=0;const o=d.o,col=d.col;
 if(!d.v){const top=d.py+4-(8+HW)+15,bot=d.py+4,half=11*(1-o);if(half<.4)return;
  [[d.px+5,1],[d.px+27-half,-1]].forEach(([x,dir])=>{let q=c.createLinearGradient(0,top,0,bot);q.addColorStop(0,WL()?"#eef1f5":"#7886a6");q.addColorStop(.5,WL()?"#e2e7ee":"#56627f");q.addColorStop(1,WL()?"#d3d9e2":"#2b3349");c.fillStyle=q;c.fillRect(x,top,half,bot-top);
   c.fillStyle="rgba(255,255,255,.25)";c.fillRect(x,top,half,.8);c.fillStyle="rgba(0,0,0,.35)";c.fillRect(x,bot-1,half,1);c.fillStyle=rgba(col,.9);const ex=dir>0?x+half-1.2:x;c.fillRect(ex,top+1,1.2,bot-top-2);
   c.fillStyle="rgba(0,0,0,.2)";for(let k=0;k<3;k++)c.fillRect(x,top+4+k*5,half,.7)})}
 else{const half=(T-8)/2*(1-o);if(half<.4)return;
  [[d.py+4,1],[d.py+T-4-half,-1]].forEach(([y,dir])=>{let q=c.createLinearGradient(d.px-3,0,d.px+3,0);q.addColorStop(0,WL()?"#d3d9e2":"#56627f");q.addColorStop(1,WL()?"#eef1f5":"#8794b2");c.fillStyle=q;c.fillRect(d.px-3,y,6,half);c.fillStyle=rgba(col,.9);const ey=dir>0?y+half-1.2:y;c.fillRect(d.px-3,ey,6,1.2)})}}

/* ---------------------------------------------------------------- main frame */
let PART=[];
function paintWorld(now){
 const dpr=RDPR(),c=wx,Z=cam.z;
 c.setTransform(dpr,0,0,dpr,0,0);drawBackdrop(c,now);
 if(!MAP)return;
 c.setTransform(dpr*Z,0,0,dpr*Z,-cam.x*Z*dpr,-cam.y*Z*dpr);c.imageSmoothingEnabled=true;c.imageSmoothingQuality="high";
 const vx0=Math.max(0,Math.floor(cam.x/T)-1),vx1=Math.min(WT-1,Math.ceil((cam.x+WW/Z)/T)+1),vy0=Math.max(0,Math.floor(cam.y/T)-1),vy1=Math.min(HT-1,Math.ceil((cam.y+WH/Z)/T)+1);
 const vis=(x,y)=>x>=vx0-3&&x<=vx1+3&&y>=vy0-3&&y<=vy1+3;
 const wl=WL();if(wl&&OFFICE())drawOffice(c,now);else if(wl)drawPlan(c,now);else drawFloor(c,vx0,vy0,vx1,vy1);
 hubCarpet(c,now);MAP.R.forEach(r=>drawRoomDecor(c,r,now));
 if(!wl){drawWalls(c,now);hubExtra(c,now)}
 /* ---- collect everything that stands on the floor ---- */
 const E=[],lights=[],low=Z<.28;
 const push=(y,fn,sh)=>E.push({y,fn,sh});
 const agAt={};S.agents.forEach(a=>{const s=SP[a.id];if(s)agAt[a.id]=s});
 MAP.R.forEach(r=>{if(r.hub)return;const mine=S.agents.filter(x=>!x.boss&&x.room==r.id);(MAP.slots[r.id]||[]).forEach((sl,i)=>{if(!vis(sl.x,sl.y))return;
  const ag=mine[i],s=ag&&SP[ag.id],busy=!!(ag&&S.busy&&ag.status!="Idle"&&s&&s.sit),wait=!!(ag&&S.pending.some(p=>p.who==ag.name));
  push((sl.y+1)*T,()=>deskDraw(c,sl,ag,busy,wait,now),()=>deskShadow(c,sl));
  push((sl.y+1)*T+10,()=>chairDraw(c,sl,r.color,0,s),null);push((sl.y+1)*T+22,()=>chairDraw(c,sl,r.color,1,s),null);
  if(!low)lights.push({x:sl.x*T+16,y:sl.y*T+10,r:busy?64:40,col:SCN?"#ffe6bc":busy?"#4fe4ff":"#2f7fa0",a:SCN?(busy?.22:.06):busy?.5:.16})})});
 MAP.props.forEach(p=>{if(!vis(p.x,p.y))return;
  const k=p.t=="belt"?p.y*T:(p.y+1)*T;push(k,()=>propDraw(c,p,now),()=>propShadow(c,p));propLights(p,lights,now)});
 const bs=MAP.bossSeat;if(bs&&vis(bs.x,bs.y)){push(bs.y*T+2,()=>throneDraw(c,bs,now),()=>softShadow(c,bs.x*T-4,bs.y*T+22,40,12,.55,1.6));push(bs.y*T+26,()=>throneBack(c,bs,now),null)}
 for(const d of MAP.doors){if(!wl&&vis(d.x,d.y)){push(d.v?d.py+2:d.py+6,()=>doorLeaves(c,d,now),null);if(d.o>.02||!low)lights.push({x:d.px+(d.v?0:16),y:d.py+(d.v?16:0),r:48,col:d.col,a:.18+d.o*.35})}}
 if(!wl)PK.forEach(p=>E.push({y:p.y*T+1,fn:()=>drawParcel(c,p,now),sh:null}));
 S.agents.forEach(a=>{const s=agAt[a.id];if(!s||!vis(s.x,s.y))return;E.push({y:s.y*T,fn:()=>agentDraw(c,a,s,now),sh:()=>agentShadow(c,a,s,now)});
  const bz=S.pending.some(p=>p.who==a.name);if(bz)lights.push({x:s.x*T,y:s.y*T-20,r:44,col:"#f59e0b",a:.4})});
 if(!low&&!PERF.lite)for(const e of E)if(e.sh)e.sh();
 E.sort((p,q)=>p.y-q.y);for(const e of E)e.fn();
 if(!PERF.lite&&!WL())drawParticles(c,now,vis);
 /* ---- lighting + glow, then unlit overlays ---- */
 lightPass(c,dpr,now,lights);
 c.setTransform(dpr*Z,0,0,dpr*Z,-cam.x*Z*dpr,-cam.y*Z*dpr);c.imageSmoothingEnabled=true;
 if(build.on){c.lineWidth=1/cam.z;c.strokeStyle="#6ee7ff22";c.beginPath();const x0=Math.max(0,Math.floor(cam.x/T)),x1=Math.min(WT,Math.ceil((cam.x+WW/cam.z)/T)),y0=Math.max(0,Math.floor(cam.y/T)),y1=Math.min(HT,Math.ceil((cam.y+WH/cam.z)/T));for(let x=x0;x<=x1;x++){c.moveTo(x*T,y0*T);c.lineTo(x*T,y1*T)}for(let y=y0;y<=y1;y++){c.moveTo(x0*T,y*T);c.lineTo(x1*T,y*T)}c.stroke();c.strokeStyle="#6ee7ff66";c.strokeRect(0,0,PW,PH);
  const r=rectOf(build.sel);if(r){c.strokeStyle="#6ee7ff";c.lineWidth=2/cam.z;c.strokeRect(r.x*T,r.y*T,r.w*T,r.h*T);const hs=handles(r),z=8/cam.z;c.fillStyle="#6ee7ff";for(const k in hs)c.fillRect(hs[k][0]-z/2,hs[k][1]-z/2,z,z)}
  const g=build.ghost;if(g){c.fillStyle=build.tool=="room"?"#a78bfa33":"#6ee7ff33";c.fillRect(g.x*T,g.y*T,g.w*T,g.h*T);c.setLineDash([6/cam.z,4/cam.z]);c.strokeStyle="#fff";c.strokeRect(g.x*T,g.y*T,g.w*T,g.h*T);c.setLineDash([])}}
 c.setTransform(dpr,0,0,dpr,0,0);
 if(!WL())paintTint(c,dpr);
 /* vignette */
 if(!WL()){const vg=c.createRadialGradient(WW/2,WH/2,Math.min(WW,WH)*.45,WW/2,WH/2,Math.max(WW,WH)*.78);vg.addColorStop(0,"rgba(0,0,12,0)");vg.addColorStop(1,SCN?"rgba(70,50,20,.16)":"rgba(0,0,12,.55)");c.fillStyle=vg;c.fillRect(0,0,WW,WH)}
 paintHUD(c,now,dpr)}
/* ======================================================================
   part 3: furniture and props. Static art is painted once into cached
   sprites (3x resolution); screens, lights and steam are animated live.
   ====================================================================== */
const PS=3,PC=new Map();
function PSPR(key,wu,hu,pad,fn){let c=PC.get(key);if(!c){c=mk(wu*PS,(hu+pad)*PS);const g=c.getContext("2d");g.scale(PS,PS);g.translate(0,pad);fn(g);c.pad=pad;c.wu=wu;c.hu=hu+pad;if(PC.size>300)PC.clear();PC.set(key,c)}return c}
const blit=(c,s,x,y)=>{s=LS(s);c.drawImage(s,x,y-s.pad,s.wu,s.hu)};
function vgrad(g,y0,y1,stops){const q=g.createLinearGradient(0,y0,0,y1);stops.forEach(([o,cl])=>q.addColorStop(o,cl));return q}
function hgrad(g,x0,x1,stops){const q=g.createLinearGradient(x0,0,x1,0);stops.forEach(([o,cl])=>q.addColorStop(o,cl));return q}
function softShadow(c,x,y,w,h,a,sp){a=SHA(a);/* layered rounded rects fake a blur */for(let i=3;i>=0;i--){c.fillStyle="rgba(0,0,10,"+(a*(.25+(3-i)*.25)/2.2)+")";const e=i*(sp||1.6);rr(c,x-e,y-e,w+e*2,h+e*2,3+e);c.fill()}}

/* ------------------------------------------------------------ workstation */
function pDesk(g,v){
 g.fillStyle=vgrad(g,11,25,[[0,"#b3bed4"],[.5,"#8e99b1"],[1,"#6c7790"]]);g.beginPath();g.roundRect(.5,11,31,14,2.2);g.fill();
 g.strokeStyle="rgba(255,255,255,.55)";g.lineWidth=.6;g.beginPath();g.moveTo(2,11.3);g.lineTo(30,11.3);g.stroke();
 g.fillStyle="rgba(255,255,255,.08)";g.beginPath();g.moveTo(3,12);g.lineTo(14,12);g.lineTo(9,24);g.lineTo(3,24);g.fill();
 g.fillStyle=vgrad(g,25,31,[[0,"#4a556e"],[1,"#1b2132"]]);g.beginPath();g.roundRect(1,24.6,30,6.4,1.2);g.fill();
 g.fillStyle="rgba(110,231,255,.9)";g.fillRect(3,26.6,26,.9);g.fillStyle="rgba(0,0,0,.4)";g.fillRect(1,30.2,30,.8);
 [[3.5,27.8],[28.5,27.8]].forEach(p=>rivet(g,p[0],p[1],.7));
 /* monitor */
 g.fillStyle="#262d40";g.fillRect(14.3,9,3.4,3.2);g.fillStyle=hgrad(g,10,22,[[0,"#4b5670"],[1,"#242b3e"]]);g.beginPath();g.ellipse(16,12.2,5.4,1.7,0,0,7);g.fill();
 g.fillStyle="rgba(0,0,0,.35)";g.beginPath();g.ellipse(16,12.6,6,1.8,0,0,7);g.fill();
 g.fillStyle=vgrad(g,0,12,[[0,"#2b344a"],[1,"#12172a"]]);g.beginPath();g.roundRect(5.4,.3,21.2,11.4,1.8);g.fill();
 g.strokeStyle="rgba(255,255,255,.28)";g.lineWidth=.5;g.beginPath();g.roundRect(5.4,.3,21.2,11.4,1.8);g.stroke();
 g.fillStyle="#05080f";g.beginPath();g.roundRect(7,1.6,18,8.6,.8);g.fill();
 /* keyboard, mouse, mug, notepad */
 g.fillStyle="#141a2a";g.beginPath();g.roundRect(8.6,15.2,14.8,5.4,1);g.fill();g.fillStyle="rgba(255,255,255,.12)";g.fillRect(8.9,15.4,14.2,.4);
 for(let r=0;r<3;r++)for(let k=0;k<9;k++){g.fillStyle=(k+r*3)%7==0?"rgba(110,231,255,.65)":"#2e3753";g.fillRect(9.4+k*1.5,16+r*1.4,1.1,.9)}
 g.fillStyle=vgrad(g,15,20,[[0,"#4a5670"],[1,"#262d40"]]);g.beginPath();g.roundRect(25.4,15.8,3.2,4.8,1.5);g.fill();g.fillStyle="rgba(110,231,255,.7)";g.fillRect(26.7,16.4,.6,1.2);
 const mugc=["#f59e0b","#ef4444","#34d399","#a78bfa","#e5e7eb"][v%5];g.fillStyle="rgba(0,0,0,.3)";g.beginPath();g.ellipse(4.6,19.6,2.7,1.2,0,0,7);g.fill();g.fillStyle=mugc;g.beginPath();g.ellipse(4.5,18.6,2.3,2.4,0,0,7);g.fill();g.fillStyle="rgba(255,255,255,.4)";g.fillRect(3.3,17,.8,3);g.fillStyle="#2a1a10";g.beginPath();g.ellipse(4.5,17.3,1.7,.8,0,0,7);g.fill();g.strokeStyle=mugc;g.lineWidth=.7;g.beginPath();g.arc(7,18.5,1.2,-1.2,1.2);g.stroke();
 if(v%3==0){g.save();g.translate(28,13.4);g.rotate(.2);g.fillStyle="#e8e4d4";g.fillRect(-2.6,-1.8,5.2,3.6);g.fillStyle="#9a96a0";for(let i=0;i<3;i++)g.fillRect(-2,-1.1+i*1,3.8,.3);g.restore()}}
function deskSprite(v){return PSPR("desk"+(v%5),32,32,0,g=>pDesk(g,v))}
function deskShadow(c,sl){if(WL())return;softShadow(c,sl.x*T+2,sl.y*T+14,30,19,.55,2)}
function deskDraw(c,sl,ag,busy,wait,now){
 if(WL()){const x=sl.x*T,y=sl.y*T,st=ag?ag.status||"":"",stuck=/^(stuck|error)/i.test(st);
  rr(c,x+2,y+3,28,18,4);c.fillStyle="#ffffff";c.fill();c.strokeStyle="#d0d5dd";c.lineWidth=1;c.stroke();
  const sx=x+8,sy=y+5,sw=16,sh=10;rr(c,sx,sy,sw,sh,1.6);c.fillStyle=!ag?"#eaecf0":wait?"#f79009":stuck?"#d92d20":busy?"#2f6bdb":"#475467";c.fill();
  if(busy&&!wait&&!stuck){c.fillStyle="rgba(255,255,255,.85)";const k=(now/260|0);for(let i=0;i<3;i++)c.fillRect(sx+2.5,sy+2.2+i*2.4,3+((hash(k+i,sl.x)%8)),1)}
  c.fillStyle="#d0d5dd";rr(c,sx-2,sy+sh,sw+4,2.2,1);c.fill();return}
 const x=sl.x*T,y=sl.y*T;blit(c,deskSprite(hash(sl.x,sl.y)),x,y);
 const sx=x+7,sy=y+1.6,sw=18,sh=8.6;c.save();rr(c,sx,sy,sw,sh,.8);c.clip();
 const st=ag?ag.status||"":"";
 if(!ag){c.fillStyle="#070a12";c.fillRect(sx,sy,sw,sh)}
 else if(wait){c.fillStyle="#3a2606";c.fillRect(sx,sy,sw,sh);c.fillStyle="#f59e0b";c.font="bold 7px sans-serif";c.textAlign="center";c.textBaseline="middle";c.fillText(((now/400|0)%2)?"!":"?",sx+sw/2,sy+sh/2+.3)}
 else if(/^(stuck|error)/i.test(st)){c.fillStyle="#3b0d10";c.fillRect(sx,sy,sw,sh);c.fillStyle="#ff6b6b";for(let i=0;i<4;i++)c.fillRect(sx+1.4,sy+1.3+i*1.8,4+((i*5)%9),.9)}
 else if(busy){
  let q=c.createLinearGradient(sx,sy,sx,sy+sh);q.addColorStop(0,"#0b3a4a");q.addColorStop(1,"#062029");c.fillStyle=q;c.fillRect(sx,sy,sw,sh);
  const sc=(now/70)|0;for(let i=0;i<7;i++){const h=hash(sc+i,sl.x*7+sl.y),ln=3+(h%11),ind=(h>>5)%3*1.6;c.fillStyle=["#6ee7ff","#34d399","#fbbf24","#c4b5fd"][(h>>8)%4];c.globalAlpha=.9;c.fillRect(sx+1.2+ind,sy+.9+i*1.13,ln,.62)}c.globalAlpha=1;
  c.fillStyle="rgba(255,255,255,.28)";c.fillRect(sx,sy+((now/90)%sh),sw,.7);c.fillStyle="rgba(180,240,255,.8)";c.fillRect(sx+sw-2.2,sy+sh-1.9,1,1.2*(((now/300)|0)%2))}
 else{let q=c.createLinearGradient(sx,sy,sx+sw,sy+sh);q.addColorStop(0,"#10264a");q.addColorStop(1,"#1b1740");c.fillStyle=q;c.fillRect(sx,sy,sw,sh);c.strokeStyle="rgba(110,231,255,.55)";c.lineWidth=.5;c.beginPath();c.arc(sx+sw/2,sy+sh/2,2.2,0,7);c.stroke();c.fillStyle="rgba(110,231,255,.5)";c.fillRect(sx+sw/2-.5,sy+sh/2-2.6,1,1.4)}
 c.fillStyle="rgba(255,255,255,.10)";c.beginPath();c.moveTo(sx,sy);c.lineTo(sx+8,sy);c.lineTo(sx+2,sy+sh);c.lineTo(sx,sy+sh);c.fill();c.restore()}

/* ------------------------------------------------------------ chairs */
function pChairSeat(g,col,big){
 const s=big?1.12:1;g.save();g.translate(16,0);g.scale(s,s);g.translate(-16,big?-1.5:0);
 g.fillStyle="#10141f";[[16,26.6],[9.5,24.3],[22.5,24.3],[11.5,28.4],[20.5,28.4]].forEach((p,i)=>{if(i)g.fillRect(16,23.5,0,0);g.beginPath();g.arc(p[0],p[1],1.2,0,7);g.fill()});
 g.strokeStyle="#262e44";g.lineWidth=1.3;g.beginPath();[[9.5,24.3],[22.5,24.3],[11.5,28.4],[20.5,28.4]].forEach(p=>{g.moveTo(16,22.5);g.lineTo(p[0],p[1])});g.stroke();
 g.fillStyle="#323b54";g.fillRect(15,18,2,5);
 g.fillStyle=vgrad(g,11,24,[[0,mixc(col,"#2a3148",.5)],[1,"#1b2132"]]);g.beginPath();g.roundRect(7.8,12.4,16.4,11.4,4);g.fill();
 g.strokeStyle="rgba(255,255,255,.3)";g.lineWidth=.6;g.beginPath();g.roundRect(7.8,12.4,16.4,11.4,4);g.stroke();g.strokeStyle=rgba(col,.85);g.lineWidth=.7;g.beginPath();g.roundRect(9.3,14,13.4,8.2,3);g.stroke();
 g.restore()}
function pChairBack(g,col,big){
 const s=big?1.12:1;g.save();g.translate(16,0);g.scale(s,s);g.translate(-16,big?-1.5:0);
 g.fillStyle=hgrad(g,8,24,[[0,mixc(col,"#242b40",.55)],[.5,mixc(col,"#303a56",.4)],[1,"#161b2a"]]);g.beginPath();g.roundRect(8,11,16,13,3.5);g.fill();
 g.fillStyle="rgba(255,255,255,.18)";g.beginPath();g.roundRect(9,11.6,5,11,2);g.fill();
 g.strokeStyle=rgba(col,.9);g.lineWidth=.8;g.beginPath();g.roundRect(8.1,11.1,15.8,12.8,3.4);g.stroke();
 g.fillStyle="#10141f";g.fillRect(10,22.5,12,1.3);
 g.restore()}
function chairDraw(c,sl,col,part,s,big){
 if(WL()){if(part)return;const x=sl.x*T+16,y=(sl.y+1)*T+10;c.beginPath();c.arc(x,y,7,0,7);c.fillStyle="#eef0f3";c.fill();c.strokeStyle="#d0d5dd";c.lineWidth=1;c.stroke();return}
 const x=sl.x*T,y=(sl.y+1)*T,key=(part?"cb":"cs")+col+(big?"B":"");
 const spr_=PSPR(key,32,32,0,g=>part?pChairBack(g,col,big):pChairSeat(g,col,big));
 blit(c,spr_,x,y+(part?0:0));
 if(!part)return}

/* ------------------------------------------------------------ consoles / racks */
function pConsole(g,v){
 g.fillStyle=vgrad(g,2,30,[[0,"#566280"],[.06,"#3c4660"],[1,"#1c2233"]]);g.beginPath();g.roundRect(1,3,30,27,2);g.fill();
 g.fillStyle="rgba(255,255,255,.35)";g.fillRect(2,3.2,28,.7);g.fillStyle="rgba(0,0,0,.45)";g.fillRect(1,29.2,30,.8);
 if(v==2){/* server rack */
  g.fillStyle="#0a0d16";g.fillRect(3,5,26,22);for(let i=0;i<5;i++){g.fillStyle=vgrad(g,5+i*4.4,9+i*4.4,[[0,"#2a3350"],[1,"#171c2e"]]);g.fillRect(3.6,5.6+i*4.3,24.8,3.6);g.fillStyle="#0b0e18";for(let k=0;k<6;k++)g.fillRect(14+k*2.4,6.5+i*4.3,1.7,1.5)}
  g.fillStyle="rgba(255,255,255,.07)";g.fillRect(3,5,3,22)}
 else{g.fillStyle="#0a0d16";g.beginPath();g.roundRect(3.6,6,24.8,14.4,1.5);g.fill();g.fillStyle="#05080f";g.fillRect(4.6,7,22.8,12.4);
  g.strokeStyle="rgba(255,255,255,.22)";g.lineWidth=.5;g.beginPath();g.roundRect(3.6,6,24.8,14.4,1.5);g.stroke();
  g.fillStyle="#12182a";g.beginPath();g.roundRect(4,22,24,6.5,1);g.fill();for(let i=0;i<6;i++){g.fillStyle=["#34d399","#f59e0b","#6ee7ff","#34d399","#ef4444","#6ee7ff"][i];g.beginPath();g.arc(7+i*3.5,25.2,.9,0,7);g.fill()}
  g.fillStyle="#2b3450";g.fillRect(24,23,3,1.2);g.fillRect(24,25.2,3,1.2)}}
function consoleSprite(v){return PSPR("con"+v,32,32,0,g=>pConsole(g,v))}
function conDraw(c,p,now){
 const x=p.x*T,y=p.y*T,v=p.seed%3;blit(c,consoleSprite(v),x,y);
 const t=now/1000;
 if(v==2){for(let i=0;i<5;i++)for(let k=0;k<3;k++){const on=((now/(260+k*90)+i*3+p.seed)|0)%5;c.fillStyle=on==0?"#ff5d5d":on<3?"#34d399":"#1c5d46";c.fillRect(x+5+k*2.2,y+7.3+i*4.3,1.2,1.2)}return}
 const sx=x+4.6,sy=y+7,sw=22.8,sh=12.4,col=["#2dd4f0","#34d399","#f59e0b"][p.seed%3];
 c.save();rr(c,sx,sy,sw,sh,.6);c.clip();
 let q=c.createLinearGradient(sx,sy,sx,sy+sh);q.addColorStop(0,mixc(col,"#000000",.78));q.addColorStop(1,mixc(col,"#000000",.9));c.fillStyle=q;c.fillRect(sx,sy,sw,sh);
 c.strokeStyle="rgba(255,255,255,.07)";c.lineWidth=.3;for(let i=1;i<4;i++){c.beginPath();c.moveTo(sx,sy+i*3.1);c.lineTo(sx+sw,sy+i*3.1);c.stroke()}
 c.strokeStyle=col;c.lineWidth=.8;c.beginPath();for(let i=0;i<=22;i++){const yy=sy+sh/2+Math.sin(t*2.4+i*.55+p.seed)*3.2*Math.sin(t*.7+i*.2)+Math.sin(i*1.7+t)*1;i?c.lineTo(sx+i,yy):c.moveTo(sx+i,yy)}c.stroke();
 c.fillStyle=rgba(col,.9);for(let i=0;i<5;i++){const h=2+((Math.sin(t*1.5+i*1.3+p.seed)+1)*2.5);c.fillRect(sx+16.4+i*1.2,sy+sh-1-h,.8,h)}
 c.fillStyle=rgba(col,.7);c.fillRect(sx+1.2,sy+1.2,8,.7);c.fillRect(sx+1.2,sy+2.6,5,.7);
 if(((now/400+p.seed)|0)%11==0){c.fillStyle="rgba(255,255,255,.18)";c.fillRect(sx,sy,sw,sh)}
 c.fillStyle="rgba(255,255,255,.08)";c.beginPath();c.moveTo(sx,sy);c.lineTo(sx+9,sy);c.lineTo(sx+3,sy+sh);c.lineTo(sx,sy+sh);c.fill();c.restore()}

/* ------------------------------------------------------------ boss command table */
function pBoss(g){
 g.fillStyle=vgrad(g,2,32,[[0,"#4b5486"],[1,"#232850"]]);g.beginPath();g.moveTo(0,10);g.quadraticCurveTo(48,-3,96,10);g.lineTo(96,28);g.quadraticCurveTo(48,36,0,28);g.closePath();g.fill();
 g.strokeStyle="rgba(255,255,255,.5)";g.lineWidth=.8;g.beginPath();g.moveTo(1,10.5);g.quadraticCurveTo(48,-2.5,95,10.5);g.stroke();
 g.fillStyle=vgrad(g,10,30,[[0,"#7a85c4"],[.4,"#4d5896"],[1,"#262c58"]]);g.beginPath();g.moveTo(2,12);g.quadraticCurveTo(48,0,94,12);g.lineTo(94,22);g.quadraticCurveTo(48,31,2,22);g.closePath();g.fill();
 g.fillStyle="rgba(255,255,255,.14)";g.beginPath();g.moveTo(8,13);g.quadraticCurveTo(30,6,50,6);g.lineTo(50,10);g.quadraticCurveTo(30,11,10,18);g.fill();
 g.strokeStyle="rgba(167,139,250,.95)";g.lineWidth=1;g.beginPath();g.moveTo(2,25.4);g.quadraticCurveTo(48,34,94,25.4);g.stroke();
 g.fillStyle="rgba(0,0,0,.35)";g.beginPath();g.moveTo(1,28);g.quadraticCurveTo(48,36,95,28);g.lineTo(95,29.5);g.quadraticCurveTo(48,37.5,1,29.5);g.fill();
 for(let i=0;i<3;i++){const bx=16+i*32;g.fillStyle="#0c0f20";g.beginPath();g.roundRect(bx,14,16,7,1.2);g.fill();g.fillStyle="#2a3270";for(let k=0;k<6;k++)g.fillRect(bx+1.4+k*2.3,15,1.7,.9)}}
function bossDraw(c,p,now){
 const x=p.x*T,y=p.y*T,s=PSPR("boss",96,32,0,pBoss);blit(c,s,x,y);
 const t=now/1000,cx=x+48,cy=y+13;
 /* three floating holo screens */
 [[x+14,0],[x+48,1],[x+82,2]].forEach(([hx_,i])=>{const w=i==1?22:17,h=i==1?13:10,hy=y-8-(i==1?4:0)+Math.sin(t*1.4+i)*.9,col=["#a78bfa","#6ee7ff","#c4b5fd"][i];
  c.save();c.translate(hx_,hy);c.fillStyle=rgba(col,.12);rr(c,-w/2,-h/2,w,h,2);c.fill();c.strokeStyle=rgba(col,.9);c.lineWidth=.8;c.stroke();c.fillStyle=rgba(col,.8);
  for(let k=0;k<4;k++){const ln=3+(hash(((t*2)|0)+k+i,3)%(w-6));c.fillRect(-w/2+2,-h/2+2+k*2.3,ln,.8)}
  c.fillStyle="rgba(255,255,255,.35)";c.fillRect(-w/2,-h/2+((t*8+i*3)%h),w,.6);c.restore()});
 /* hologram projector: rotating wireframe */
 c.save();c.translate(cx,cy-8);const g_=c.createLinearGradient(0,10,0,-12);g_.addColorStop(0,"rgba(167,139,250,.5)");g_.addColorStop(1,"rgba(167,139,250,0)");c.fillStyle=g_;c.beginPath();c.moveTo(-8,10);c.lineTo(8,10);c.lineTo(12,-12);c.lineTo(-12,-12);c.fill();
 c.strokeStyle="rgba(196,181,253,.95)";c.lineWidth=.7;for(let k=0;k<3;k++){c.beginPath();c.ellipse(0,-1,9*Math.abs(Math.cos(t*1.2+k*1.05)),9,0,0,7);c.stroke()}c.beginPath();c.ellipse(0,-1,9,2.6,0,0,7);c.stroke();
 c.fillStyle="rgba(196,181,253,.95)";c.beginPath();c.arc(Math.cos(t*2)*9,-1+Math.sin(t*2)*2.6,1,0,7);c.fill();c.restore()}

/* ------------------------------------------------------------ pillar */
function pPillar(g){
 g.fillStyle=vgrad(g,0,10,[[0,"#7b87a6"],[1,"#4b5674"]]);g.beginPath();g.ellipse(16,7,8.4,3.6,0,0,7);g.fill();
 g.fillStyle=hgrad(g,7,25,[[0,"#8793b1"],[.3,"#566280"],[1,"#232a3f"]]);g.fillRect(8,7,16,36);
 g.fillStyle=vgrad(g,7,12,[[0,"#a1adc8"],[1,"#667291"]]);g.beginPath();g.ellipse(16,7,8,3.2,0,0,7);g.fill();
 g.fillStyle="#10141f";g.beginPath();g.roundRect(13,12,6,26,3);g.fill();
 g.fillStyle=hgrad(g,6,26,[[0,"#7a86a6"],[.5,"#4b5674"],[1,"#1e2538"]]);g.beginPath();g.ellipse(16,44,10.5,4,0,0,7);g.fill();g.fillStyle="rgba(255,255,255,.25)";g.beginPath();g.ellipse(16,43,10,3.2,0,Math.PI,Math.PI*2);g.fill();
 g.fillStyle="rgba(0,0,0,.4)";g.fillRect(8,42,16,1)}
function pillarDraw(c,p,now){
 const x=p.x*T,y=p.y*T,s=LS(PSPR("pillar",32,44,6,pPillar));c.drawImage(s,x,y-12-s.pad+ -1,32,s.hu);
 const k=.55+.45*Math.sin(now/700+p.x),col=((now/3000|0)+p.x)%2?"#6ee7ff":"#a78bfa";
 c.fillStyle=rgba(col,.55+.45*k);c.beginPath();c.roundRect(x+14.2,y-2,3.6,24,1.8);c.fill();c.fillStyle="rgba(255,255,255,"+(.5*k)+")";c.fillRect(x+15.3,y-1,1.4,22);
 for(let i=0;i<4;i++){const yy=y+(((now/40)+i*20)%24)-2;c.fillStyle="rgba(255,255,255,.8)";c.fillRect(x+15.4,yy,1.2,1.2)}}

/* ------------------------------------------------------------ plant */
function pPlant(g,v){
 g.fillStyle=hgrad(g,8,24,[[0,"#8a5a3c"],[.4,"#b07a52"],[1,"#5a3a24"]]);g.beginPath();g.moveTo(9,18);g.lineTo(23,18);g.lineTo(21,29.5);g.quadraticCurveTo(16,31.5,11,29.5);g.closePath();g.fill();
 g.fillStyle="#c28c62";g.beginPath();g.ellipse(16,18,7.2,2.2,0,0,7);g.fill();g.fillStyle="#2b1a10";g.beginPath();g.ellipse(16,18,6,1.6,0,0,7);g.fill();
 const r=R32(v*13+5);
 for(let i=0;i<11;i++){const an=-Math.PI/2+(i-5)*.34+(r()-.5)*.2,len=11+r()*9,x0=16,y0=18,x1=x0+Math.cos(an)*len,y1=y0+Math.sin(an)*len-r()*3;
  g.save();g.translate(x0,y0);g.rotate(an+Math.PI/2);const l=len;g.fillStyle=hgrad(g,-3,3,[[0,mixc("#2f9e5a","#000000",.25+r()*.1)],[1,mixc("#58d58a","#ffffff",.0)]]);g.beginPath();g.moveTo(0,0);g.quadraticCurveTo(-4.6,-l*.45,0,-l);g.quadraticCurveTo(4.6,-l*.45,0,0);g.fill();
  g.strokeStyle="rgba(255,255,255,.35)";g.lineWidth=.4;g.beginPath();g.moveTo(0,0);g.lineTo(0,-l*.92);g.stroke();g.restore()}
 g.fillStyle="rgba(255,255,255,.3)";g.beginPath();g.ellipse(13,19.5,1.4,.5,0,0,7);g.fill()}
function plantDraw(c,p){const s=PSPR("plant"+(p.seed||0)%3,32,32,0,g=>pPlant(g,(p.seed||0)%3));blit(c,s,p.x*T,p.y*T-2)}

/* ------------------------------------------------------------ crate */
function pCrate(g,v){
 g.fillStyle=vgrad(g,6,30,[[0,"#8a7656"],[1,"#5a4a34"]]);g.beginPath();g.roundRect(1.5,8,29,22,1.5);g.fill();
 g.fillStyle=vgrad(g,5,13,[[0,"#b39d78"],[1,"#8a7656"]]);g.beginPath();g.moveTo(1.5,10);g.lineTo(4,5);g.lineTo(28,5);g.lineTo(30.5,10);g.closePath();g.fill();
 g.strokeStyle="rgba(0,0,0,.35)";g.lineWidth=.7;g.strokeRect(1.5,8,29,22);for(let i=0;i<4;i++){g.fillStyle="rgba(0,0,0,.18)";g.fillRect(3,12+i*4.5,26,.8)}
 g.fillStyle="#2f2618";g.fillRect(1.5,14,29,2.4);g.fillRect(14,8,4,22);g.fillStyle="rgba(255,255,255,.18)";g.fillRect(1.5,8,29,.8);
 [[3.5,10],[28.5,10],[3.5,28],[28.5,28]].forEach(p=>rivet(g,p[0],p[1],.9));
 if(v==0){g.fillStyle="#e8e4d4";g.fillRect(19,20,9,5.5);g.fillStyle="#222";g.fillRect(20,21.2,5,.8);g.fillRect(20,23,7,.6);g.fillStyle="#d9a21b";g.fillRect(4,22,8,5);g.fillStyle="#15181f";for(let i=0;i<3;i++){g.beginPath();g.moveTo(4+i*3,27);g.lineTo(6+i*3,27);g.lineTo(8+i*3,22);g.lineTo(6+i*3,22);g.fill()}}
 else{g.fillStyle="#ef4444";g.beginPath();g.arc(8,23,3,0,7);g.fill();g.fillStyle="#fff";g.fillRect(6.2,22.4,3.6,1.2)}}
function crateDraw(c,p){blit(c,PSPR("crate"+(p.seed?1:0),32,32,0,g=>pCrate(g,p.seed?1:0)),p.x*T,p.y*T)}

/* ------------------------------------------------------------ conveyor + bin */
function beltDraw(c,p,now){
 const x=p.x*T,y=p.y*T,s=PSPR("belt",32,32,0,g=>{
  g.fillStyle=vgrad(g,6,30,[[0,"#4a5570"],[1,"#232a3d"]]);g.beginPath();g.roundRect(0,6,32,24,1.5);g.fill();
  g.fillStyle=vgrad(g,7,11,[[0,"#8793b1"],[1,"#566280"]]);g.fillRect(0,6,32,4);g.fillStyle=vgrad(g,25,30,[[0,"#566280"],[1,"#2b3348"]]);g.fillRect(0,25,32,5);
  g.fillStyle="#0e121c";g.fillRect(0,10,32,15);g.fillStyle="rgba(255,255,255,.12)";g.fillRect(0,10,32,.8);g.fillStyle="rgba(0,0,0,.45)";g.fillRect(0,24.2,32,.8)});
 blit(c,s,x,y);
 const off=(now/55)%8;c.save();c.beginPath();c.rect(x,y+10,32,15);c.clip();
 for(let i=-1;i<5;i++){const rx=x+i*8+off;c.fillStyle=vgrad_(c,y+10,y+25,"#3b4560","#1a2030");c.fillRect(rx,y+10.5,5.6,14);c.fillStyle="rgba(255,255,255,.12)";c.fillRect(rx,y+10.5,1,14);c.fillStyle=rgba("#f59e0b",.8);c.fillRect(rx+3.2,y+11.5,.8,12)}
 c.restore();c.fillStyle="rgba(245,158,11,.9)";for(let i=0;i<4;i++)c.fillRect(x+3+i*8,y+27.4,2,1)}
function vgrad_(c,y0,y1,a,b){const q=c.createLinearGradient(0,y0,0,y1);q.addColorStop(0,a);q.addColorStop(1,b);return q}
function pBin(g){
 g.fillStyle=vgrad(g,4,30,[[0,"#5a6684"],[1,"#262d42"]]);g.beginPath();g.roundRect(1,6,30,24,2);g.fill();
 g.fillStyle=vgrad(g,4,10,[[0,"#9aa7c4"],[1,"#667291"]]);g.beginPath();g.roundRect(0.5,4,31,7,2);g.fill();
 g.fillStyle="#080b14";g.beginPath();g.roundRect(5,8,22,10,1.5);g.fill();
 g.fillStyle="rgba(255,255,255,.3)";g.fillRect(1,6,30,.7);g.fillStyle="rgba(0,0,0,.4)";g.fillRect(1,29,30,1);
 g.fillStyle="#12182a";g.fillRect(5,21,22,6);g.fillStyle="#34d399";for(let i=0;i<4;i++)g.fillRect(7+i*5,23,3.5,2)}
function binDraw(c,p,now){
 const x=p.x*T,y=p.y*T;blit(c,PSPR("bin",32,32,0,pBin),x,y);
 const fl=p.flash&&p.flash>now?(p.flash-now)/600:0,sc=((now/500)%1);
 c.fillStyle=rgba("#34d399",.35+fl*.6);c.fillRect(x+5,y+8+sc*8,22,1);if(fl>0){c.fillStyle=rgba("#34d399",fl*.5);c.fillRect(x+5,y+8,22,10)}}

/* ------------------------------------------------------------ break room */
function pCouch(g,col){
 const c0=mixc(col,"#3a2a22",.55);
 g.fillStyle=hgrad(g,0,32,[[0,shade(c0,-.25)],[.5,c0],[1,shade(c0,-.3)]]);g.beginPath();g.roundRect(1,4,30,12,4);g.fill();
 g.fillStyle="rgba(255,255,255,.18)";g.beginPath();g.roundRect(3,4.6,26,3,2);g.fill();
 g.fillStyle=vgrad(g,14,27,[[0,shade(c0,.1)],[1,shade(c0,-.22)]]);g.beginPath();g.roundRect(5,14,22,12.4,3.4);g.fill();
 g.strokeStyle="rgba(0,0,0,.35)";g.lineWidth=.6;g.beginPath();g.moveTo(16,14.5);g.lineTo(16,26);g.stroke();g.strokeStyle="rgba(255,255,255,.12)";g.beginPath();g.roundRect(5.5,14.5,21,11.4,3);g.stroke();
 [[1,8],[24.5,8]].forEach(([ax])=>{g.fillStyle=hgrad(g,ax,ax+6.5,[[0,shade(c0,.15)],[1,shade(c0,-.35)]]);g.beginPath();g.roundRect(ax,8,6.5,19.5,3);g.fill();g.fillStyle="rgba(255,255,255,.2)";g.fillRect(ax+.8,8.8,4.8,.7)});
 g.fillStyle="rgba(0,0,0,.35)";g.fillRect(2,27.5,28,1.2);g.fillStyle="#2a2f40";g.fillRect(3,28,2.5,2);g.fillRect(26.5,28,2.5,2)}
function couchDraw(c,p){blit(c,PSPR("couch"+p.col,32,32,0,g=>pCouch(g,p.col||"#6ee7ff")),p.x*T,p.y*T)}
function pCoffee(g){
 g.fillStyle=hgrad(g,5,27,[[0,"#8793b1"],[.4,"#5a6684"],[1,"#2a3248"]]);g.beginPath();g.roundRect(6,2,20,27,2.4);g.fill();
 g.fillStyle=vgrad(g,2,8,[[0,"#aab6d2"],[1,"#6a7694"]]);g.beginPath();g.roundRect(6,2,20,6,2.4);g.fill();
 g.fillStyle="#080b14";g.beginPath();g.roundRect(9.4,10,13,8,1.2);g.fill();g.fillStyle="#1b2132";g.fillRect(9,19.6,14,2.2);
 g.fillStyle="#e8e8f0";g.beginPath();g.moveTo(12.6,22);g.lineTo(19.4,22);g.lineTo(18.4,27.6);g.lineTo(13.6,27.6);g.fill();g.fillStyle="#2a1a10";g.fillRect(13,22.3,6,1.3);
 g.fillStyle="rgba(0,0,0,.4)";g.fillRect(6,28.4,20,1.2);g.fillStyle="#ef4444";g.beginPath();g.arc(23.6,5,1,0,7);g.fill()}
function coffeeDraw(c,p,now){
 const x=p.x*T,y=p.y*T;blit(c,PSPR("coffee",32,32,0,pCoffee),x,y);
 c.fillStyle=((now/700)|0)%2?"#f59e0b":"#a56a12";c.fillRect(x+10.4,y+11,11,3);c.fillStyle="rgba(255,255,255,.35)";c.fillRect(x+10.4,y+11,11,.6);
 c.fillStyle="#34d399";c.fillRect(x+10.6,y+15.4,2,1);c.fillStyle="#6ee7ff";c.fillRect(x+13.6,y+15.4,2,1);
 for(let i=0;i<3;i++){const k=((now/900)+i/3)%1;c.fillStyle="rgba(255,255,255,"+(.4*(1-k))+")";c.beginPath();c.arc(x+16+Math.sin(k*6+i)*1.8,y+22-k*14,1+k*2,0,7);c.fill()}}
function pTable(g){
 g.fillStyle="#2a1a10";g.beginPath();g.ellipse(32,25,22,5,0,0,7);g.fill();g.fillStyle=hgrad(g,28,36,[[0,"#4a3a2e"],[1,"#2a1e16"]]);g.fillRect(28.5,17,7,9);
 g.fillStyle=vgrad(g,6,24,[[0,"#d9b88a"],[.5,"#b88e5e"],[1,"#8a6540"]]);g.beginPath();g.ellipse(32,15,30,10,0,0,7);g.fill();g.strokeStyle="rgba(255,255,255,.35)";g.lineWidth=.8;g.beginPath();g.ellipse(32,14.4,29.4,9.4,0,Math.PI*1.05,Math.PI*1.95);g.stroke();
 g.fillStyle="rgba(0,0,0,.22)";g.beginPath();g.ellipse(32,18.4,29,7.2,0,.15,Math.PI-.15);g.fill();g.fillStyle="rgba(255,255,255,.13)";g.beginPath();g.ellipse(22,10,11,3,-.15,0,7);g.fill();
 g.fillStyle="#e8e8f0";g.beginPath();g.roundRect(24,6,6,7,1.2);g.fill();g.fillStyle="#f59e0b";g.fillRect(24.6,7.4,4.8,2);g.fillStyle="#e8e8f0";g.beginPath();g.roundRect(37,8,6,7,1.2);g.fill();g.fillStyle="#34d399";g.fillRect(37.6,9.4,4.8,2)}
function tableDraw(c,p){if(p.seed===1)return;blit(c,PSPR("table",64,32,0,pTable),p.x*T,p.y*T)}

/* ------------------------------------------------------------ dispatch */
const PLAN_HIDE=["con","crate","belt","bin","pillar"];
function flatProp(c,p){const x=p.x*T,y=p.y*T;
 if(p.t=="plant"){rr(c,x+11,y+18,10,8,2);c.fillStyle="#d0d5dd";c.fill();[[16,13,7,"#9db39a"],[11,15,5,"#8aa588"],[21,15,5,"#8aa588"]].forEach(([a,b,r,cl])=>{c.beginPath();c.arc(x+a,y+b,r,0,7);c.fillStyle=cl;c.fill()});return true}
 if(p.t=="couch"){rr(c,x+3,y+8,26,15,5);c.fillStyle="#eef0f3";c.fill();c.strokeStyle="#d0d5dd";c.lineWidth=1;c.stroke();rr(c,x+5,y+8,22,5,3);c.fillStyle="#e4e7ec";c.fill();return true}
 if(p.t=="coffee"){rr(c,x+9,y+6,14,16,3);c.fillStyle="#e4e7ec";c.fill();c.strokeStyle="#c9cfd8";c.lineWidth=1;c.stroke();c.beginPath();c.arc(x+16,y+15,3,0,7);c.fillStyle="#98a2b3";c.fill();return true}
 if(p.t=="table"){if(p.seed===1)return true;rr(c,x+4,y+8,56,15,7);c.fillStyle="#ffffff";c.fill();c.strokeStyle="#d0d5dd";c.lineWidth=1;c.stroke();return true}
 return false}
function propDraw(c,p,now){
 if(WL()&&PLAN_HIDE.includes(p.t))return;
 if(WL()&&flatProp(c,p))return;
 switch(p.t){case"con":return conDraw(c,p,now);case"boss":return bossDraw(c,p,now);case"pillar":return pillarDraw(c,p,now);case"plant":return plantDraw(c,p);
  case"crate":return crateDraw(c,p);case"belt":return beltDraw(c,p,now);case"bin":return binDraw(c,p,now);case"couch":return couchDraw(c,p);case"coffee":return coffeeDraw(c,p,now);case"table":return tableDraw(c,p);case"mtable":return mtableDraw(c,p)}}
function propShadow(c,p){
 if(WL()&&p.t!="boss")return;const x=p.x*T,y=p.y*T;
 switch(p.t){case"con":softShadow(c,x+3,y+24,28,10,.5,1.4);break;case"boss":softShadow(c,x+3,y+18,(p.w||3)*32-4,16,.55,2.2);break;case"pillar":softShadow(c,x+4,y+26,24,12,.6,2);break;case"plant":softShadow(c,x+8,y+26,18,7,.5,1.4);break;
  case"crate":softShadow(c,x+3,y+24,28,10,.55,1.6);break;case"bin":softShadow(c,x+3,y+26,28,8,.5,1.4);break;case"couch":softShadow(c,x+3,y+22,28,12,.5,1.6);break;case"coffee":softShadow(c,x+7,y+25,18,8,.5,1.4);break;case"table":if(p.seed!==1)softShadow(c,x+6,y+22,58,12,.5,2);break}}
function propLights(p,L,now){
 const x=p.x*T,y=p.y*T;
 if(p.t=="con")L.push({x:x+16,y:y+14,r:56,col:["#2dd4f0","#34d399","#f59e0b"][p.seed%3],a:.34});
 else if(p.t=="boss"){const hw=(p.w||3)*16;L.push({x:x+hw,y:y+8,r:150,col:"#a78bfa",a:.6});L.push({x:x+hw,y:y-8,r:70,col:"#6ee7ff",a:.28});L.push({x:x+hw-60,y:y+10,r:50,col:"#f5c542",a:.22});L.push({x:x+hw+60,y:y+10,r:50,col:"#f5c542",a:.22})}
 else if(p.t=="pillar")L.push({x:x+16,y:y+10,r:78,col:((now/3000|0)+p.x)%2?"#6ee7ff":"#a78bfa",a:.38+.12*Math.sin(now/700+p.x)});
 else if(p.t=="coffee")L.push({x:x+16,y:y+14,r:34,col:"#f59e0b",a:.28});
 else if(p.t=="bin")L.push({x:x+16,y:y+12,r:42,col:"#34d399",a:.26});
 else if(p.t=="belt")L.push({x:x+16,y:y+18,r:30,col:"#f59e0b",a:.10});
 else if(p.t=="table"&&p.seed!==1)L.push({x:x+32,y:y+10,r:50,col:"#ffd9a0",a:.22})}

/* ------------------------------------------------------------ parcels (shipping animation) */
function drawParcel(c,p,now){
 const k=(now-p.t0)/p.dur,x=(p.x0+(p.x1-p.x0)*Math.min(1,k))*T+4,y=p.y*T+9-Math.sin(k*Math.PI)*2;
 softShadow(c,x+1,y+11,22,5,.4,1);
 c.fillStyle=vgrad_(c,y,y+14,"#c9a26a","#8c6a3c");c.beginPath();c.roundRect(x,y,24,14,1.5);c.fill();
 c.fillStyle="rgba(255,255,255,.28)";c.fillRect(x,y,24,2);c.fillStyle="#e9d8a8";c.fillRect(x+10,y,4,14);c.fillStyle="#fff";c.fillRect(x+15,y+7,7,5);c.fillStyle="#333";c.fillRect(x+16,y+8,5,.7);c.fillRect(x+16,y+9.6,4,.6);
 c.strokeStyle="rgba(0,0,0,.3)";c.lineWidth=.6;c.strokeRect(x,y,24,14)}
/* ======================================================================
   part 4: characters. Fully procedural shaded humanoids, rendered once per
   pose into a 1.7x sprite (walk cycle, idle, sitting, typing) with an
   outline, then drawn smoothly at any zoom.
   ====================================================================== */
const CW=84,CH=124,CK=1.7,CF=.40; /* design size, render scale, design->world scale */
const CC=new Map();
function limb(g,x1,y1,x2,y2,w,c1,c2,hi){g.lineCap="round";g.lineJoin="round";g.strokeStyle=c1;g.lineWidth=w;g.beginPath();g.moveTo(x1,y1);g.lineTo(x2,y2);g.stroke();
 if(hi!==false){g.strokeStyle=c2;g.globalAlpha=.55;g.lineWidth=w*.34;g.beginPath();g.moveTo(x1-w*.2,y1);g.lineTo(x2-w*.2,y2);g.stroke();g.globalAlpha=1}}
function ell(g,x,y,rx,ry,fill,rot){g.fillStyle=fill;g.beginPath();g.ellipse(x,y,rx,ry,rot||0,0,7);g.fill()}
function boot(g,x,y,dir,w,tr,tr2,back){/* foot at ankle (x,y); dir: 0 front,1 back,-1 left,+1 right */
 if(dir==0||dir==1){g.fillStyle=vgrad(g,y-2,y+7,[[0,"#3a4258"],[1,"#12151f"]]);g.beginPath();g.roundRect(x-w/2,y-2,w,8.4,3);g.fill();
  if(dir==0){g.fillStyle=tr;g.beginPath();g.roundRect(x-w/2+.8,y+2.6,w-1.6,3.4,2);g.fill();g.fillStyle="rgba(255,255,255,.3)";g.fillRect(x-w/2+1.5,y-1.5,w-3,.8)}else{g.fillStyle=tr2;g.fillRect(x-w/2+1,y+4,w-2,1.6)}
  g.fillStyle="#07090f";g.fillRect(x-w/2,y+5.6,w,1.1)}
 else{const f=dir;g.fillStyle=vgrad(g,y-3,y+6,[[0,"#3a4258"],[1,"#12151f"]]);g.beginPath();g.moveTo(x-f*3.5,y-3);g.lineTo(x+f*3,y-3);g.lineTo(x+f*3.4,y+1);g.quadraticCurveTo(x+f*12,y+1.5,x+f*12,y+5.2);g.lineTo(x-f*4.2,y+5.8);g.closePath();g.fill();
  g.fillStyle=tr;g.beginPath();g.moveTo(x+f*6,y+1.4);g.quadraticCurveTo(x+f*12,y+1.8,x+f*12,y+5.2);g.lineTo(x+f*5,y+5.4);g.closePath();g.fill();g.fillStyle="#07090f";g.fillRect(Math.min(x-f*4.2,x+f*12),y+5.2,16.2,1.1)}}
function hand(g,x,y,sk,r){g.fillStyle=sk;g.beginPath();g.arc(x,y,r||3.4,0,7);g.fill();g.fillStyle="rgba(0,0,0,.16)";g.beginPath();g.arc(x+.6,y+.8,(r||3.4)*.7,0,Math.PI);g.fill()}

function paintHuman(g,L,dir,fr,sit,typing){
 const sk=L.skin,sk2=shade(sk,-.24),sk3=shade(sk,.14),hr=L.hair,hr2=shade(hr,-.38),hr3=shade(hr,.3),su=L.suit,su2=shade(su,-.34),su3=shade(su,.24),tr=L.trim,tr2=shade(tr,-.38),tr3=shade(tr,.25),tg=L.tag||"#6ee7ff";
 const st=L.style|0,ou=L.outfit|0,ac=L.acc|0,walking=!sit&&fr>0,ph=walking?(fr-1)/8*Math.PI*2:0;
 const dy=sit?24:0,bob=walking?-Math.abs(Math.cos(ph))*2.1:0,sway=walking?Math.sin(ph)*.7:0;
 const pants=ou==0?mixc(su,"#10131f",.12):mixc(su,"#141a2c",.72),pants2=shade(pants,-.3),pants3=shade(pants,.2);
 const sleeve=ou==0?su:ou==1?tr:ou==2?mixc(su,"#ffffff",.6):"#eef2fa",sleeve2=shade(sleeve,-.3),sleeve3=shade(sleeve,.2);
 const hipY=64+dy+bob,shY=34+dy+bob,hdY=17+dy+bob,cx=42+sway;
 const back=dir==1,side=dir==2;
 /* ---------- helpers bound to this pose ---------- */
 const torsoFront=()=>{
  const q=hgrad(g,cx-18,cx+18,[[0,su3],[.4,su],[1,su2]]);g.fillStyle=q;g.beginPath();g.moveTo(cx-17,shY+3);g.quadraticCurveTo(cx-17,shY-2.4,cx-10,shY-2.6);g.lineTo(cx+10,shY-2.6);g.quadraticCurveTo(cx+17,shY-2.4,cx+17,shY+3);g.lineTo(cx+14.2,hipY+1);g.quadraticCurveTo(cx,hipY+5.6,cx-14.2,hipY+1);g.closePath();g.fill();
  g.strokeStyle="rgba(255,255,255,.16)";g.lineWidth=.8;g.beginPath();g.moveTo(cx-16.2,shY+3);g.quadraticCurveTo(cx-16,shY-1.6,cx-10,shY-1.9);g.stroke();
  g.fillStyle="rgba(0,0,0,.14)";g.beginPath();g.moveTo(cx+9,shY-2);g.lineTo(cx+17,shY+3);g.lineTo(cx+14.2,hipY+1);g.lineTo(cx+8,hipY+3);g.closePath();g.fill()};
 const belt=()=>{g.fillStyle=vgrad(g,hipY-5,hipY+1,[[0,tr3],[1,tr2]]);g.beginPath();g.roundRect(cx-14.4,hipY-5.2,28.8,5.2,1.2);g.fill();if(!back){g.fillStyle="#d9dfef";g.fillRect(cx-2.6,hipY-4.6,5.2,4);g.fillStyle=tr2;g.fillRect(cx-1.4,hipY-3.6,2.8,2)}};
 const neckAndHead=()=>{
  g.fillStyle=vgrad(g,shY-9,shY-1,[[0,sk],[1,sk2]]);g.fillRect(cx-3.8,shY-9,7.6,8);g.fillStyle="rgba(0,0,0,.2)";g.fillRect(cx-3.8,shY-9,7.6,2.4);
  /* collar */
  if(ou==0||ou==1){g.fillStyle=ou==0?su3:"#e8eef8";g.beginPath();g.ellipse(cx,shY-2.4,9.2,3,0,0,Math.PI);g.fill();g.strokeStyle="rgba(0,0,0,.35)";g.lineWidth=.6;g.stroke()}
  else if(ou==3){g.fillStyle="#fafcff";g.beginPath();g.moveTo(cx-10,shY-2);g.lineTo(cx-4,shY+5);g.lineTo(cx-2,shY-4);g.closePath();g.fill();g.beginPath();g.moveTo(cx+10,shY-2);g.lineTo(cx+4,shY+5);g.lineTo(cx+2,shY-4);g.closePath();g.fill()}};
 /* ---------- arms ---------- */
 const armsFB=(before)=>{
  for(const i of [0,1]){const sg=i?1:-1,s=walking?Math.sin(ph+(i?0:Math.PI)):0,sx=cx+sg*17,sy=shY+3.5;
   let ex,ey,wx,wy;
   if(sit&&!back){ex=sx+sg*3.4;ey=sy+16;wx=cx+sg*11;wy=hipY+10;}
   else if(sit&&back){const j=typing?Math.sin(fr*1.9+i*2.2)*1.6:0;ex=sx+sg*(3.8+j*.3);ey=sy+14+j;wx=cx+sg*11;wy=sy+11;}
   else{ex=sx+sg*(3.6-s*.6);ey=sy+15+s*3.4;wx=sx+sg*(4.2-s*1.4);wy=sy+31+s*6.4}
   const behind=sit&&back; if(before!==behind)continue;
   limb(g,sx,sy,ex,ey,9.2,sleeve,sleeve3);limb(g,ex,ey,wx,wy,8.2,sleeve2,sleeve3,false);
   if(!(sit&&back)){g.fillStyle=ou==3?"#c8d2e6":tr;g.beginPath();g.ellipse(wx,wy-1.4,4.2,1.9,0,0,7);g.fill();hand(g,wx,wy+2.4,sk,3.6)}
   if(ou==0||ou==2){g.fillStyle=tr;g.beginPath();g.ellipse(sx,sy-1.2,5.6,3.4,0,Math.PI,Math.PI*2);g.fill()}}};
 /* ---------- head parts ---------- */
 const headFront=()=>{
  /* ears */
  ell(g,cx-12.4,hdY+1.4,2.4,3.4,sk2);ell(g,cx+12.4,hdY+1.4,2.4,3.4,sk2);
  const q=g.createRadialGradient(cx-4,hdY-6,2,cx,hdY,15);q.addColorStop(0,sk3);q.addColorStop(.6,sk);q.addColorStop(1,sk2);g.fillStyle=q;g.beginPath();g.ellipse(cx,hdY,12.2,13.4,0,0,7);g.fill();
  /* jaw shadow */g.fillStyle="rgba(0,0,0,.10)";g.beginPath();g.ellipse(cx,hdY+9.6,9,4,0,0,Math.PI);g.fill();
  /* eyes */
  for(const sg of[-1,1]){const ex=cx+sg*4.8,ey=hdY+1.4;ell(g,ex,ey,2.9,2.6,"#f4f6fb");g.fillStyle="#2a3050";g.beginPath();g.arc(ex+sg*.2,ey+.2,1.75,0,7);g.fill();g.fillStyle="#0a0d18";g.beginPath();g.arc(ex+sg*.2,ey+.2,.9,0,7);g.fill();g.fillStyle="#fff";g.fillRect(ex-.8,ey-.9,.9,.9);
   g.strokeStyle=st==5?sk2:hr2;g.lineWidth=1.3;g.lineCap="round";g.beginPath();g.moveTo(ex-sg*3,ey-3.4+sg*.2);g.quadraticCurveTo(ex,ey-4.6,ex+sg*3,ey-3.2);g.stroke();
   g.strokeStyle="rgba(0,0,0,.28)";g.lineWidth=.6;g.beginPath();g.arc(ex,ey,2.9,Math.PI*1.1,Math.PI*1.9);g.stroke()}
  g.strokeStyle=sk2;g.lineWidth=.9;g.lineCap="round";g.beginPath();g.moveTo(cx-.6,hdY+3.4);g.quadraticCurveTo(cx-1.8,hdY+6.6,cx+.2,hdY+7.2);g.stroke();
  g.strokeStyle=mixc(sk,"#8a3a3a",.6);g.lineWidth=1;g.beginPath();g.moveTo(cx-3.2,hdY+10.4);g.quadraticCurveTo(cx,hdY+12.2,cx+3.2,hdY+10.4);g.stroke();
  g.fillStyle="rgba(255,120,120,.12)";g.beginPath();g.arc(cx-8,hdY+6.6,2.6,0,7);g.arc(cx+8,hdY+6.6,2.6,0,7);g.fill()};
 const headBack=()=>{ell(g,cx-12.4,hdY+1.4,2.4,3.4,sk2);ell(g,cx+12.4,hdY+1.4,2.4,3.4,sk2);const q=g.createRadialGradient(cx-4,hdY-6,2,cx,hdY,15);q.addColorStop(0,sk);q.addColorStop(1,sk2);g.fillStyle=q;g.beginPath();g.ellipse(cx,hdY,12.2,13.4,0,0,7);g.fill()};
 const hairFront=()=>{
  if(st==5){g.fillStyle="rgba(255,255,255,.22)";g.beginPath();g.ellipse(cx-3,hdY-9,5,2.4,-.3,0,7);g.fill();return}
  if(st==4)return;
  if(st==3){/* cap */
   g.fillStyle=hr;g.beginPath();g.moveTo(cx-12.6,hdY-1);g.quadraticCurveTo(cx-13,hdY-9,cx-9,hdY-6);g.lineTo(cx-8,hdY+1);g.closePath();g.fill();g.beginPath();g.moveTo(cx+12.6,hdY-1);g.quadraticCurveTo(cx+13,hdY-9,cx+9,hdY-6);g.lineTo(cx+8,hdY+1);g.closePath();g.fill();
   g.fillStyle=hgrad(g,cx-14,cx+14,[[0,tr3],[.5,tr],[1,tr2]]);g.beginPath();g.moveTo(cx-13.4,hdY-4.4);g.quadraticCurveTo(cx-13,hdY-16.4,cx,hdY-16.6);g.quadraticCurveTo(cx+13,hdY-16.4,cx+13.4,hdY-4.4);g.quadraticCurveTo(cx,hdY-7.4,cx-13.4,hdY-4.4);g.fill();
   g.fillStyle=tr2;g.beginPath();g.ellipse(cx,hdY-4.6,15.5,3,0,0,Math.PI);g.fill();g.fillStyle=tr;g.beginPath();g.ellipse(cx,hdY-5.2,15,2.6,0,0,Math.PI);g.fill();g.fillStyle="rgba(255,255,255,.25)";g.beginPath();g.ellipse(cx-3,hdY-11,4,2,-.4,0,7);g.fill();g.fillStyle=tr2;g.beginPath();g.arc(cx,hdY-16.5,1.2,0,7);g.fill();return}
  const q=hgrad(g,cx-13,cx+13,[[0,hr3],[.45,hr],[1,hr2]]);g.fillStyle=q;
  if(st==1){/* long: locks in front of shoulders */
   g.beginPath();g.moveTo(cx-12.8,hdY-2);g.quadraticCurveTo(cx-16,hdY+18,cx-12,hdY+30);g.lineTo(cx-8,hdY+30);g.quadraticCurveTo(cx-9,hdY+14,cx-8.2,hdY+1);g.closePath();g.fill();
   g.beginPath();g.moveTo(cx+12.8,hdY-2);g.quadraticCurveTo(cx+16,hdY+18,cx+12,hdY+30);g.lineTo(cx+8,hdY+30);g.quadraticCurveTo(cx+9,hdY+14,cx+8.2,hdY+1);g.closePath();g.fill()}
  g.beginPath();g.moveTo(cx-12.9,hdY+1);g.quadraticCurveTo(cx-15,hdY-10.5,cx-7,hdY-14.2);g.quadraticCurveTo(cx,hdY-17.8,cx+7,hdY-14.2);g.quadraticCurveTo(cx+15,hdY-10.5,cx+12.9,hdY+1);
  g.quadraticCurveTo(cx+11,hdY-7.6,cx+5,hdY-8.6);g.quadraticCurveTo(cx+1,hdY-5.6,cx-4,hdY-8.6);g.quadraticCurveTo(cx-10.6,hdY-7.2,cx-12.9,hdY+1);g.fill();
  if(st==2){for(let i=0;i<5;i++){const x=cx-10+i*5,h=7+(i%2)*4;g.beginPath();g.moveTo(x-3,hdY-11);g.lineTo(x+.4,hdY-11-h);g.lineTo(x+3.4,hdY-11);g.closePath();g.fill()}}
  g.strokeStyle="rgba(255,255,255,.28)";g.lineWidth=.9;g.beginPath();g.moveTo(cx-9,hdY-10.8);g.quadraticCurveTo(cx-2,hdY-15.6,cx+5,hdY-13);g.stroke()};
 const hairBack=()=>{
  if(st==5||st==4)return;
  const q=hgrad(g,cx-13,cx+13,[[0,hr3],[.4,hr],[1,hr2]]);g.fillStyle=q;
  if(st==3){g.fillStyle=hr2;g.beginPath();g.ellipse(cx,hdY+2,12.6,10.6,0,0,Math.PI);g.fill();g.fillStyle=hgrad(g,cx-14,cx+14,[[0,tr3],[.5,tr],[1,tr2]]);g.beginPath();g.moveTo(cx-13.4,hdY-.4);g.quadraticCurveTo(cx-13,hdY-16.4,cx,hdY-16.6);g.quadraticCurveTo(cx+13,hdY-16.4,cx+13.4,hdY-.4);g.quadraticCurveTo(cx,hdY+2,cx-13.4,hdY-.4);g.fill();g.fillStyle=tr2;g.fillRect(cx-5,hdY-2,10,1.8);return}
  g.beginPath();g.moveTo(cx-13,hdY+3);g.quadraticCurveTo(cx-15.4,hdY-12,cx,hdY-17);g.quadraticCurveTo(cx+15.4,hdY-12,cx+13,hdY+3);g.quadraticCurveTo(cx+12,hdY+11,cx,hdY+12.6);g.quadraticCurveTo(cx-12,hdY+11,cx-13,hdY+3);g.fill();
  if(st==1){g.beginPath();g.moveTo(cx-13.4,hdY+3);g.quadraticCurveTo(cx-15,hdY+22,cx-11,hdY+31);g.lineTo(cx+11,hdY+31);g.quadraticCurveTo(cx+15,hdY+22,cx+13.4,hdY+3);g.fill()}
  if(st==2){for(let i=0;i<5;i++){const x=cx-10+i*5,h=7+(i%2)*4;g.beginPath();g.moveTo(x-3,hdY-11);g.lineTo(x+.4,hdY-11-h);g.lineTo(x+3.4,hdY-11);g.closePath();g.fill()}}
  g.strokeStyle="rgba(0,0,0,.22)";g.lineWidth=.8;g.beginPath();g.moveTo(cx,hdY-15);g.quadraticCurveTo(cx+1.4,hdY-4,cx,hdY+8);g.stroke();g.strokeStyle="rgba(255,255,255,.22)";g.beginPath();g.moveTo(cx-8,hdY-8);g.quadraticCurveTo(cx-4,hdY-14,cx+3,hdY-13);g.stroke()};
 const helmet=(frontFace)=>{
  const q=g.createRadialGradient(cx-6,hdY-8,2,cx,hdY,19);q.addColorStop(0,"rgba(210,244,255,.42)");q.addColorStop(.6,"rgba(130,210,245,.20)");q.addColorStop(1,"rgba(70,150,210,.30)");g.fillStyle=q;g.beginPath();g.arc(cx,hdY-.4,17.2,0,7);g.fill();
  g.strokeStyle="rgba(215,240,255,.95)";g.lineWidth=1.6;g.beginPath();g.arc(cx,hdY-.4,17.2,0,7);g.stroke();g.strokeStyle="rgba(255,255,255,.7)";g.lineWidth=1.8;g.beginPath();g.arc(cx,hdY-.4,14.4,Math.PI*1.12,Math.PI*1.5);g.stroke();
  g.fillStyle="rgba(255,255,255,.22)";g.beginPath();g.ellipse(cx+8,hdY+8,4,2,-.7,0,7);g.fill();
  g.fillStyle=hgrad(g,cx-14,cx+14,[[0,tr3],[.5,tr],[1,tr2]]);g.beginPath();g.ellipse(cx,hdY+16,15,4.4,0,0,7);g.fill();g.strokeStyle="rgba(0,0,0,.4)";g.lineWidth=.7;g.stroke();g.fillStyle="rgba(255,255,255,.3)";g.fillRect(cx-12,hdY+14.2,24,.9);
  g.fillStyle=tr;g.fillRect(cx-1,hdY-19.4,2,3.4);g.fillStyle="#ff5d5d";g.beginPath();g.arc(cx,hdY-19.8,1.4,0,7);g.fill()};
 /* ---------- accessories ---------- */
 const accFront=()=>{
  if(ac==1){g.strokeStyle="#1b2132";g.lineWidth=1.2;g.fillStyle="rgba(190,230,255,.22)";for(const sg of[-1,1]){g.beginPath();g.roundRect(cx+sg*4.8-4.4,hdY-1,8.8,6.8,2.2);g.fill();g.stroke()}g.beginPath();g.moveTo(cx-.4,hdY+2);g.lineTo(cx+.4,hdY+2);g.stroke();g.beginPath();g.moveTo(cx-9.2,hdY+1.6);g.lineTo(cx-12.4,hdY+.8);g.moveTo(cx+9.2,hdY+1.6);g.lineTo(cx+12.4,hdY+.8);g.stroke();g.fillStyle="rgba(255,255,255,.5)";g.fillRect(cx-8,hdY,2,1);g.fillRect(cx+2,hdY,2,1)}
  else if(ac==2){g.strokeStyle="#1b2132";g.lineWidth=2.2;g.lineCap="round";g.beginPath();g.arc(cx,hdY-1,13.6,Math.PI*1.04,Math.PI*1.96);g.stroke();for(const sg of[-1,1]){g.fillStyle="#1b2132";g.beginPath();g.roundRect(cx+sg*13.2-2.6,hdY-1,5.2,8,2);g.fill();g.fillStyle=tg;g.fillRect(cx+sg*13.2-1,hdY+1,2,3)}g.strokeStyle="#1b2132";g.lineWidth=1.3;g.beginPath();g.moveTo(cx-12.4,hdY+7);g.quadraticCurveTo(cx-10,hdY+14,cx-4,hdY+13);g.stroke();g.fillStyle="#ff6b6b";g.beginPath();g.arc(cx-3.6,hdY+13,1.3,0,7);g.fill()}
  else if(ac==4){g.strokeStyle="#c8d0e0";g.lineWidth=1.2;g.beginPath();g.moveTo(cx+5,hdY-14);g.lineTo(cx+7,hdY-24);g.stroke();g.fillStyle=((performance.now()/500)|0)%2?"#ff5d5d":"#7a2a2a";g.beginPath();g.arc(cx+7,hdY-24.6,1.8,0,7);g.fill()}
  else if(ac==3){g.fillStyle=tr;g.fillRect(cx-14.6,shY-1,3.4,18);g.fillRect(cx+11.2,shY-1,3.4,18);g.fillStyle=tr2;g.fillRect(cx-14.6,shY+14,3.4,2);g.fillRect(cx+11.2,shY+14,3.4,2)}};
 /* ---------- outfit decoration on the front of the torso ---------- */
 const outfitFront=()=>{
  if(ou==0){g.strokeStyle="rgba(0,0,0,.35)";g.lineWidth=.8;g.beginPath();g.moveTo(cx,shY+2);g.lineTo(cx,hipY-5);g.stroke();g.strokeStyle="rgba(255,255,255,.18)";g.beginPath();g.moveTo(cx+.8,shY+2);g.lineTo(cx+.8,hipY-5);g.stroke();
   g.fillStyle=tr;g.fillRect(cx-16.8,shY+4,2.2,12);g.fillRect(cx+14.6,shY+4,2.2,12);
   g.fillStyle=tg;g.beginPath();g.arc(cx-8,shY+9,3.3,0,7);g.fill();g.fillStyle="rgba(255,255,255,.55)";g.beginPath();g.arc(cx-8.8,shY+8.2,1.1,0,7);g.fill();g.strokeStyle="rgba(0,0,0,.4)";g.lineWidth=.6;g.beginPath();g.arc(cx-8,shY+9,3.3,0,7);g.stroke();
   g.fillStyle="rgba(0,0,0,.20)";g.fillRect(cx+4.4,shY+11,7.4,6.2);g.fillStyle="rgba(255,255,255,.15)";g.fillRect(cx+4.4,shY+11,7.4,.8)}
  else if(ou==1){g.fillStyle="#eef2fa";g.beginPath();g.moveTo(cx-5,shY-2);g.lineTo(cx+5,shY-2);g.lineTo(cx+4,hipY-4);g.lineTo(cx-4,hipY-4);g.closePath();g.fill();g.fillStyle="rgba(0,0,0,.14)";g.fillRect(cx+1,shY,4,hipY-shY-4);
   g.fillStyle=hgrad(g,cx-17,cx+17,[[0,tr3],[.5,tr],[1,tr2]]);g.beginPath();g.moveTo(cx-17,shY+3);g.quadraticCurveTo(cx-17,shY-2.4,cx-10,shY-2.6);g.lineTo(cx-4.4,shY-2.6);g.lineTo(cx-3.6,hipY-4);g.lineTo(cx-13.6,hipY+1);g.closePath();g.fill();
   g.beginPath();g.moveTo(cx+17,shY+3);g.quadraticCurveTo(cx+17,shY-2.4,cx+10,shY-2.6);g.lineTo(cx+4.4,shY-2.6);g.lineTo(cx+3.6,hipY-4);g.lineTo(cx+13.6,hipY+1);g.closePath();g.fill();
   g.strokeStyle="rgba(255,255,255,.3)";g.lineWidth=.7;g.beginPath();g.moveTo(cx-4.4,shY-2);g.lineTo(cx-3.6,hipY-4);g.moveTo(cx+4.4,shY-2);g.lineTo(cx+3.6,hipY-4);g.stroke();g.fillStyle=tg;g.beginPath();g.arc(cx-9,shY+8,2.5,0,7);g.fill()}
  else if(ou==2){g.fillStyle=mixc(su,"#ffffff",.6);g.fillRect(cx-6,shY-2,12,hipY-shY+1);g.fillStyle=hgrad(g,cx-17,cx+17,[[0,tr3],[.5,tr],[1,tr2]]);g.beginPath();g.moveTo(cx-15.4,shY+1);g.lineTo(cx-6,shY-2.6);g.lineTo(cx-3.6,hipY-3);g.lineTo(cx-13.4,hipY+1);g.closePath();g.fill();g.beginPath();g.moveTo(cx+15.4,shY+1);g.lineTo(cx+6,shY-2.6);g.lineTo(cx+3.6,hipY-3);g.lineTo(cx+13.4,hipY+1);g.closePath();g.fill();
   g.fillStyle="#d9dfef";for(let i=0;i<3;i++){g.fillRect(cx-5.4,shY+4+i*7,1.8,1.8);g.fillRect(cx+3.6,shY+4+i*7,1.8,1.8)}g.fillStyle=tg;g.beginPath();g.arc(cx-9,shY+9,2.3,0,7);g.fill()}
  else{/* lab coat */g.fillStyle=hgrad(g,cx-18,cx+18,[[0,"#ffffff"],[.5,"#e6ebf6"],[1,"#aab4ca"]]);g.beginPath();g.moveTo(cx-17.6,shY+3);g.quadraticCurveTo(cx-17.6,shY-2.6,cx-10,shY-2.6);g.lineTo(cx-4,shY-2.6);g.lineTo(cx-3,hipY+30);g.lineTo(cx-17,hipY+27);g.closePath();g.fill();
   g.beginPath();g.moveTo(cx+17.6,shY+3);g.quadraticCurveTo(cx+17.6,shY-2.6,cx+10,shY-2.6);g.lineTo(cx+4,shY-2.6);g.lineTo(cx+3,hipY+30);g.lineTo(cx+17,hipY+27);g.closePath();g.fill();
   g.strokeStyle="rgba(0,0,0,.25)";g.lineWidth=.7;g.beginPath();g.moveTo(cx-4,shY-2);g.lineTo(cx-3,hipY+30);g.moveTo(cx+4,shY-2);g.lineTo(cx+3,hipY+30);g.stroke();g.fillStyle="rgba(0,0,0,.10)";g.fillRect(cx+8,hipY+8,6,6);g.fillStyle=tg;g.fillRect(cx-12,shY+12,4,1.8);g.fillStyle="#cfd6e6";g.beginPath();g.arc(cx-3.4,shY+10,.9,0,7);g.arc(cx-3.2,shY+17,.9,0,7);g.fill()}};
 /* ============================ FRONT / BACK ============================ */
 if(dir==0||dir==1){
  /* backpack sits behind the torso when seen from the back, helmet back etc. */
  const bk=back;
  if(bk&&ac==3){g.fillStyle=hgrad(g,cx-14,cx+14,[[0,tr3],[.5,tr],[1,tr2]]);g.beginPath();g.roundRect(cx-13,shY-1,26,31,4);g.fill();g.fillStyle=tr2;g.fillRect(cx-13,shY+12,26,2);g.fillRect(cx-1,shY-1,2,31);g.fillStyle="rgba(255,255,255,.25)";g.fillRect(cx-12,shY,24,.8);g.fillStyle="#34d399";g.fillRect(cx+8,shY+3,3,1.6)}
  if(!bk&&st==1)hairBack();else if(bk&&st==1)hairBack();
  if(sit&&bk)armsFB(true);
  /* legs */
  if(!sit||!bk){for(const i of [0,1]){const sg=i?1:-1,s=walking?Math.sin(ph+(i?Math.PI:0)):0,lift=walking?Math.max(0,s)*4.6:0,
    hx=cx+sg*6.8,hy=hipY-2,ax=cx+sg*(7.6+(walking?s*.4:0)),ay=sit?106+0:(106+(walking?s*2.4*(bk?-1:1):0)-lift);
    if(sit){/* seated, feet on the floor, thighs towards the camera */
     if(!bk){limb(g,hx,hy+4,cx+sg*8.2,hy+13,12,pants,pants3);g.fillStyle=pants3;g.beginPath();g.arc(cx+sg*8.2,hy+13,5.4,0,7);g.fill();limb(g,cx+sg*8.2,hy+13,ax,ay-5,9.4,pants,pants3,false);boot(g,ax,ay-2.4,0,11.2,tr,tr2,false)}}
    else{const kx=cx+sg*(7.4+(walking?s*.3:0)),ky=hipY+22+(walking?s*1.3-lift*.5:0);
     limb(g,hx,hy,kx,ky,11.2,pants,pants3);limb(g,kx,ky,ax,ay-4,9.4,pants,pants3,false);
     if(ou==0){g.strokeStyle=tr;g.lineWidth=1.6;g.lineCap="butt";g.beginPath();g.moveTo(hx+sg*5.2,hy+6);g.lineTo(kx+sg*4.4,ky);g.lineTo(ax+sg*4,ay-6);g.stroke()}
     boot(g,ax,ay-2.4,bk?1:0,11.2,tr,tr2,bk)}}}
  if(!bk||!(sit&&bk)){}
  /* far-side order: torso first then arms over it */
  torsoFront();
  if(!bk)outfitFront();else{/* back details */
   if(ou==3){g.fillStyle=hgrad(g,cx-18,cx+18,[[0,"#ffffff"],[.5,"#e6ebf6"],[1,"#aab4ca"]]);g.beginPath();g.moveTo(cx-17.6,shY+3);g.quadraticCurveTo(cx-17.6,shY-2.6,cx-10,shY-2.6);g.lineTo(cx+10,shY-2.6);g.quadraticCurveTo(cx+17.6,shY-2.6,cx+17.6,shY+3);g.lineTo(cx+17,hipY+27);g.lineTo(cx-17,hipY+27);g.closePath();g.fill();g.strokeStyle="rgba(0,0,0,.18)";g.lineWidth=.8;g.beginPath();g.moveTo(cx,shY);g.lineTo(cx,hipY+27);g.stroke()}
   else if(ou==1){g.fillStyle=hgrad(g,cx-17,cx+17,[[0,tr3],[.5,tr],[1,tr2]]);g.beginPath();g.moveTo(cx-17,shY+3);g.quadraticCurveTo(cx-17,shY-2.4,cx-10,shY-2.6);g.lineTo(cx+10,shY-2.6);g.quadraticCurveTo(cx+17,shY-2.4,cx+17,shY+3);g.lineTo(cx+14.2,hipY+1);g.quadraticCurveTo(cx,hipY+5.6,cx-14.2,hipY+1);g.closePath();g.fill();g.strokeStyle="rgba(0,0,0,.3)";g.lineWidth=.8;g.beginPath();g.moveTo(cx,shY-2);g.lineTo(cx,hipY);g.stroke()}
   else if(ou==2){g.fillStyle=hgrad(g,cx-17,cx+17,[[0,tr3],[.5,tr],[1,tr2]]);g.beginPath();g.moveTo(cx-14,shY);g.lineTo(cx+14,shY);g.lineTo(cx+13.4,hipY+1);g.lineTo(cx-13.4,hipY+1);g.closePath();g.fill()}
   else{g.strokeStyle="rgba(0,0,0,.3)";g.lineWidth=.9;g.beginPath();g.moveTo(cx,shY);g.lineTo(cx,hipY-5);g.stroke();g.fillStyle=tr;g.fillRect(cx-16.8,shY+4,2.2,12);g.fillRect(cx+14.6,shY+4,2.2,12);g.fillStyle="rgba(0,0,0,.14)";g.beginPath();g.ellipse(cx-6,shY+10,4,7,.2,0,7);g.ellipse(cx+6,shY+10,4,7,-.2,0,7);g.fill()}}
  belt();
  if(ou==3&&!bk)g.fillStyle="#d4dbec";
  if(!(sit&&bk))armsFB(false);else armsFB(false);
  if(!bk&&ac==3)accFront();
  neckAndHead();
  if(bk){headBack();hairBack();if(st==4)helmet(false)}
  else{headFront();hairFront();if(st==4)helmet(true);accFront()}
  if(bk){if(ac==2){g.strokeStyle="#1b2132";g.lineWidth=2.2;g.lineCap="round";g.beginPath();g.arc(cx,hdY-1,13.6,Math.PI*1.04,Math.PI*1.96);g.stroke();for(const sg of[-1,1]){g.fillStyle="#1b2132";g.beginPath();g.roundRect(cx+sg*13.2-2.6,hdY-1,5.2,8,2);g.fill()}}
   else if(ac==4){g.strokeStyle="#c8d0e0";g.lineWidth=1.2;g.beginPath();g.moveTo(cx+5,hdY-14);g.lineTo(cx+7,hdY-24);g.stroke();g.fillStyle="#ff5d5d";g.beginPath();g.arc(cx+7,hdY-24.6,1.8,0,7);g.fill()}}
  return}
 /* ============================ SIDE (facing left) ============================ */
 const F=-1,hipX=42,sh=shY;
 const armSide=(i,far)=>{const s=walking?Math.sin(ph+(i?Math.PI:0)):0,a=-s*.62,rest=sit?.2:0;let sx=hipX+(far?1.4:-1.2),sy=sh+3.5;
  const ex=sx+F*Math.sin(a+rest)*15,ey=sy+Math.cos(a+rest)*15,fa=a+rest+(sit?1.05:.35+.3*Math.max(0,a)),wx=ex+F*Math.sin(fa)*14,wy=ey+Math.cos(fa)*14;
  const c1=far?sleeve2:sleeve,c2=far?sleeve2:sleeve3;limb(g,sx,sy,ex,ey,9,c1,c2,!far);limb(g,ex,ey,wx,wy,8,far?shade(sleeve2,-.1):sleeve2,sleeve3,false);
  g.fillStyle=far?shade(tr,-.2):tr;g.beginPath();g.ellipse(wx,wy-1,3.6,1.8,Math.atan2(wy-ey,wx-ex)+1.57,0,7);g.fill();hand(g,wx+F*.4,wy+2.2,far?sk2:sk,3.4);
  if(!far&&(ou==0||ou==2)){g.fillStyle=tr;g.beginPath();g.ellipse(sx,sy-1.4,5,3.2,0,Math.PI,Math.PI*2);g.fill()}};
 const legSide=(i,far)=>{const s=Math.sin(ph+(i?Math.PI:0)),c=Math.cos(ph+(i?Math.PI:0));let a=walking?s*.52:0,fl=walking?.62*Math.max(0,c):0;
  const hx=hipX+(far?1:-1),hy=hipY-2,pc=far?pants2:pants,hc=far?pants2:pants3;
  if(sit){const kx=hx+F*14,ky=hy+4,ax=kx+F*1.5,ay=106;limb(g,hx,hy+2,kx,ky,11,pc,hc);g.fillStyle=far?pants2:pants3;g.beginPath();g.arc(kx,ky,5.2,0,7);g.fill();limb(g,kx,ky,ax,ay-5,9.2,pc,hc,false);boot(g,ax,ay-2.4,F,11,far?shade(tr,-.2):tr,tr2);return}
  const kx=hx+F*Math.sin(a)*21,ky=hy+Math.cos(a)*21,b=a-fl,ax=kx+F*Math.sin(b)*19.5,ay=ky+Math.cos(b)*19.5;
  limb(g,hx,hy,kx,ky,11,pc,hc);limb(g,kx,ky,ax,ay,9.2,pc,hc,false);boot(g,ax,Math.min(ay,108)-2.4,F,11,far?shade(tr,-.2):tr,tr2)};
 if(ac==3){g.fillStyle=hgrad(g,hipX,hipX+14,[[0,tr],[1,tr2]]);g.beginPath();g.roundRect(hipX+5.4,sh-1,12.4,29,3.4);g.fill();g.fillStyle="rgba(255,255,255,.25)";g.fillRect(hipX+6,sh,2,27);g.fillStyle="#34d399";g.fillRect(hipX+13,sh+3,2.4,1.4)}
 if(st==1){const q=hgrad(g,hipX-2,hipX+14,[[0,hr],[1,hr2]]);g.fillStyle=q;g.beginPath();g.moveTo(hipX+3,hdY-8);g.quadraticCurveTo(hipX+14,hdY+4,hipX+8.4,hdY+28);g.lineTo(hipX-1,hdY+28);g.quadraticCurveTo(hipX+2,hdY+10,hipX-2,hdY-4);g.fill()}
 legSide(0,true);if(sit)armSide(0,true);else armSide(0,true);
 /* torso */
 g.fillStyle=hgrad(g,hipX-9,hipX+9,[[0,ou==3?"#ffffff":su3],[.5,ou==3?"#e6ebf6":su],[1,ou==3?"#aab4ca":su2]]);g.beginPath();g.moveTo(hipX-8.4,sh+3);g.quadraticCurveTo(hipX-9.2,sh-2.4,hipX-3,sh-2.6);g.lineTo(hipX+4.4,sh-2.6);g.quadraticCurveTo(hipX+9.4,sh-2,hipX+9,sh+4);g.lineTo(hipX+7.6,ou==3?hipY+27:hipY+1);g.quadraticCurveTo(hipX,(ou==3?hipY+30:hipY+5),hipX-7.6,ou==3?hipY+27:hipY+1);g.closePath();g.fill();
 if(ou==1){g.fillStyle=tr;g.beginPath();g.moveTo(hipX-8.4,sh+3);g.quadraticCurveTo(hipX-9.2,sh-2.4,hipX-3,sh-2.6);g.lineTo(hipX+4.4,sh-2.6);g.quadraticCurveTo(hipX+9.4,sh-2,hipX+9,sh+4);g.lineTo(hipX+7.6,hipY+1);g.quadraticCurveTo(hipX,hipY+5,hipX-7.6,hipY+1);g.closePath();g.fill()}
 else if(ou==2){g.fillStyle=tr;g.beginPath();g.moveTo(hipX-8,sh);g.lineTo(hipX+8,sh);g.lineTo(hipX+7.6,hipY+1);g.lineTo(hipX-7.6,hipY+1);g.closePath();g.fill()}
 else if(ou==0){g.fillStyle=tg;g.beginPath();g.arc(hipX-5.4,sh+9,2.6,0,7);g.fill();g.fillStyle=tr;g.fillRect(hipX-1,sh+3,2,10)}
 g.fillStyle="rgba(255,255,255,.14)";g.fillRect(hipX-8.4,sh+1,1.4,hipY-sh-4);
 g.fillStyle=vgrad(g,hipY-5,hipY+1,[[0,tr3],[1,tr2]]);g.beginPath();g.roundRect(hipX-8.2,hipY-5.2,16.4,5.2,1.2);g.fill();
 legSide(1,false);armSide(1,false);
 /* neck + head */
 g.fillStyle=vgrad(g,sh-9,sh-1,[[0,sk],[1,sk2]]);g.fillRect(hipX-3.6,sh-9,7,8);
 const hX=41,q=g.createRadialGradient(hX-4,hdY-6,2,hX,hdY,15);q.addColorStop(0,sk3);q.addColorStop(.6,sk);q.addColorStop(1,sk2);
 if(st!=5&&st!=4&&st!=3){/* hair behind */const hq=hgrad(g,hX-10,hX+14,[[0,hr],[1,hr2]]);g.fillStyle=hq;g.beginPath();g.ellipse(hX+4.6,hdY-1.6,9.2,13.4,0,0,7);g.fill()}
 g.fillStyle=q;g.beginPath();g.ellipse(hX,hdY,11.4,13.2,0,0,7);g.fill();
 /* nose + chin */
 g.fillStyle=sk;g.beginPath();g.moveTo(hX-10.4,hdY+.6);g.quadraticCurveTo(hX-14.4,hdY+4.6,hX-10.8,hdY+6.4);g.quadraticCurveTo(hX-9.4,hdY+5,hX-9.4,hdY+2);g.closePath();g.fill();g.strokeStyle=sk2;g.lineWidth=.6;g.stroke();
 g.fillStyle="rgba(0,0,0,.10)";g.beginPath();g.ellipse(hX-1,hdY+9.4,8,4,0,0,Math.PI);g.fill();
 ell(g,hX+3.6,hdY+1.8,2.3,3.4,sk2);g.strokeStyle="rgba(0,0,0,.22)";g.lineWidth=.6;g.beginPath();g.arc(hX+3.6,hdY+1.8,1.2,.5,5.5);g.stroke();
 const ex=hX-5.6,ey=hdY+1.2;ell(g,ex,ey,2.4,2.5,"#f4f6fb");g.fillStyle="#2a3050";g.beginPath();g.arc(ex-.8,ey+.2,1.6,0,7);g.fill();g.fillStyle="#0a0d18";g.beginPath();g.arc(ex-.9,ey+.2,.85,0,7);g.fill();g.fillStyle="#fff";g.fillRect(ex-1.4,ey-.9,.8,.8);
 g.strokeStyle=st==5?sk2:hr2;g.lineWidth=1.3;g.lineCap="round";g.beginPath();g.moveTo(ex-3.2,ey-3.2);g.quadraticCurveTo(ex,ey-4.6,ex+2.6,ey-3.2);g.stroke();
 g.strokeStyle=mixc(sk,"#8a3a3a",.6);g.lineWidth=1;g.beginPath();g.moveTo(hX-8,hdY+10.4);g.quadraticCurveTo(hX-5.6,hdY+11.8,hX-3.4,hdY+10.4);g.stroke();
 /* hair front-side */
 if(st==3){g.fillStyle=hgrad(g,hX-14,hX+14,[[0,tr3],[.5,tr],[1,tr2]]);g.beginPath();g.moveTo(hX-11.6,hdY-3.6);g.quadraticCurveTo(hX-11,hdY-16.4,hX+1,hdY-16.4);g.quadraticCurveTo(hX+12.4,hdY-14,hX+12,hdY-1);g.quadraticCurveTo(hX,hdY-5,hX-11.6,hdY-3.6);g.fill();g.fillStyle=tr2;g.beginPath();g.moveTo(hX-10.8,hdY-5);g.quadraticCurveTo(hX-21,hdY-3.4,hX-20.4,hdY-1);g.quadraticCurveTo(hX-14,hdY-2.4,hX-9,hdY-2.4);g.fill();g.fillStyle=hr;g.beginPath();g.ellipse(hX+7,hdY+1,4.4,6,0,0,7);g.fill()}
 else if(st!=5&&st!=4){const hq=hgrad(g,hX-12,hX+12,[[0,hr3],[.5,hr],[1,hr2]]);g.fillStyle=hq;g.beginPath();g.moveTo(hX-11.2,hdY-1);g.quadraticCurveTo(hX-13,hdY-12,hX-4,hdY-15);g.quadraticCurveTo(hX+8,hdY-18,hX+12,hdY-8);g.lineTo(hX+12,hdY+8);g.quadraticCurveTo(hX+9,hdY+1,hX+5.6,hdY-1);g.quadraticCurveTo(hX+3,hdY-7.4,hX-3,hdY-7.4);g.quadraticCurveTo(hX-9,hdY-6.6,hX-11.2,hdY-1);g.fill();
  if(st==2){for(let i=0;i<5;i++){const x=hX-8+i*4.4,h=7+(i%2)*4;g.beginPath();g.moveTo(x-3,hdY-12);g.lineTo(x+.6+(i-2)*.8,hdY-12-h);g.lineTo(x+3.4,hdY-12);g.closePath();g.fill()}}
  g.strokeStyle="rgba(255,255,255,.28)";g.lineWidth=.9;g.beginPath();g.moveTo(hX-7,hdY-10.4);g.quadraticCurveTo(hX,hdY-15.6,hX+7,hdY-12.4);g.stroke()}
 else if(st==5){g.fillStyle="rgba(255,255,255,.22)";g.beginPath();g.ellipse(hX-3,hdY-9,5,2.4,-.3,0,7);g.fill()}
 if(st==4){const q2=g.createRadialGradient(hX-6,hdY-8,2,hX,hdY,19);q2.addColorStop(0,"rgba(210,244,255,.42)");q2.addColorStop(.6,"rgba(130,210,245,.20)");q2.addColorStop(1,"rgba(70,150,210,.30)");g.fillStyle=q2;g.beginPath();g.arc(hX,hdY-.4,17,0,7);g.fill();g.strokeStyle="rgba(215,240,255,.95)";g.lineWidth=1.6;g.beginPath();g.arc(hX,hdY-.4,17,0,7);g.stroke();g.strokeStyle="rgba(255,255,255,.7)";g.lineWidth=1.8;g.beginPath();g.arc(hX,hdY-.4,14.2,Math.PI*1.12,Math.PI*1.5);g.stroke();
  g.fillStyle=hgrad(g,hX-14,hX+14,[[0,tr3],[.5,tr],[1,tr2]]);g.beginPath();g.ellipse(hX,hdY+16,13,4.4,0,0,7);g.fill();g.strokeStyle="rgba(0,0,0,.4)";g.lineWidth=.7;g.stroke();g.fillStyle=tr;g.fillRect(hX-1,hdY-19.4,2,3.4);g.fillStyle="#ff5d5d";g.beginPath();g.arc(hX,hdY-19.8,1.4,0,7);g.fill()}
 if(ac==1){g.strokeStyle="#1b2132";g.lineWidth=1.2;g.fillStyle="rgba(190,230,255,.22)";g.beginPath();g.roundRect(hX-9.8,hdY-1.2,7,6.6,2);g.fill();g.stroke();g.beginPath();g.moveTo(hX-2.8,hdY+1);g.lineTo(hX+3.6,hdY+.4);g.stroke()}
 else if(ac==2){g.strokeStyle="#1b2132";g.lineWidth=2.2;g.lineCap="round";g.beginPath();g.arc(hX+1,hdY-1,13,Math.PI*1.1,Math.PI*1.95);g.stroke();g.fillStyle="#1b2132";g.beginPath();g.roundRect(hX+1.2,hdY-1,5.6,8,2);g.fill();g.fillStyle=tg;g.fillRect(hX+2.8,hdY+1.2,2.4,3);g.strokeStyle="#1b2132";g.lineWidth=1.3;g.beginPath();g.moveTo(hX+2,hdY+7);g.quadraticCurveTo(hX-4,hdY+14,hX-8.6,hdY+12);g.stroke();g.fillStyle="#ff6b6b";g.beginPath();g.arc(hX-8.8,hdY+12,1.3,0,7);g.fill()}
 else if(ac==4){g.strokeStyle="#c8d0e0";g.lineWidth=1.2;g.beginPath();g.moveTo(hX+2,hdY-14);g.lineTo(hX+4,hdY-24);g.stroke();g.fillStyle="#ff5d5d";g.beginPath();g.arc(hX+4,hdY-24.6,1.8,0,7);g.fill()}}

function charSprite(L,dir,fr,sit,typing){
 const key=[L.skin,L.hair,L.suit,L.trim,L.tag,L.style|0,L.outfit|0,L.acc|0,dir,fr,sit?1:0,typing?1:0].join("|");let o=CC.get(key);if(o)return o;
 const c=mk(CW*CK,CH*CK),g=c.getContext("2d");g.scale(CK,CK);g.imageSmoothingEnabled=true;
 if(dir==3){g.translate(CW,0);g.scale(-1,1);paintHuman(g,L,2,fr,sit,typing)}else paintHuman(g,L,dir,fr,sit,typing);
 /* outline: dark silhouette stamped around the figure */
 const s=mk(c.width,c.height),sg=s.getContext("2d");sg.drawImage(c,0,0);sg.globalCompositeOperation="source-in";sg.fillStyle=SCN?"#4a3d33":"#060814";sg.fillRect(0,0,s.width,s.height);
 o=mk(c.width,c.height);const og=o.getContext("2d");const r=1.7;for(let a=0;a<12;a++){og.globalAlpha=.9;og.drawImage(s,Math.cos(a/12*6.283)*r,Math.sin(a/12*6.283)*r)}og.globalAlpha=1;og.drawImage(c,0,0);
 if(CC.size>700)CC.clear();CC.set(key,o);return o}
/* compatibility with the avatar editor preview */
function spr(L,dir,fr,sit){return charSprite(L,dir,sit?0:1+((fr|0)&7),sit)}
function previewLoop(){const c=$("pv");if(!$("dg").open)return;const g=c.getContext("2d");g.clearRect(0,0,c.width,c.height);g.imageSmoothingEnabled=true;g.imageSmoothingQuality="high";const f=1+Math.floor(performance.now()/110)%8,h=c.height-4,w=h*CW/CH;[0,2,3,1].forEach((d,i)=>g.drawImage(charSprite(curLook,d,f,false),i*(c.width/4)+(c.width/4-w)/2,2,w,h));requestAnimationFrame(previewLoop)}

/* ---------------------------------------------------------------- drawing agents in the world */
function agentShadow(c,a,s,now){const sitN=s.sit&&!s.moving;
 const x=s.x*T,y=s.y*T+(sitN?12:13);const q=c.createRadialGradient(x,y,1,x,y,12);q.addColorStop(0,"rgba(0,0,10,.55)");q.addColorStop(1,"rgba(0,0,10,0)");c.fillStyle=q;c.beginPath();c.ellipse(x+1.5,y+1,11.5,4.6,0,0,7);c.fill()}
function agentDraw(c,a,s,now){const sitN=s.sit&&!s.moving;
 const L=a.look||DEFL,busy=S.busy&&a.status!="Idle";let fr=0,typing=false;
 if(sitN){typing=busy&&s.dir==1;fr=typing?1+(((now/120)|0)%4):0}else if(s.moving)fr=1+(Math.floor(s.fr)%8);
 const img=charSprite(L,s.dir,fr,sitN,typing),w=CW*CF,h=CH*CF,gx=s.x*T,gy=s.y*T+(sitN?11:12);
 const jump=s.cel>now?Math.abs(Math.sin(now/120))*5:0,br=(!s.moving&&!sitN)?1+Math.sin(now/760+a.name.length)*.010:1;
 c.save();c.translate(gx,gy-jump);c.scale(1,br);c.drawImage(img,-w/2,-(112/CH)*h,w,h);c.restore();
 celebrate(c,s,gx,gy-jump,now)}

/* ---------------------------------------------------------------- ambient particles */
function drawParticles(c,now,vis){
 if(cam.z<.4||!MAP)return;
 const W=WW/cam.z,H=WH/cam.z;c.save();
 for(let i=0;i<46;i++){const h=hash(i,5),fx=((h%1000)/1000),fy=(((h>>10)%1000)/1000),x=cam.x+((fx*W+now*.004*((i%5)-2)+i*37)%W+W)%W,y=cam.y+((fy*H-now*.006*(1+i%3)+i*53)%H+H)%H,tx=x/T|0,ty=y/T|0;
  if(tx<0||ty<0||tx>=WT||ty>=HT||!MAP.own[ty*WT+tx])continue;
  c.fillStyle="rgba(210,230,255,"+(.10+.14*Math.abs(Math.sin(now/900+i)))+")";c.beginPath();c.arc(x,y,.55+(i%3)*.25,0,7);c.fill()}
 c.restore()}
/* ===== v9 part 5: HUD ===== */
const HF="600 {S}px 'Bahnschrift','Segoe UI',system-ui,sans-serif";
function hfont(s){return HF.replace("{S}",s)}
function pill(c,x,y,txt,col,sz,bg){c.font=hfont(sz);const w=c.measureText(txt).width+14,hh=sz+9;
 if(WL())bg="#ffffff";c.fillStyle=bg||"rgba(21,24,31,.92)";c.beginPath();c.roundRect(x-w/2,y-hh/2,w,hh,5);c.fill();
 c.strokeStyle=col;c.globalAlpha=.8;c.lineWidth=1;c.beginPath();c.roundRect(x-w/2+.5,y-hh/2+.5,w-1,hh-1,5);c.stroke();c.globalAlpha=1;
 if(WL()){c.strokeStyle="rgba(16,24,40,.10)";c.beginPath();c.roundRect(x-w/2-.5,y-hh/2+1,w+1,hh,5);c.stroke()}c.fillStyle=WL()?"#101828":"#e7e9ee";c.textAlign="center";c.textBaseline="middle";c.fillText(txt,x,y+.5)}
function bubble(c,sx,sy,s){c.font="12.5px 'Segoe UI',system-ui,sans-serif";let t=s.say;if(t.length>110)t=t.slice(0,107)+"\u2026";const L=[];let l="";for(const w of t.split(/\s+/)){const n=l?l+" "+w:w;if(c.measureText(n).width>190&&l){L.push(l);l=w}else l=n}if(l)L.push(l);
 const bw=Math.max(...L.map(x=>c.measureText(x).width))+20,bh=L.length*16+14,st=s.kind=="stuck",bx=Math.min(Math.max(sx-bw/2,6),WW-bw-6),by=Math.max(6,sy-bh-10);
 const bgc=WL()?(st?"#fff7e6":"#ffffff"):(st?"#2b2312":"#15181f");c.fillStyle=bgc;c.strokeStyle=st?"#d9a441":WL()?"#d0d5dd":"#363d4d";c.lineWidth=1;c.beginPath();c.roundRect(bx,by,bw,bh,6);c.fill();c.stroke();
 c.fillStyle=bgc;c.beginPath();c.moveTo(sx-5,by+bh-.5);c.lineTo(sx,by+bh+6);c.lineTo(sx+5,by+bh-.5);c.fill();
 c.fillStyle=WL()?"#101828":"#e7e9ee";c.textAlign="left";c.textBaseline="alphabetic";L.forEach((x,i)=>c.fillText(x,bx+10,by+18+i*16))}
function paintHUD(c,now,dpr){
 c.setTransform(dpr,0,0,dpr,0,0);const z=cam.z;
 MAP.R.forEach(r=>{const[sx,sy]=w2s((r.x+r.w/2)*T,r.y*T-6);if(sx<-200||sx>WW+200||sy<-50||sy>WH+50)return;
  const ag=S.agents.filter(a=>r.hub?a.boss:a.room==r.id),runs=ag.reduce((n,a)=>n+(a.runs||0),0),done=ag.reduce((n,a)=>n+(a.done||0),0),fs=z<.4?10:12;
  if(!OFFICE())pill(c,sx,sy-(r.hub||z<.4||WL()?14:36),r.name,r.color,fs);
  if(z>=.4&&!r.hub&&!WL()){if(!ag.length)pill(c,sx,sy-14,"Empty room",r.color,Math.max(9,fs-2),"#070d1a99");else pill(c,sx,sy-14,runs+" runs \u00b7 "+done+" shipped",r.color,Math.max(9,fs-2),"#070d1ac8")}});
 S.agents.forEach(a=>{const s=SP[a.id];if(!s||!MAP)return;const busy=S.busy&&a.status!="Idle",wait=S.pending.some(p=>p.who==a.name),sd=seatOf(a);
  if(sd&&z>=.5&&!a.boss){const[sx,sy]=w2s((sd.x+.5)*T,sd.y*T-T*.9);if(sx>-80&&sx<WW+80&&sy>-40&&sy<WH+40){
    pill(c,sx,sy,a.name,roomColOf(a),11);
    if(s.sit&&busy){const t=Math.max(0,(now-s.t0)/1000|0);pill(c,sx,sy-19,"Running "+(t/60|0)+":"+String(t%60).padStart(2,"0"),"#4ade80",10,"#06140c")}}}
  const[hx,hy]=w2s(s.x*T,s.y*T-(a.boss?46:30));if(hx<-100||hx>WW+100||hy<-60||hy>WH+60)return;
  if(a.boss){bossTag(c,a,s,hx,hy,now,z)}else if(z>=.7&&!(sd&&!a.boss&&s.sit)){c.font=hfont(11);c.textAlign="center";c.textBaseline="alphabetic";c.lineWidth=3;c.strokeStyle=WL()?"#ffffffe6":"#000c";c.lineJoin="round";c.strokeText(a.name,hx,hy-6);c.fillStyle=WL()?"#101828":a.boss?"#c4b5fd":"#e8f0ff";c.fillText(a.name,hx,hy-6)}
  if(wait){const by=hy-22+Math.sin(now/180)*2;c.fillStyle="#d9a441";c.beginPath();c.arc(hx,by,9,0,7);c.fill();c.fillStyle="#1a1000";c.font="bold 13px sans-serif";c.textAlign="center";c.textBaseline="middle";c.fillText("!",hx,by+1)}
  if(s.say&&now<s.sayT)bubble(c,hx,hy-(wait?30:8),s)});
 legend(c,now);drawMini(c,now);
 const nb=S.agents.filter(a=>S.busy&&a.status!="Idle").length,txt=(S.pending.length?S.pending.length+" awaiting your approval":nb?nb+" agent"+(nb>1?"s":"")+" working":"All quiet")+" \u00b7 "+S.rooms.length+" room"+(S.rooms.length>1?"s":"");
 $("zl").textContent=Math.round(cam.z*100)+"%"}

function bossTag(c,a,s,hx,hy,now,z){
 const fs=Math.round(Math.max(7,Math.min(11,5+z*5))),txt="Boss";
 c.font=hfont(fs);const w=c.measureText(txt).width+fs*1.4,h=fs+8,x=hx-w/2,y=hy+6-h;
 const wl=WL();c.fillStyle=wl?"#334155":"#2b2312";c.beginPath();c.roundRect(x,y,w,h,4);c.fill();if(!wl){c.strokeStyle="#d9a441";c.lineWidth=1;c.beginPath();c.roundRect(x+.5,y+.5,w-1,h-1,4);c.stroke()}
 c.fillStyle=wl?"#ffffff":"#f0cf85";c.textAlign="center";c.textBaseline="middle";c.fillText(txt,hx,y+h/2+.5);
 if(bossPing>now){const k=1-(bossPing-now)/2500,r=20+k*140;c.strokeStyle="rgba(217,164,65,"+(1-k)+")";c.lineWidth=2;c.beginPath();c.arc(hx,hy+34,r,0,7);c.stroke()}}
function legend(c,now){if(build.on||WW<560||!MAP)return;const rows=[{n:(S.hub&&S.hub.name)||"Operations Hub",col:roomColOf({boss:1}),k:"Boss"}].concat(S.rooms.map(r=>({n:r.name,col:r.color,k:S.agents.filter(a=>!a.boss&&a.room==r.id).length+""})));
 c.font=hfont(11);const w=Math.max(...rows.map(r=>c.measureText(r.n).width+c.measureText(r.k).width))+54,h=rows.length*20+12,x=12,y=WH-12-h;
 c.fillStyle=WL()?"#ffffff":"rgba(21,24,31,.94)";c.beginPath();c.roundRect(x,y,w,h,6);c.fill();c.strokeStyle=WL()?"#d0d5dd":"#363d4d";c.lineWidth=1;c.beginPath();c.roundRect(x+.5,y+.5,w-1,h-1,6);c.stroke();
 rows.forEach((r,i)=>{const yy=y+16+i*20;c.fillStyle=r.col;c.beginPath();c.roundRect(x+11,yy-5,10,10,2);c.fill();
  c.font=hfont(11);c.textAlign="left";c.textBaseline="middle";c.fillStyle=WL()?"#101828":"#e7e9ee";c.fillText(r.n,x+30,yy+.5);c.fillStyle=WL()?"#5d6676":"#8b93a3";c.textAlign="right";c.fillText(r.k,x+w-10,yy+.5)})}
/* ===== v9.1: executive desk, bridge extras, boss look ===== */
const GOLD="#f5c542",GOLD2="#b8860b";
function pBoss(g,W){W=W||160;
 const m=W/2;
 g.fillStyle=vgrad(g,2,34,[[0,"#3b4478"],[1,"#171a3a"]]);g.beginPath();g.moveTo(0,12);g.quadraticCurveTo(m,-4,W,12);g.lineTo(W,30);g.quadraticCurveTo(m,38,0,30);g.closePath();g.fill();
 /* gold edge */
 g.strokeStyle=GOLD;g.lineWidth=1.6;g.beginPath();g.moveTo(1,12.5);g.quadraticCurveTo(m,-3,W-1,12.5);g.stroke();
 g.strokeStyle="rgba(255,240,180,.55)";g.lineWidth=.7;g.beginPath();g.moveTo(3,11.2);g.quadraticCurveTo(m,-4.4,W-3,11.2);g.stroke();
 /* top surface */
 g.fillStyle=vgrad(g,10,32,[[0,"#8a95d2"],[.35,"#4a5496"],[1,"#20255a"]]);g.beginPath();g.moveTo(3,14);g.quadraticCurveTo(m,1,W-3,14);g.lineTo(W-3,24);g.quadraticCurveTo(m,33,3,24);g.closePath();g.fill();
 g.fillStyle="rgba(255,255,255,.16)";g.beginPath();g.moveTo(10,15);g.quadraticCurveTo(m*.6,8,m,7.5);g.lineTo(m,11);g.quadraticCurveTo(m*.6,12,12,19);g.fill();
 /* gold inlay + underglow */
 g.strokeStyle="rgba(245,197,66,.9)";g.lineWidth=1.1;g.beginPath();g.moveTo(3,26.2);g.quadraticCurveTo(m,35.5,W-3,26.2);g.stroke();
 g.strokeStyle="rgba(167,139,250,.9)";g.lineWidth=1;g.beginPath();g.moveTo(3,28.2);g.quadraticCurveTo(m,37.6,W-3,28.2);g.stroke();
 g.fillStyle="rgba(0,0,0,.4)";g.beginPath();g.moveTo(1,30.5);g.quadraticCurveTo(m,39.5,W-1,30.5);g.lineTo(W-1,32);g.quadraticCurveTo(m,41,1,32);g.fill();
 /* keyboards / consoles */
 const n=Math.round((W-20)/34);for(let i=0;i<n;i++){const bx=10+i*((W-20)/n)+((W-20)/n-20)/2;g.fillStyle="#0b0e20";g.beginPath();g.roundRect(bx,16+Math.abs(i-(n-1)/2)*.5,20,7,1.4);g.fill();g.fillStyle="#35409a";for(let k=0;k<8;k++)g.fillRect(bx+1.4+k*2.3,17.2+Math.abs(i-(n-1)/2)*.5,1.7,1)}
 /* gold end caps */
 for(const ex of[2,W-8]){g.fillStyle=vgrad(g,8,30,[[0,"#ffe9a0"],[1,GOLD2]]);g.beginPath();g.roundRect(ex,9,6,20,2);g.fill()}
 /* emblem */
 g.fillStyle=GOLD;g.beginPath();g.moveTo(m,26.2);for(let k=0;k<10;k++){const r=k%2?1.4:3.4,a=-Math.PI/2+k*Math.PI/5;g.lineTo(m+Math.cos(a)*r,27.6+Math.sin(a)*r)}g.closePath();g.fill()}
function bossDraw(c,p,now){
 if(WL())return execDesk(c,p,now);
 const W=(p.w||3)*32,x=p.x*T,y=p.y*T,s=PSPR("boss"+W,W,36,0,g=>pBoss(g,W));blit(c,s,x,y);
 const t=now/1000,cx=x+W/2,cy=y+13;
 const nh=W>=160?5:3,cols=["#f5c542","#a78bfa","#6ee7ff","#a78bfa","#f5c542"].slice(nh==5?0:1,nh==5?5:4);
 const pos=nh==5?[-56,-28,0,28,56]:[-32,0,32];
 pos.forEach((dx,i)=>{const mid=dx==0,w=mid?26:18,h=mid?15:11,hy=y-10-(mid?5:Math.abs(dx)>40?-1:1)+Math.sin(t*1.4+i)*.9,col=(nh==5?["#f5c542","#a78bfa","#6ee7ff","#a78bfa","#f5c542"]:["#a78bfa","#6ee7ff","#c4b5fd"])[i];
  c.save();c.translate(cx+dx,hy);c.fillStyle=rgba(col,.14);rr(c,-w/2,-h/2,w,h,2);c.fill();c.strokeStyle=rgba(col,.95);c.lineWidth=.9;c.stroke();c.fillStyle=rgba(col,.85);
  for(let k=0;k<4;k++){const ln=3+(hash(((t*2)|0)+k+i,3)%(w-6));c.fillRect(-w/2+2,-h/2+2+k*2.5,ln,.8)}
  c.fillStyle="rgba(255,255,255,.35)";c.fillRect(-w/2,-h/2+((t*8+i*3)%h),w,.6);c.restore()});
 /* hologram projector: rotating wireframe */
 c.save();c.translate(cx,cy-9);const g_=c.createLinearGradient(0,10,0,-14);g_.addColorStop(0,"rgba(245,197,66,.45)");g_.addColorStop(1,"rgba(245,197,66,0)");c.fillStyle=g_;c.beginPath();c.moveTo(-8,10);c.lineTo(8,10);c.lineTo(13,-14);c.lineTo(-13,-14);c.fill();
 c.strokeStyle="rgba(255,226,140,.95)";c.lineWidth=.8;for(let k=0;k<3;k++){c.beginPath();c.ellipse(0,-2,10*Math.abs(Math.cos(t*1.2+k*1.05)),10,0,0,7);c.stroke()}c.beginPath();c.ellipse(0,-2,10,2.8,0,0,7);c.stroke();
 c.fillStyle="#fff3c0";c.beginPath();c.arc(Math.cos(t*2)*10,-2+Math.sin(t*2)*2.8,1.2,0,7);c.fill();c.restore()}
/* ---- v14.8 Operations Hub (white theme): live wall dashboard, executive desk, meeting table ---- */
function opsWall(c,r,now){const X=r.x*T,Y=r.y*T,W=r.w*T,pad=16,y=Y+14,h=58,x=X+pad,w=W-pad*2;
 c.save();c.shadowColor="rgba(16,24,40,.08)";c.shadowBlur=10*cam.z*RDPR();rr(c,x,y,w,h,8);c.fillStyle="#ffffff";c.fill();c.restore();rr(c,x,y,w,h,8);c.strokeStyle="#d0d5dd";c.lineWidth=1;c.stroke();
 const A=S.agents||[],st=a=>(S.pending||[]).some(p=>p.who==a.name)?"a":/^(Stuck|Error)/.test(a.status||"")?"s":S.busy&&a.t0&&a.status&&a.status!="Idle"?"w":"i";
 const mid=new Date();mid.setHours(0,0,0,0);const shipped=(S.ledger_tail||[]).length?null:null;
 const k=[["Working",A.filter(a=>st(a)=="w").length,"#12805c"],["Waiting for you",(S.pending||[]).length,"#b54708"],["Stuck",A.filter(a=>st(a)=="s").length,"#c4320a"],["Rooms",(S.rooms||[]).length,"#1f5fd6"]];
 const cw=w/k.length;k.forEach(([l,n,col],i)=>{const cx=x+cw*i;if(i){c.fillStyle="#eaecf0";c.fillRect(cx,y+10,1,h-20)}
  c.fillStyle=col;c.font="600 22px 'Segoe UI Variable Display','Segoe UI',system-ui,sans-serif";c.textAlign="left";c.textBaseline="alphabetic";c.fillText(String(n),cx+14,y+30);
  c.fillStyle="#5d6676";c.font="500 10.5px 'Segoe UI',system-ui,sans-serif";c.fillText(l,cx+14,y+46);
  if(i==0&&n>0){c.font="600 22px 'Segoe UI Variable Display','Segoe UI',system-ui,sans-serif";const tw=c.measureText(String(n)).width,p=.5+.5*Math.sin(now/400);c.fillStyle=rgba(col,.35+p*.5);c.beginPath();c.arc(cx+14+tw+8,y+22,3.5,0,7);c.fill()}});
 c.textAlign="left"}
function execDesk(c,p,now){const W=(p.w||3)*32,x=p.x*T,y=p.y*T;
 c.save();c.shadowColor="rgba(16,24,40,.12)";c.shadowBlur=8*cam.z*RDPR();c.shadowOffsetY=3*cam.z*RDPR();rr(c,x+2,y+6,W-4,24,6);c.fillStyle="#ffffff";c.fill();c.restore();
 rr(c,x+2,y+6,W-4,24,6);c.strokeStyle="#d0d5dd";c.lineWidth=1;c.stroke();c.fillStyle="#475467";c.fillRect(x+8,y+27,W-16,2);
 const n=W>=160?3:2,mw=n==3?34:30;for(let i=0;i<n;i++){const mx=x+W/2+(i-(n-1)/2)*(mw+6)-mw/2,my=y-6;rr(c,mx,my,mw,18,3);c.fillStyle="#1d2433";c.fill();
  c.fillStyle="#2f6bdb";c.globalAlpha=.85;for(let k=0;k<3;k++)c.fillRect(mx+4,my+4+k*4,4+((hash(i,k)+((now/900)|0))%(mw-10)),1.6);c.globalAlpha=1;c.fillStyle="#98a2b3";c.fillRect(mx+mw/2-1.5,my+18,3,5)}
 c.fillStyle="#eaecf0";rr(c,x+W/2-14,y+18,28,6,2);c.fill()}
function officeChair(c,bs,back){const cx=(bs.x+.5)*T,by=bs.y*T;
 if(back){rr(c,cx-13,by+6,26,14,6);c.fillStyle="#3b4352";c.fill();c.fillStyle="rgba(255,255,255,.12)";rr(c,cx-10,by+8,20,4,2);c.fill()}
 else{c.fillStyle="rgba(16,24,40,.12)";c.beginPath();c.ellipse(cx,by+24,14,4,0,0,7);c.fill();rr(c,cx-12,by+8,24,14,6);c.fillStyle="#4a5263";c.fill()}}
function mtableDraw(c,p){const x=p.x*T,y=p.y*T,W=(p.w||5)*T,H=(p.h||2)*T,wl=WL();
 const seat=(sx,sy)=>{c.beginPath();c.arc(sx,sy,7,0,7);c.fillStyle=wl?"#e4e7ec":"#2a3142";c.fill();c.strokeStyle=wl?"#c9cfd8":"#3d4659";c.lineWidth=1;c.stroke()};
 for(let i=0;i<4;i++){seat(x+W*(i+.5)/4,y-2);seat(x+W*(i+.5)/4,y+H+2)}seat(x-4,y+H/2);seat(x+W+4,y+H/2);
 c.save();c.shadowColor=wl?"rgba(16,24,40,.10)":"rgba(0,0,0,.4)";c.shadowBlur=10*cam.z*RDPR();c.shadowOffsetY=3*cam.z*RDPR();c.beginPath();c.roundRect(x+4,y+6,W-8,H-12,(H-12)/2);c.fillStyle=wl?"#ffffff":"#3a4356";c.fill();c.restore();
 c.beginPath();c.roundRect(x+4,y+6,W-8,H-12,(H-12)/2);c.strokeStyle=wl?"#d0d5dd":"#5a6683";c.lineWidth=1;c.stroke();
 c.fillStyle=wl?"#98a2b3":"#a78bfa";c.globalAlpha=.6;c.beginPath();c.roundRect(x+W/2-18,y+H/2-1.5,36,3,1.5);c.fill();c.globalAlpha=1}
/* ---- extras that make the bridge feel special ---- */
function hubExtra(c,now){
 const r=MAP.R.find(q=>q.hub);if(!r)return;const X=r.x*T,Y=r.y*T,W=r.w*T,H=r.h*T;
 /* big wall viewscreen */
 const sw=Math.min(W*.5,200),sx=X+W/2-sw/2,sy=Y-24;
 c.save();rr(c,sx-3,sy-3,sw+6,22,4);const wl=WL();c.fillStyle=wl?"#d7dde6":vgrad_(c,sy-3,sy+19,"#d9b84a","#6b5217");c.fill();rr(c,sx,sy,sw,16,3);c.fillStyle=wl?"#ffffff":"#050816";c.fill();
 const gg=c.createLinearGradient(sx,sy,sx+sw,sy);gg.addColorStop(0,"rgba(110,231,255,.18)");gg.addColorStop(.5,"rgba(167,139,250,.28)");gg.addColorStop(1,"rgba(110,231,255,.18)");c.fillStyle=gg;c.fillRect(sx,sy,sw,16);
 c.save();c.beginPath();c.rect(sx,sy,sw,16);c.clip();c.strokeStyle=wl?"rgba(124,92,240,.9)":"rgba(196,181,253,.9)";c.lineWidth=1;c.beginPath();for(let i=0;i<=sw;i+=3){const v=8+Math.sin(i*.09+now/400)*4+Math.sin(i*.31+now/230)*1.6;i?c.lineTo(sx+i,sy+v):c.moveTo(sx,sy+v)}c.stroke();
 c.fillStyle=wl?"rgba(124,92,240,.5)":"rgba(255,255,255,.8)";for(let i=0;i<14;i++){const px=sx+((hash(i,7)%sw)+now/40*(1+i%3*.3))%sw;c.fillRect(px,sy+2+(hash(i,3)%12),1,1)}c.restore();c.restore();
 /* gold inlay + glowing curved window band */
 const half=r.shape=="half";
 c.save();c.strokeStyle="rgba(245,197,66,.6)";c.lineWidth=1.4;if(half)halfPath(c,X,Y,W,H,12);else rr(c,X+12,Y+12,W-24,H-24,8);c.stroke();c.strokeStyle="rgba(245,197,66,.16)";c.lineWidth=5;c.stroke();
 if(half){const p=.5+.5*Math.sin(now/900);c.strokeStyle="rgba(167,139,250,"+(.35+p*.25)+")";c.lineWidth=2;halfPath(c,X,Y,W,H,3);c.stroke()}
 const k=half?[[X+12,Y+12,1,1],[X+W-12,Y+12,-1,1]]:[[X+12,Y+12,1,1],[X+W-12,Y+12,-1,1],[X+12,Y+H-12,1,-1],[X+W-12,Y+H-12,-1,-1]];c.fillStyle=GOLD;k.forEach(([a,b,dx,dy])=>{c.beginPath();c.moveTo(a,b);c.lineTo(a+dx*14,b);c.lineTo(a,b+dy*14);c.fill()});c.restore()}
function halfPath(c,X,Y,W,H,i){c.beginPath();c.moveTo(X+i,Y+i);c.lineTo(X+W-i,Y+i);c.ellipse(X+W/2,Y+i,W/2-i,H-i,0,0,Math.PI);c.closePath()}
function vgrad_(c,y0,y1,a,b){const g=c.createLinearGradient(0,y0,0,y1);g.addColorStop(0,a);g.addColorStop(1,b);return g}
/* carpet runway under the executive desk (drawn with the floor decor) */
function hubCarpet(c,now){if(WL())return;const r=MAP.R.find(q=>q.hub),b=MAP.props.find(p=>p.t=="boss");if(!r||!b)return;const W=(b.w||3)*32,x=b.x*T-14,y=b.y*T+2,w=W+28,h=r.shape=="half"?T*4.4:(r.y+r.h-1)*T-y-T*2;
 c.save();rr(c,x,y,w,h,10);let q=c.createLinearGradient(x,y,x,y+h);const wl=WL();q.addColorStop(0,wl?"rgba(124,92,240,.16)":"rgba(88,28,135,.8)");q.addColorStop(1,wl?"rgba(124,92,240,.04)":"rgba(60,24,110,.2)");c.fillStyle=q;c.fill();c.strokeStyle="rgba(245,197,66,.8)";c.lineWidth=1.6;rr(c,x+4,y+4,w-8,h-8,8);c.stroke();c.strokeStyle="rgba(245,197,66,.35)";c.lineWidth=.8;rr(c,x+8,y+8,w-16,h-16,6);c.stroke();c.restore()}
/* the commander's chair: a high-backed throne facing the curved wall (drawn before the seated boss) */
function throneDraw(c,bs,now){
 if(WL())return officeChair(c,bs,false);
 const cx=(bs.x+.5)*T,by=bs.y*T;
 const s=PSPR("throne",64,64,0,g=>{
  g.fillStyle="#1a1236";g.beginPath();g.ellipse(32,54,22,7,0,0,7);g.fill();
  /* back */
  g.fillStyle=vgrad(g,2,44,[[0,"#7c5bd6"],[.5,"#4a2f9a"],[1,"#24165a"]]);g.beginPath();g.moveTo(12,44);g.lineTo(12,14);g.quadraticCurveTo(12,3,32,3);g.quadraticCurveTo(52,3,52,14);g.lineTo(52,44);g.closePath();g.fill();
  g.strokeStyle=GOLD;g.lineWidth=1.8;g.stroke();g.strokeStyle="rgba(255,255,255,.2)";g.lineWidth=.8;g.beginPath();g.moveTo(16,40);g.lineTo(16,15);g.quadraticCurveTo(16,7,32,7);g.stroke();
  g.fillStyle=GOLD;g.beginPath();for(let k=0;k<10;k++){const q_=k%2?2.4:5.6,a=-Math.PI/2+k*Math.PI/5;g.lineTo(32+Math.cos(a)*q_,13+Math.sin(a)*q_)}g.closePath();g.fill();
  /* arm rests */
  for(const ax of[4,50]){g.fillStyle=vgrad(g,30,56,[[0,"#7a5ad0"],[1,"#2c1a6a"]]);g.beginPath();g.roundRect(ax,30,10,24,4);g.fill();g.strokeStyle=GOLD;g.lineWidth=1.2;g.stroke()}
  /* seat cushion */
  g.fillStyle=vgrad(g,40,56,[[0,"#9a7cf0"],[1,"#4a2f9a"]]);g.beginPath();g.roundRect(13,42,38,13,5);g.fill();g.strokeStyle="rgba(245,197,66,.8)";g.lineWidth=1;g.stroke()},"x");
 c.drawImage(LS(s),cx-32,by-30,64,64)}

/* back-view chair: the low backrest in front of the seated boss (he faces his desk, back to the camera) */
function throneBack(c,bs,now){
 if(WL())return;
 const cx=(bs.x+.5)*T,by=bs.y*T;
 const s=PSPR("thrBack",44,24,0,g=>{
  g.fillStyle="rgba(0,0,10,.35)";g.beginPath();g.ellipse(22,21,18,3,0,0,7);g.fill();
  g.fillStyle=vgrad(g,0,22,[[0,"#7c5bd6"],[1,"#2c1a6a"]]);g.beginPath();g.roundRect(3,2,38,19,6);g.fill();
  g.strokeStyle=GOLD;g.lineWidth=1.4;g.stroke();g.strokeStyle="rgba(255,255,255,.22)";g.lineWidth=.8;g.beginPath();g.roundRect(6,4.6,32,12.6,4);g.stroke();
  g.fillStyle=GOLD;g.beginPath();for(let k=0;k<10;k++){const q_=k%2?1.6:3.6,a=-Math.PI/2+k*Math.PI/5;g.lineTo(22+Math.cos(a)*q_,11+Math.sin(a)*q_)}g.closePath();g.fill()},"x");
 c.drawImage(LS(s),cx-22,by+4,44,24)}
/* ===== v9.1: room-coloured agents + the boss ===== */
function roomColOf(a){if(a.boss){const h=MAP&&MAP.R.find(r=>r.hub);return(h&&h.color)||"#475467"}const r=S.rooms.find(q=>q.id==a.room);return r?r.color:"#4f6d8f"}
function lookFor(L,boss,col){L=L||DEFL;if(boss&&WL())return{...L,suit:"#334155",trim:"#1e293b",tag:"#334155",outfit:1};if(boss)return{...L,suit:col,trim:col,tag:GOLD,outfit:1};const o=(L.outfit|0)%2;return{...L,suit:col,trim:o?col:mixc(col,"#0b0f1a",.55),tag:col,outfit:o}}
function previewLoop(){const c=$("pv");if(!$("dg").open)return;const g=c.getContext("2d");g.clearRect(0,0,c.width,c.height);g.imageSmoothingEnabled=true;g.imageSmoothingQuality="high";
 const boss=$("bs")&&$("bs").checked,rid=$("rm")&&$("rm").value,rm=S.rooms.find(r=>r.id==rid),hub=MAP&&MAP.R.find(r=>r.hub),col=boss?((hub&&hub.color)||"#a78bfa"):(rm?rm.color:"#6ee7ff"),L=lookFor(curLook,boss,col);
 const f=1+Math.floor(performance.now()/110)%8,h=c.height-4,w=h*CW/CH;[0,2,3,1].forEach((d,i)=>g.drawImage(charSprite(L,d,f,false),i*(c.width/4)+(c.width/4-w)/2,2,w,h));requestAnimationFrame(previewLoop)}
function agentShadow(c,a,s,now){if(WL())return;const sitN=s.sit&&!s.moving,col=roomColOf(a),x=s.x*T,y=s.y*T+(sitN?12:13);
 if(WL()){c.fillStyle="rgba(16,24,40,.14)";c.beginPath();c.ellipse(x+1,y+1,11,4.2,0,0,7);c.fill();if(!a.boss){c.strokeStyle=rgba(col,.55);c.lineWidth=1.2;c.beginPath();c.ellipse(x,y,12,5,0,0,7);c.stroke()}if(typeof sel!="undefined"&&a.id==sel){c.strokeStyle="#2563eb";c.lineWidth=1.4;c.beginPath();c.ellipse(x,y,a.boss?20:16,a.boss?8:6.5,0,0,7);c.stroke()}return}
 const q=c.createRadialGradient(x,y,1,x,y,12);q.addColorStop(0,"rgba(0,0,10,.55)");q.addColorStop(1,"rgba(0,0,10,0)");c.fillStyle=q;c.beginPath();c.ellipse(x+1.5,y+1,11.5,4.6,0,0,7);c.fill();
 if(a.boss){const p=.5+.5*Math.sin(now/420);
  const gg=c.createRadialGradient(x,y,2,x,y,30);gg.addColorStop(0,"rgba(245,197,66,.40)");gg.addColorStop(1,"rgba(245,197,66,0)");c.fillStyle=gg;c.beginPath();c.ellipse(x,y,30,12,0,0,7);c.fill();
  c.strokeStyle="rgba(245,197,66,"+(.7+p*.3)+")";c.lineWidth=2.2;c.beginPath();c.ellipse(x,y,17+p*2,7+p,0,0,7);c.stroke();c.strokeStyle="rgba(255,255,255,.55)";c.lineWidth=1;c.beginPath();c.ellipse(x,y,22+p*3,9+p*1.2,0,0,7);c.stroke()}
 else{c.fillStyle=rgba(col,.20);c.beginPath();c.ellipse(x,y,12.5,5.2,0,0,7);c.fill();c.strokeStyle=rgba(col,.95);c.lineWidth=1.9;c.beginPath();c.ellipse(x,y,12.5,5.2,0,0,7);c.stroke()}
 if(typeof sel!="undefined"&&a.id==sel){c.strokeStyle="#ffffff";c.lineWidth=1.4;c.setLineDash([4,3]);c.lineDashOffset=-now/60;c.beginPath();c.ellipse(x,y,(a.boss?28:17),(a.boss?11:7),0,0,7);c.stroke();c.setLineDash([])}}
function crown(c,cx,top,w){c.save();c.translate(cx,top);const g=c.createLinearGradient(0,-8,0,3);g.addColorStop(0,"#fff0b0");g.addColorStop(1,"#c8921a");c.fillStyle=g;c.strokeStyle="#6b4a08";c.lineWidth=.9;
 c.beginPath();c.moveTo(-w/2,3);c.lineTo(-w/2,-3);c.lineTo(-w/4,-9);c.lineTo(-w/8,-4);c.lineTo(0,-12);c.lineTo(w/8,-4);c.lineTo(w/4,-9);c.lineTo(w/2,-3);c.lineTo(w/2,3);c.closePath();c.fill();c.stroke();
 c.fillStyle="#ff4d6d";c.beginPath();c.arc(0,-1,1.9,0,7);c.fill();c.fillStyle="#5ee0ff";c.beginPath();c.arc(-w/3.2,0,1.2,0,7);c.arc(w/3.2,0,1.2,0,7);c.fill();c.restore()}
function cape(c,col,dy,sway){const g=c.createLinearGradient(0,34+dy,0,106+dy);g.addColorStop(0,mixc(col,"#ffffff",.12));g.addColorStop(1,mixc(col,"#05030f",.7));c.fillStyle=g;c.strokeStyle=GOLD;c.lineWidth=1.8;
 c.beginPath();c.moveTo(27,36+dy);c.quadraticCurveTo(42,30+dy,57,36+dy);c.lineTo(66+sway,100+dy);c.quadraticCurveTo(54,106+dy,42,101+dy);c.quadraticCurveTo(30,106+dy,18-sway,100+dy);c.closePath();c.fill();c.stroke()}
function tokenDraw(c,a,s,now){const sitN=s.sit&&!s.moving,boss=!!a.boss,col=boss?"#334155":roomColOf(a),busy=S.busy&&a.status&&a.status!="Idle",wait=(S.pending||[]).some(p=>p.who==a.name),stuck=/^(Stuck|Error)/.test(a.status||"");
 const R=boss?13:10,cx=s.x*T,cy=s.y*T+(sitN?4:-2)-(s.moving?Math.abs(Math.sin(now/110))*1.6:0),ic=typeof ink=="function"?ink(col):col;
 if(busy&&!wait&&!stuck){const p=.5+.5*Math.sin(now/380);c.beginPath();c.arc(cx,cy,R+3+p*2,0,7);c.fillStyle="rgba(18,128,92,"+(.10+p*.08)+")";c.fill()}
 c.save();c.shadowColor="rgba(16,24,40,.18)";c.shadowBlur=6*cam.z*RDPR();c.shadowOffsetY=1.5*cam.z*RDPR();c.beginPath();c.arc(cx,cy,R,0,7);c.fillStyle=boss?"#334155":"#ffffff";c.fill();c.restore();
 c.beginPath();c.arc(cx,cy,R-.8,0,7);c.strokeStyle=boss?"#1e293b":ic;c.lineWidth=boss?1.4:2;c.stroke();
 c.fillStyle=boss?"#ffffff":ic;c.font="600 "+(boss?12:10.5)+"px 'Segoe UI',system-ui,sans-serif";c.textAlign="center";c.textBaseline="middle";c.fillText((a.name||"?")[0].toUpperCase(),cx,cy+.5);
 const dc=wait?"#f79009":stuck?"#d92d20":busy?"#12b76a":null;if(dc){c.beginPath();c.arc(cx+R*.72,cy+R*.72,3.6,0,7);c.fillStyle=dc;c.fill();c.strokeStyle="#ffffff";c.lineWidth=1.4;c.stroke()}
 if(typeof sel!="undefined"&&a.id==sel){c.beginPath();c.arc(cx,cy,R+4,0,7);c.strokeStyle="#2563eb";c.lineWidth=1.6;c.stroke()}}
/* v15.1: people in suits (white theme / office). Suit colour = their team's colour; everyone wears a tie. */
function personDraw(c,a,s,now){const sitN=s.sit&&!s.moving,boss=!!a.boss,col=boss?"#1f2937":roomColOf(a),L=a.look||{},skin=L.skin||"#e8b48a",HN=["#2b1d14","#4a3222","#6b4423","#1f1f1f","#a8875a","#8d8d8d","#3b2a20"],hair=HN[[...String(a.id||a.name)].reduce((n,ch)=>n+ch.charCodeAt(0),0)%HN.length];
 const back=sitN||s.dir==1,k=boss?1.12:1,x=s.x*T,y=s.y*T+(sitN?4:11),step=s.moving?Math.sin(now/85):0;
 const busy=S.busy&&a.status&&a.status!="Idle",wait=(S.pending||[]).some(p=>p.who==a.name),stuck=/^(Stuck|Error)/.test(a.status||""),typing=sitN&&busy;
 const dark=mixc(col,"#0b0f1a",.38),edge=mixc(col,"#000000",.28);
 c.save();c.translate(x,y);c.scale(k,k);
 c.fillStyle="rgba(16,24,40,.15)";c.beginPath();c.ellipse(0,0,9.5,3.2,0,0,7);c.fill();
 if(typeof sel!="undefined"&&a.id==sel){c.strokeStyle="#2563eb";c.lineWidth=1.5;c.beginPath();c.ellipse(0,0,12,4.5,0,0,7);c.stroke()}
 if(!sitN){c.fillStyle=dark;rr(c,-5,-10+(step>0?-1.2:0),4.4,10,1.6);c.fill();rr(c,.6,-10+(step<0?-1.2:0),4.4,10,1.6);c.fill();
  c.fillStyle="#1d2433";rr(c,-5.6,-1.8,5.4,2.6,1.2);c.fill();rr(c,.4,-1.8,5.4,2.6,1.2);c.fill()}
 const bt=sitN?-21:-26,bh=sitN?16:17;
 c.fillStyle=dark;rr(c,-11.5,bt+2.5,4.2,11.5+(typing?Math.sin(now/80):0),2);c.fill();rr(c,7.3,bt+2.5,4.2,11.5+(typing?Math.cos(now/80):0),2);c.fill();
 rr(c,-9,bt,18,bh,5);c.fillStyle=col;c.fill();c.strokeStyle=edge;c.lineWidth=.7;c.stroke();
 if(!back){c.fillStyle="#ffffff";c.beginPath();c.moveTo(-4.2,bt+.2);c.lineTo(4.2,bt+.2);c.lineTo(0,bt+9.5);c.closePath();c.fill();
  c.fillStyle=boss?"#7a1f2b":"#1e293b";c.beginPath();c.moveTo(-1.3,bt+1);c.lineTo(1.3,bt+1);c.lineTo(1.9,bt+8.5);c.lineTo(0,bt+11.5);c.lineTo(-1.9,bt+8.5);c.closePath();c.fill();
  c.strokeStyle=edge;c.lineWidth=.8;c.beginPath();c.moveTo(-4.4,bt);c.lineTo(-.6,bt+9.6);c.moveTo(4.4,bt);c.lineTo(.6,bt+9.6);c.stroke();
  c.fillStyle=edge;c.beginPath();c.arc(0,bt+12.6,.8,0,7);c.arc(0,bt+15,.8,0,7);c.fill()}
 else{c.strokeStyle=edge;c.lineWidth=.8;c.beginPath();c.moveTo(0,bt+3);c.lineTo(0,bt+bh-1);c.stroke();c.fillStyle="#ffffff";rr(c,-3,bt-.6,6,2,1);c.fill()}
 const hy=bt-6.2;c.fillStyle=skin;rr(c,-2,hy+4,4,3,1);c.fill();c.beginPath();c.arc(0,hy,6.2,0,7);c.fill();
 c.fillStyle=hair;c.beginPath();if(back)c.arc(0,hy-.2,6.5,0,7);else{c.arc(0,hy-.6,6.5,Math.PI*1.02,Math.PI*1.98);c.quadraticCurveTo(4,hy-3.2,0,hy-3.4);c.quadraticCurveTo(-4,hy-3.2,-6.4,hy-1)}c.fill();
 c.restore();
 const dc=wait?"#f79009":stuck?"#d92d20":busy?"#12b76a":null;if(dc){const dx=x+8*k,dy=y+(bt-11)*k;c.beginPath();c.arc(dx,dy,3.4,0,7);c.fillStyle=dc;c.fill();c.strokeStyle="#ffffff";c.lineWidth=1.3;c.stroke()}}
function agentDraw(c,a,s,now){if(WL())return personDraw(c,a,s,now);const sitN=s.sit&&!s.moving,boss=!!a.boss,col=roomColOf(a),L=lookFor(a.look,boss,col),busy=S.busy&&a.status!="Idle";let fr=0,typing=false;
 if(sitN){typing=busy&&s.dir==1;fr=typing?1+(((now/120)|0)%4):0}else if(s.moving)fr=1+(Math.floor(s.fr)%8);
 const img=charSprite(L,s.dir,fr,sitN,typing),gx=s.x*T,gy=s.y*T+(sitN?11:12),bs=boss?(WL()?1.15:1.45):1,dy=sitN?24:0;
 const jump=s.cel>now?Math.abs(Math.sin(now/120))*5:0,br=(!s.moving&&!sitN)?1+Math.sin(now/760+a.name.length)*.010:1,bob=(s.moving?-Math.abs(Math.cos((fr-1)/8*Math.PI*2))*2.1:0);
 c.save();c.translate(gx,gy-jump);c.scale(CF*bs,CF*bs*br);c.translate(-42,-112);
 const fancy=boss&&!WL();
 if(fancy&&s.dir!=1)cape(c,col,dy,s.moving?Math.sin(now/130)*3:0);
 c.drawImage(mipFor(img,CH*CF*bs*cam.z*RDPR()),0,0,CW,CH);
 if(fancy){if(s.dir==1)cape(c,col,dy,0);
  if(s.dir<2||s.dir==1){for(const sg of[-1,1]){const ex=42+sg*17.6,ey=36+dy+bob;c.fillStyle="#d9a526";c.strokeStyle="#6b4a08";c.lineWidth=.8;c.beginPath();c.ellipse(ex,ey,6,3.4,0,0,7);c.fill();c.stroke();c.fillStyle="#fff0b0";c.fillRect(ex-3,ey-1,6,1.2);c.fillStyle="#d9a526";for(let k=-2;k<=2;k++)c.fillRect(ex+k*2.2-.5,ey+3,1,3.2)}}
  crown(c,42,(L.style==4?1:5)+dy+bob,s.dir>=2?15:19)}
 c.restore();celebrate(c,s,gx,gy-jump,now)}

/* v13: pre-shrunk copies of each character sprite (halved step by step), so the screen never has to squash a big image every frame */
function mipFor(img,h){if(h>=img.height*.75)return img;let m=img._m;if(!m)m=img._m=[img];let i=0;
 while(m[i].height*.5>=h&&m[i].height>24){if(!m[i+1]){const a=m[i],b=mk(a.width/2,a.height/2),g=b.getContext("2d");g.imageSmoothingEnabled=true;g.imageSmoothingQuality="high";g.drawImage(a,0,0,b.width,b.height);m[i+1]=b}i++}
 return m[i]}
