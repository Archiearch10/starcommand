"""StarCommand v13: Video Studio (faceless Shorts) and printable PDFs.

make_video  script.json -> vertical 1080x1920 MP4 with AI voice, stock clips (Pexels or Pixabay) or AI images, and captions
yt_*        YouTube connect (OAuth, loopback) and upload (YouTube Data API v3, resumable)
make_pdf    HTML -> A4 / US Letter PDF (+ preview PNG) with the headless browser
"""
import os,re,sys,json,time,shutil,random,secrets,subprocess,threading,urllib.request,urllib.parse,urllib.error,asyncio
from pathlib import Path
class MediaError(Exception):pass
CFG={"port":8766}
def init(**k):CFG.update(k)
NOWIN=0x08000000 if os.name=="nt" else 0
_TRIED=set()
PIPERR={}
def _py():
    "python.exe (not pythonw.exe) so pip can run properly"
    e=sys.executable
    if os.name=="nt" and os.path.basename(e).lower()=="pythonw.exe":
        c=os.path.join(os.path.dirname(e),"python.exe")
        if os.path.exists(c):return c
    return e
def _pip(*pk):
    """v15.21: tries a normal install, then a per-user install (no administrator needed), and repairs pip if it is missing.
    The last error is kept so the message can say what actually went wrong."""
    base=[_py(),"-m","pip","install","--disable-pip-version-check","--no-input","--prefer-binary"]
    last=""
    for extra in([],["--user"],"ensurepip",["--user"]):
        try:
            if extra=="ensurepip":
                subprocess.run([_py(),"-m","ensurepip","--upgrade","--default-pip"],capture_output=True,text=True,timeout=300,creationflags=NOWIN);continue
            r=subprocess.run(base+extra+list(pk),capture_output=True,text=True,timeout=600,creationflags=NOWIN)
            if r.returncode==0:PIPERR.pop(pk[0],None);break
            out=((r.stderr or "")+"\n"+(r.stdout or "")).strip().splitlines()
            last=next((l for l in reversed(out) if re.search(r"error|denied|failed|No matching|could not|Microsoft Visual C\+\+",l,re.I)),out[-1] if out else "pip failed")
        except Exception as e:last=str(e)
    if last:PIPERR[pk[0]]=last.strip()[:240]
    import importlib;importlib.invalidate_caches()
    try:
        import site;p=site.getusersitepackages()
        if os.path.isdir(p) and p not in sys.path:sys.path.append(p)
    except Exception:pass
def _need(mod,pkg,why):
    try:return __import__(mod)
    except Exception:pass
    if pkg not in _TRIED:_TRIED.add(pkg);_pip(pkg)
    try:return __import__(mod)
    except Exception:
        _TRIED.discard(pkg)
        why_err=PIPERR.get(pkg,"")
        raise MediaError("Could not install %s (%s).%s Check your internet connection, or open a command window and run:  py -m pip install --user %s"%(pkg,why," Reason: "+why_err+"." if why_err else "",pkg))
# ---------------------------------------------------------------- ffmpeg
def ffmpeg():
    p=shutil.which("ffmpeg")
    if p:return p
    return _need("imageio_ffmpeg","imageio-ffmpeg","the video maker").get_ffmpeg_exe()
def run_ff(args,timeout=900,cwd=None):
    r=subprocess.run([ffmpeg(),"-hide_banner","-loglevel","error","-y",*args],capture_output=True,text=True,timeout=timeout,cwd=cwd,creationflags=NOWIN)
    if r.returncode!=0:raise MediaError("The video tool (ffmpeg) failed: "+(r.stderr or "").strip()[-500:])
def duration(path):
    r=subprocess.run([ffmpeg(),"-hide_banner","-i",path],capture_output=True,text=True,creationflags=NOWIN)
    m=re.search(r"Duration: (\d+):(\d+):([\d.]+)",r.stderr or "")
    if not m:raise MediaError("Could not read the length of "+os.path.basename(path))
    return int(m.group(1))*3600+int(m.group(2))*60+float(m.group(3))
# ---------------------------------------------------------------- voice
VOICES={"en-GB-RyanNeural":"British male","en-GB-SoniaNeural":"British female","en-US-GuyNeural":"American male","en-US-JennyNeural":"American female","en-AU-WilliamNeural":"Australian male"}
def tts(text,base,voice=""):
    """Returns the path of an audio file. Free voices: Microsoft Edge online voices, then the Windows built-in voice."""
    voice=voice if voice in VOICES else "en-GB-RyanNeural";errs=[]
    if os.environ.get("STARCOMMAND_FAKE_TTS"):
        d=max(1.2,len(text.split())/2.7);out=base+".wav"
        run_ff(["-f","lavfi","-i","sine=frequency=200:duration=%.2f"%d,"-ac","2","-ar","44100",out]);return out
    try:
        et=_need("edge_tts","edge-tts","the AI voice");out=base+".mp3"
        async def go():await et.Communicate(text,voice,rate="+6%").save(out)
        asyncio.run(go())
        if os.path.getsize(out)>800:return out
        errs.append("Edge voice returned no audio")
    except Exception as e:errs.append("Edge voice: %s"%str(e)[:160])
    if os.name=="nt":
        out=base+".wav";tf=base+".txt";open(tf,"w",encoding="utf8").write(text)
        ps="$t=Get-Content -Raw -Encoding UTF8 '%s';Add-Type -AssemblyName System.Speech;$s=New-Object System.Speech.Synthesis.SpeechSynthesizer;$s.Rate=1;$s.SetOutputToWaveFile('%s');$s.Speak($t);$s.Dispose()"%(tf.replace("'","''"),out.replace("'","''"))
        r=subprocess.run(["powershell","-NoProfile","-ExecutionPolicy","Bypass","-Command",ps],capture_output=True,text=True,timeout=180,creationflags=NOWIN)
        if os.path.exists(out) and os.path.getsize(out)>2000:return out
        errs.append("Windows voice: %s"%(r.stderr or "no audio")[:160])
    raise MediaError("No voice could be made. "+" | ".join(errs))
# ---------------------------------------------------------------- pictures
def _pil():
    _need("PIL","pillow","captions");from PIL import Image,ImageDraw,ImageFont;return Image,ImageDraw,ImageFont
FONTS=[r"C:\Windows\Fonts\arialbd.ttf",r"C:\Windows\Fonts\segoeuib.ttf","/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf","/System/Library/Fonts/Supplemental/Arial Bold.ttf"]
def _font(sz):
    _,_,IF=_pil()
    for f in FONTS:
        if os.path.exists(f):return IF.truetype(f,sz)
    try:return IF.load_default(sz)
    except TypeError:return IF.load_default()
def chunks(text,n=3):
    out=[];cur=[]
    for w in text.split():
        cur.append(w)
        if len(cur)>=n or re.search(r"[.!?,;:]$",w):out.append(" ".join(cur));cur=[]
    if cur:out.append(" ".join(cur))
    return out
def caption_png(text,dest):
    Image,ImageDraw,_=_pil();f=_font(84);im=Image.new("RGBA",(1080,420),(0,0,0,0));d=ImageDraw.Draw(im)
    words=text.split();lines=[];cur=""
    for w in words:
        t=(cur+" "+w).strip()
        if d.textlength(t,font=f)>960 and cur:lines.append(cur);cur=w
        else:cur=t
    if cur:lines.append(cur)
    y=(420-len(lines)*100)//2
    for ln in lines:
        x=(1080-d.textlength(ln,font=f))/2;d.text((x,y),ln,font=f,fill=(255,255,255),stroke_width=9,stroke_fill=(0,0,0));y+=100
    im.save(dest);return dest
def gradient(dest,seed=0):
    Image,ImageDraw,_=_pil();rnd=random.Random(seed);a=[rnd.randint(10,80) for _ in range(3)];b=[rnd.randint(90,200) for _ in range(3)]
    im=Image.new("RGB",(1188,2112));d=ImageDraw.Draw(im)
    for y in range(2112):
        k=y/2111;d.line([(0,y),(1188,y)],fill=tuple(int(a[i]+(b[i]-a[i])*k) for i in range(3)))
    im.save(dest);return dest
def _req(url,headers=None,data=None,method=None,timeout=60):
    return urllib.request.urlopen(urllib.request.Request(url,data=data,headers=dict({"User-Agent":"StarCommand/13"},**(headers or {})),method=method),timeout=timeout)
def pexels_clip(query,dest,key,used):
    u="https://api.pexels.com/videos/search?"+urllib.parse.urlencode({"query":query,"orientation":"portrait","per_page":15})
    j=json.load(_req(u,{"Authorization":key},timeout=30))
    vids=[v for v in j.get("videos",[]) if v.get("duration",0)>=3 and str(v.get("id")) not in used] or [v for v in j.get("videos",[]) if v.get("duration",0)>=3]
    if not vids:return None
    v=random.choice(vids[:5]);fs=[f for f in v.get("video_files",[]) if f.get("width") and f.get("height") and f["height"]>=f["width"]]
    if not fs:return None
    ok=sorted([f for f in fs if f["width"]>=720],key=lambda f:f["width"]) or sorted(fs,key=lambda f:-f["width"])
    with _req(ok[0]["link"],timeout=120) as r,open(dest,"wb") as o:
        n=0
        while True:
            b=r.read(1<<16)
            if not b:break
            n+=len(b);o.write(b)
            if n>150_000_000:raise MediaError("stock clip too large")
    used.append(str(v["id"]));return "Video by %s on Pexels"%(v.get("user") or {}).get("name","a Pexels creator")
PIXABAY="https://pixabay.com/api/videos/"
def _download(url,dest):
    with _req(url,timeout=120) as r,open(dest,"wb") as o:
        n=0
        while True:
            b=r.read(1<<16)
            if not b:break
            n+=len(b);o.write(b)
            if n>150_000_000:raise MediaError("stock clip too large")
def pixabay_clip(query,dest,key,used):
    """free stock videos from Pixabay (pixabay.com/api/docs). Mostly landscape; the video maker crops them to vertical."""
    u=os.environ.get("STARCOMMAND_PIXABAY_URL",PIXABAY)+"?"+urllib.parse.urlencode({"key":key,"q":query[:95],"per_page":20,"safesearch":"true"})
    j=json.load(_req(u,timeout=30))
    hits=[h for h in j.get("hits",[]) if h.get("duration",0)>=3 and "pb"+str(h.get("id")) not in used] or [h for h in j.get("hits",[]) if h.get("duration",0)>=3]
    if not hits:
        w=query.split()
        if len(w)>1:return pixabay_clip(" ".join(w[:max(1,len(w)//2)]),dest,key,used)
        return None
    h=random.choice(hits[:6]);vs=h.get("videos") or {}
    # prefer portrait files, then a size that is sharp enough without being huge
    fs=[vs[k] for k in("large","medium","small","tiny") if (vs.get(k) or {}).get("url")]
    port=[f for f in fs if f.get("height",0)>=f.get("width",1)]
    pick=(port or [f for f in fs if f.get("height",0)>=1080] or [f for f in fs if f.get("height",0)>=720] or fs)
    if not pick:return None
    _download(pick[0]["url"],dest);used.append("pb"+str(h["id"]))
    return "Video by %s on Pixabay"%(h.get("user") or "a Pixabay creator")
def background(s,i,tmp,key,gen_image,used,log,pixabay_key=""):
    q=str(s.get("search") or s.get("say",""))[:80]
    if key and not os.environ.get("STARCOMMAND_FAKE_PEXELS"):
        try:
            c=pexels_clip(q,os.path.join(tmp,"bg%02d.mp4"%i),key,used)
            if c:return os.path.join(tmp,"bg%02d.mp4"%i),True,c
            log("no Pexels clip found for '%s'"%q)
        except Exception as e:log("Pexels failed for '%s' (%s)"%(q,str(e)[:80]))
    if pixabay_key and not os.environ.get("STARCOMMAND_FAKE_PEXELS"):
        try:
            c=pixabay_clip(q,os.path.join(tmp,"bg%02d.mp4"%i),pixabay_key,used)
            if c:return os.path.join(tmp,"bg%02d.mp4"%i),True,c
            log("no Pixabay clip found for '%s', using a picture instead"%q)
        except Exception as e:log("Pixabay failed for '%s' (%s), using a picture instead"%(q,str(e)[:80]))
    if gen_image and not os.environ.get("STARCOMMAND_FAKE_PEXELS"):
        try:
            p=os.path.join(tmp,"bg%02d.png"%i);gen_image(str(s.get("image_prompt") or "vertical photo, "+q),p);return p,False,""
        except Exception as e:log("image generator failed (%s), using a colour background"%str(e)[:80])
    return gradient(os.path.join(tmp,"bg%02d.png"%i),i),False,""
# ---------------------------------------------------------------- video
def render_scene(bg,isv,audio,caps,dur,out):
    a=(["-stream_loop","-1","-i",bg] if isv else ["-loop","1","-framerate","30","-i",bg])+["-i",audio]
    for p,_,_ in caps:a+=["-i",p]
    if isv:f="[0:v]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,setsar=1,fps=30[b0]"
    else:f="[0:v]scale=1188:2112:force_original_aspect_ratio=increase,crop=1188:2112,crop=1080:1920:x='(in_w-out_w)*t/%.2f':y='(in_h-out_h)/2',setsar=1,fps=30[b0]"%max(dur,0.5)
    for k,(_,s,e) in enumerate(caps):f+=";[b%d][%d:v]overlay=(W-w)/2:H*0.60:enable='between(t,%.2f,%.2f)'[b%d]"%(k,k+2,s,e,k+1)
    f+=";[1:a]apad,aresample=44100[a]"
    run_ff(a+["-filter_complex",f,"-map","[b%d]"%len(caps),"-map","[a]","-t","%.2f"%dur,"-c:v","libx264","-preset","veryfast","-crf","22","-pix_fmt","yuv420p","-r","30","-c:a","aac","-b:a","160k","-ac","2",out])
def load_script(path):
    try:sc=json.load(open(path,encoding="utf8"))
    except Exception as e:raise MediaError("The script file is not valid JSON (%s). Expected {\"title\":\"...\",\"description\":\"...\",\"tags\":[...],\"scenes\":[{\"say\":\"...\",\"search\":\"...\"}]}"%str(e)[:120])
    sc["scenes"]=[x for x in sc.get("scenes",[]) if isinstance(x,dict) and str(x.get("say","")).strip()]
    if not sc["scenes"]:raise MediaError('The script has no scenes. Each scene needs "say" (the narration) and "search" (2-4 words for the stock clip).')
    if len(sc["scenes"])>14:raise MediaError("Too many scenes (%d). Use 4 to 10."%len(sc["scenes"]))
    w=sum(len(x["say"].split()) for x in sc["scenes"])
    if w>380:raise MediaError("The script is too long (%d words). Shorts must be under 3 minutes; aim for 90 to 160 words."%w)
    return sc
def make_video(script_file,out,pexels_key="",voice="",gen_image=None,tiktok_dir=None,log=print,pixabay_key=""):
    sc=load_script(script_file);os.makedirs(os.path.dirname(out) or ".",exist_ok=True)
    tmp=out+".parts";shutil.rmtree(tmp,ignore_errors=True);os.makedirs(tmp)
    uf=os.path.join(os.path.dirname(out),".used-clips.json")
    try:used=json.load(open(uf))
    except Exception:used=[]
    credits=[];parts=[]
    try:
        for i,s in enumerate(sc["scenes"]):
            au=tts(s["say"],os.path.join(tmp,"v%02d"%i),voice);dur=duration(au)+0.35
            bg,isv,cr=background(s,i,tmp,pexels_key,gen_image,used,log,pixabay_key)
            if cr and cr not in credits:credits.append(cr)
            cs=chunks(s["say"]);wt=[len(c)+4 for c in cs];tot=sum(wt);t=0.0;caps=[]
            for k,c in enumerate(cs):
                e=t+(dur-0.35)*wt[k]/tot;caps.append((caption_png(c,os.path.join(tmp,"c%02d_%02d.png"%(i,k))),t,e if k<len(cs)-1 else dur));t=e
            pt=os.path.join(tmp,"p%02d.mp4"%i);render_scene(bg,isv,au,caps,dur,pt);parts.append(os.path.basename(pt))
        open(os.path.join(tmp,"list.txt"),"w").write("".join("file '%s'\n"%p for p in parts))
        run_ff(["-f","concat","-safe","0","-i","list.txt","-c","copy","-movflags","+faststart",os.path.abspath(out)],cwd=tmp)
    finally:
        json.dump(used[-400:],open(uf,"w"))
        shutil.rmtree(tmp,ignore_errors=True)
    total=duration(out);desc=str(sc.get("description","")).strip()
    if credits:desc+="\n\nStock footage: "+"; ".join(credits[:6])
    meta={"title":str(sc.get("title","")).strip()[:100],"description":desc[:4900],"tags":[str(t)[:60] for t in sc.get("tags",[])][:20],"seconds":round(total,1),"script":script_file,"made":time.strftime("%Y-%m-%d %H:%M")}
    json.dump(meta,open(out[:-4]+".json","w",encoding="utf8"),indent=1)
    if tiktok_dir:
        os.makedirs(tiktok_dir,exist_ok=True);nm=os.path.basename(out);shutil.copy(out,os.path.join(tiktok_dir,nm))
        tags=" ".join("#"+re.sub(r"\W","",t) for t in meta["tags"][:5] if re.sub(r"\W","",t))
        open(os.path.join(tiktok_dir,nm[:-4]+".txt"),"w",encoding="utf8").write("%s\n\n%s"%(meta["title"],tags))
    return meta
# ---------------------------------------------------------------- YouTube
YT_SCOPE="https://www.googleapis.com/auth/youtube.upload"
_STATE={}
def yt_redirect():return "http://127.0.0.1:%d/"%CFG["port"]
def yt_auth_url(cid):
    st=secrets.token_urlsafe(16);_STATE[st]=time.time()
    return "https://accounts.google.com/o/oauth2/v2/auth?"+urllib.parse.urlencode({"client_id":cid,"redirect_uri":yt_redirect(),"response_type":"code","scope":YT_SCOPE,"access_type":"offline","prompt":"consent","state":st})
def _tok(body):
    try:return json.load(_req("https://oauth2.googleapis.com/token",{"Content-Type":"application/x-www-form-urlencoded"},urllib.parse.urlencode(body).encode(),"POST",30))
    except urllib.error.HTTPError as e:
        t=e.read().decode("utf8","ignore")[:300]
        if "invalid_grant" in t:raise MediaError("YouTube sign-in has expired or was removed. Open Settings > Video Studio and press Connect YouTube again. (If this happens every week, set your Google app's publishing status to 'In production'.)")
        raise MediaError("Google sign-in error: "+t)
def yt_exchange(cid,sec,code,state):
    if state not in _STATE:raise MediaError("This sign-in link is old. Press Connect YouTube again.")
    _STATE.pop(state,None);j=_tok({"code":code,"client_id":cid,"client_secret":sec,"redirect_uri":yt_redirect(),"grant_type":"authorization_code"})
    if not j.get("refresh_token"):raise MediaError("Google did not return a long-term token. Remove StarCommand at myaccount.google.com/permissions and connect again.")
    return j["refresh_token"]
def yt_upload(cid,sec,refresh,path,title,desc,tags,privacy="private",synthetic=False,kids=False):
    if not(cid and sec and refresh):raise MediaError("YouTube is not connected. Open Settings > Video Studio: paste your Google client ID and secret in API keys, then press Connect YouTube.")
    at=_tok({"client_id":cid,"client_secret":sec,"refresh_token":refresh,"grant_type":"refresh_token"})["access_token"]
    size=os.path.getsize(path);title=(title or os.path.basename(path)[:-4]).strip()
    if "#shorts" not in (title+desc).lower():desc=(desc+"\n\n#Shorts").strip()
    body={"snippet":{"title":title[:100],"description":desc[:4900],"tags":tags[:20],"categoryId":"22"},
          "status":{"privacyStatus":privacy if privacy in("private","unlisted","public") else "private","selfDeclaredMadeForKids":bool(kids),"containsSyntheticMedia":bool(synthetic)}}
    try:
        r=_req("https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status",{"Authorization":"Bearer "+at,"Content-Type":"application/json; charset=UTF-8","X-Upload-Content-Type":"video/mp4","X-Upload-Content-Length":str(size)},json.dumps(body).encode(),"POST",60)
        loc=r.headers.get("Location")
        if not loc:raise MediaError("YouTube did not accept the upload request.")
        with open(path,"rb") as fh:data=fh.read()
        j=json.load(_req(loc,{"Authorization":"Bearer "+at,"Content-Type":"video/mp4","Content-Length":str(size)},data,"PUT",900))
    except urllib.error.HTTPError as e:
        t=e.read().decode("utf8","ignore")
        if "quotaExceeded" in t or "uploadLimitExceeded" in t:raise MediaError("YouTube's daily upload limit for this account or app is reached. Try again tomorrow.")
        raise MediaError("YouTube refused the upload (%s): %s"%(e.code,t[:300]))
    return j.get("id"),(j.get("status") or {}).get("privacyStatus") or privacy
# ---------------------------------------------------------------- PDFs
def make_pdf(html_file,out,size="A4",preview=True):
    try:from playwright.sync_api import sync_playwright
    except Exception:raise MediaError("The PDF maker uses the browser tool. Open Settings > Browser tool and press Install, then try again.")
    sizes=["A4","Letter"] if str(size).lower()=="both" else ["Letter" if str(size).lower().startswith("let") else "A4"]
    base=out[:-4] if out.lower().endswith(".pdf") else out;made=[];os.makedirs(os.path.dirname(base) or ".",exist_ok=True)
    res={}
    def run():
        try:
            with sync_playwright() as pw:
                br=pw.chromium.launch(headless=True);pg=br.new_page(viewport={"width":794,"height":1123},device_scale_factor=2)
                pg.goto(Path(html_file).resolve().as_uri(),wait_until="load",timeout=60000);pg.wait_for_timeout(400)
                for sz in sizes:
                    p=base+("-"+sz if len(sizes)>1 else "")+".pdf";pg.pdf(path=p,format=sz,print_background=True,prefer_css_page_size=False,margin={"top":"0","bottom":"0","left":"0","right":"0"});made.append(p)
                if preview:pg.screenshot(path=base+"-preview.png");made.append(base+"-preview.png")
                br.close()
        except Exception as e:res["err"]=str(e).split("\n")[0][:300]
    t=threading.Thread(target=run,daemon=True);t.start();t.join(180)
    if "err" in res:
        if "Executable doesn't exist" in res["err"]:raise MediaError("The browser tool is not fully installed. Open Settings > Browser tool and press Install.")
        raise MediaError("PDF failed: "+res["err"])
    if not made:raise MediaError("PDF timed out.")
    pages=[len(re.findall(rb"/Type\s*/Page[^s]",open(p,"rb").read())) for p in made if p.endswith(".pdf")]
    return made,pages
