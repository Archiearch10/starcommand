import importlib.util,urllib.parse,io,zipfile,socket,hashlib,mimetypes,json,os,re,subprocess,threading,time,urllib.request,urllib.error,uuid,webbrowser,random,shutil,glob,sys,atexit
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
import tools_ext as X
import vinted as V
import media as M
try:import updater as UPDR
except Exception:UPDR=None
VER="15.0"
DEFAULT_UPDATE_URL="https://raw.githubusercontent.com/Archiearch10/starcommand/main/version.json"
PORT=int(os.environ.get("STARCOMMAND_PORT") or 8766)
SUP=os.environ.get("STARCOMMAND_SUPERVISED")=="1"
B=os.path.dirname(os.path.abspath(__file__))
# ---- your data lives OUTSIDE the app folder so updating = replace the app files and run
DATA=os.environ.get("STARCOMMAND_DATA") or os.path.join(os.path.expanduser("~"),"StarCommand-data")
os.makedirs(DATA,exist_ok=True)
F=os.path.join(DATA,"data.json");LF=os.path.join(DATA,"logs.json");W=os.path.join(DATA,"workspace");os.makedirs(W,exist_ok=True)
IMPORTED=""
def _import_legacy():
    global IMPORTED
    if os.path.exists(F):return
    c=[os.path.join(B,"data.json")]+glob.glob(os.path.join(os.path.dirname(B),"StarCommand*","data.json"))
    c=[x for x in c if os.path.exists(x)]
    if not c:return
    p=max(c,key=os.path.getmtime);shutil.copy(p,F);IMPORTED=p
    ws=os.path.join(os.path.dirname(p),"workspace")
    if os.path.isdir(ws):
        try:shutil.copytree(ws,W,dirs_exist_ok=True)
        except Exception:pass
_import_legacy()
if os.path.exists(F):
    try:shutil.copy(F,F+".bak")
    except Exception:pass
P={"groq":("https://api.groq.com/openai/v1/chat/completions","llama-3.3-70b-versatile"),
"openrouter":("https://openrouter.ai/api/v1/chat/completions","meta-llama/llama-3.3-70b-instruct:free"),
"gemini":("https://generativelanguage.googleapis.com/v1beta/openai/chat/completions","gemini-2.5-flash"),
"openai":("https://api.openai.com/v1/chat/completions","gpt-4o-mini"),
"xai":("https://api.x.ai/v1/chat/completions","grok-3-mini"),
"ollama":("http://localhost:11434/v1/chat/completions","llama3.2")}
try:
    for _k,_v in json.loads(os.environ.get("STARCOMMAND_PROVIDERS","{}")).items():P[_k]=(_v,P[_k][1])
except Exception:pass
SERVICES=["printify","etsy","pexels","youtube_id","youtube_secret"];PROV_ORDER=["groq","openrouter","gemini","openai","xai"]
PERMS={0:"Read-only",1:"Workspace",2:"Whole computer"}
L=threading.RLock()
PAL=["#6ee7ff","#a78bfa","#f59e0b","#34d399","#f472b6","#60a5fa","#fb7185","#a3e635"]
ROOMPAL=["#4f6d8f","#3f7d74","#8a6d3b","#5f7a4a","#8c5a5a","#4a6b7c","#6f5f8f","#6b7280"]  # v14.9: calm, professional room colours
R0={"id":"r1","name":"My First Business","color":PAL[0],"kind":"work"}
SK=["#f5d0b0","#e8b48a","#c68e63","#8d5a3b","#5b3a29"];HR=["#2b1d14","#5a3a22","#d9a441","#c0392b","#e8e8f0","#2f6fed","#8e44ad","#1abc9c"];TR=["#1f2937","#f59e0b","#e5e7eb","#111827"]
HEX=re.compile(r"^#[0-9a-fA-F]{6}$")
def mklook(seed):
    g=random.Random(str(seed));return {"skin":g.choice(SK),"hair":g.choice(HR),"suit":g.choice(PAL),"trim":g.choice(TR),"style":g.randint(0,5),"outfit":g.randint(0,3),"acc":g.randint(0,4),"tag":g.choice(PAL)}
def clean_look(l):
    b=l if isinstance(l,dict) else {}
    o={k:(b[k] if HEX.match(str(b.get(k,""))) else d) for k,d in(("skin","#e8b48a"),("hair","#5a3a22"),("suit","#6ee7ff"),("trim","#1f2937"),("tag","#6ee7ff"))}
    for k,mx in(("style",5),("outfit",3),("acc",4)):
        try:o[k]=max(0,min(mx,int(b.get(k,0))))
        except Exception:o[k]=0
    return o
def ag(n,r,e,boss=False,p="groq",room="",perm=1):
    i=uuid.uuid4().hex[:8];lk=mklook(i)
    if boss:lk.update(suit="#7c5cf0",trim="#f59e0b",style=4,tag="#a78bfa")
    return {"id":i,"name":n,"role":r,"emoji":e,"boss":boss,"provider":p,"model":P[p][1],"status":"Idle","room":room,"look":lk,"runs":0,"done":0,
            "perm":perm,"budget":{"tokens":0,"usd":0.0},"usage":{"calls":0,"in":0,"out":0},"spent":0.0,"notes":[],"task":"","last":""}
S={"keys":{},"ask":True,"memory":[],"board":[],"rooms":[dict(R0)],"tasks":[],"settings":{},
   "agents":[ag("Nova","Boss. Plans projects, delegates work, solves problems, keeps the task board up to date.","👑",True),
             ag("Scout","Researcher. Uses web_search, reddit_top, trends_daily and etsy_search to find real trends. Never invents URLs or numbers.","🔭",room="r1"),
             ag("Pixel","Designer. Creates original product and design ideas, makes artwork with generate_image.","🎨",room="r1"),
             ag("Lister","Operator. Writes listings and prepares products with the Printify tools.","📦",room="r1")]}
if os.path.exists(F):
    try:S.update(json.load(open(F,encoding="utf8")))
    except Exception:pass
for _a in S["agents"]:
    if re.search(r"allam|compound",_a["model"]):_a["model"]=P[_a["provider"]][1]
W0,H0=100,72;OX,OY=20,13
HUB0={"id":"hub","name":"Operations Hub","x":OX+23,"y":OY+18,"w":14,"h":10,"shape":"rect"}
SLOTS=[(4,18,[(18,20,5,2)]),(42,18,[(37,20,5,2)]),(23,2,[(25,12,2,6)]),(23,34,[(29,25,2,9)]),(4,2,[(10,12,2,6)]),(42,2,[(48,12,2,6)]),(4,34,[(10,28,2,6)]),(42,34,[(48,28,2,6)])]
FURT={"desk","con","plant","crate","bin","belt","pillar","couch","coffee","table"}
def cleanrect(q,mn):
    w=max(mn,min(W0,int(q["w"])));h=max(mn,min(H0,int(q["h"])))
    return {"x":max(0,min(W0-w,int(q["x"]))),"y":max(0,min(H0-h,int(q["y"]))),"w":w,"h":h}
def clean_fur(l):
    out=[]
    for f in (l if isinstance(l,list) else [])[:150]:
        try:
            if f.get("t") in FURT:out.append({"id":str(f.get("id") or uuid.uuid4().hex[:5])[:10],"t":f["t"],"x":max(0,min(W0-1,int(f["x"]))),"y":max(0,min(H0-1,int(f["y"])))})
        except Exception:pass
    return out
def hit(a,b):return a["x"]<b["x"]+b["w"] and b["x"]<a["x"]+a["w"] and a["y"]<b["y"]+b["h"] and b["y"]<a["y"]+a["h"]
RW,RHT=14,10
def arrange():
    """v14.7: tidy auto-layout. The bridge sits top centre; rooms line up in neat rows either side of straight
    corridors (spines), each joined by a short spur, so every new room slots in symmetrically."""
    rooms=[r for r in S["rooms"]]
    cols=[1,3,0,4];X0=(W0-(5*RW+4*4))//2;cx=lambda c:X0+c*(RW+4);Y0=2
    # band 1: row A (y0) + row B ; band 2: row C + row D (needs the centre trunk)
    yA,ysp1,yB=Y0,Y0+RHT+2,Y0+RHT+2+3+2
    yC=yB+RHT+3;ysp2=yC+RHT+2;yD=ysp2+3+2
    slots=[(c,yA,"A") for c in cols]+[(c,yB,"B") for c in cols]
    if len(rooms)>8:slots+=[(c,yC,"C") for c in cols]+[(c,yD,"D") for c in cols]
    elif len(rooms)==9:pass
    halls=[];used={}
    h=S["hub"];h.update({"x":cx(2),"y":Y0,"w":RW,"h":RHT,"shape":"rect","name":"Operations Hub"})
    for r,(c,y,row) in zip(rooms,slots):
        nx,ny=cx(c),y;dx,dy=nx-r.get("x",nx),ny-r.get("y",ny)
        if isinstance(r.get("fur"),list):
            for q in r["fur"]:q["x"]+=dx;q["y"]+=dy
        r.update({"x":nx,"y":ny,"w":RW,"h":RHT});used.setdefault(row,[]).append(c)
    extra=rooms[len(slots):]
    mid=cx(2)+RW//2-1
    def spine(y,cs):
        xs=[cx(c) for c in cs]+[cx(2)];x0=min(xs);x1=max(xs)+RW;halls.append({"x":x0,"y":y,"w":x1-x0,"h":3})
    if used:
        spine(ysp1,used.get("A",[])+used.get("B",[]))
        halls.append({"x":mid,"y":Y0+RHT,"w":2,"h":ysp1-(Y0+RHT)})        # hub -> spine 1
        for c in used.get("A",[]):halls.append({"x":cx(c)+RW//2-1,"y":yA+RHT,"w":2,"h":ysp1-(yA+RHT)})
        for c in used.get("B",[]):halls.append({"x":cx(c)+RW//2-1,"y":ysp1+3,"w":2,"h":yB-(ysp1+3)})
    if used.get("C") or used.get("D"):
        spine(ysp2,used.get("C",[])+used.get("D",[]))
        halls.append({"x":mid,"y":ysp1+3,"w":2,"h":ysp2-(ysp1+3)})        # trunk between the spines
        for c in used.get("C",[]):halls.append({"x":cx(c)+RW//2-1,"y":yC+RHT,"w":2,"h":ysp2-(yC+RHT)})
        for c in used.get("D",[]):halls.append({"x":cx(c)+RW//2-1,"y":ysp2+3,"w":2,"h":yD-(ysp2+3)})
    S["halls"]=[dict(q,id="a%d"%i) for i,q in enumerate(halls)]
    for r in extra:r.pop("x",None);_place_room(r)
def place_room(r):
    if S.get("settings",{}).get("auto_layout",True) and r in S["rooms"]:arrange();return
    _place_room(r)
def _place_room(r):
    occ=[S["hub"]]+[q for q in S["rooms"] if q is not r and "x" in q]
    for sx,sy,hs in SLOTS:
        c={"x":OX+sx,"y":OY+sy,"w":14,"h":10}
        if not any(hit({"x":c["x"]-1,"y":c["y"]-1,"w":16,"h":12},q) for q in occ):
            r.update(c)
            for hx,hy,hw,hh in hs:
                q={"x":OX+hx,"y":OY+hy,"w":hw,"h":hh}
                if not any(all(h[k]==q[k] for k in q) for h in S["halls"]):S["halls"].append(dict(q,id="h"+uuid.uuid4().hex[:5]))
            return
    for k in range(40):
        c={"x":OX+4+18*(k%4),"y":OY+48+13*(k//4),"w":14,"h":10}
        if c["x"]+c["w"]<=W0 and c["y"]+c["h"]<=H0 and not any(hit(c,q) for q in occ):r.update(c);return
    r.update({"x":2,"y":2,"w":14,"h":10})
def fix_all():
    if not S.get("rooms"):S["rooms"]=[dict(R0)]
    S.setdefault("halls",[]);S.setdefault("tasks",[]);S.setdefault("settings",{})
    st=S["settings"]
    for k,v in(("fallback",True),("standup_min",0),("auto_layout",True),("ntfy_topic",""),("ntfy_server","https://ntfy.sh"),("ntfy_approvals",True),("ntfy_shipped",True),("ntfy_errors",True),("ntfy_digest",True),("digest_at","21:00"),("auto_backup",True),("day_cap_usd",0.0),("image_provider","pollinations"),("printify_shop",""),("browser_visible",False),("etsy_shop",""),("lan",False),("pin",""),("update_url",""),("risk_guard",True),("daynight",True),("yt_privacy","private"),("yt_voice","en-GB-RyanNeural"),("yt_daily_max",2),("auto_update",True)):st.setdefault(k,v)
    if not st["pin"]:st["pin"]="%06d"%random.randint(0,999999)
    st.setdefault("owner_name","")
    if not st.get("update_url") and not S.get("upd_default_v141"):st["update_url"]=DEFAULT_UPDATE_URL;S["upd_default_v141"]=True
    for k in("rules","schedules","sales"):S.setdefault(k,[])
    S.setdefault("usage_days",{})
    X.BR.visible=bool(st["browser_visible"])
    if not isinstance(S.get("hub"),dict) or "x" not in S["hub"]:S["hub"]=dict(HUB0)
    ids={r["id"] for r in S["rooms"]}
    for r in S["rooms"]:
        r.setdefault("kind","work")
        if "x" not in r:place_room(r)
    for a in S["agents"]:
        a["room"]="" if a["boss"] else (a.get("room") if a.get("room") in ids else S["rooms"][0]["id"])
        a["look"]=clean_look(a["look"]) if a.get("look") else mklook(a["id"])
        a.setdefault("runs",0);a.setdefault("done",0);a.setdefault("perm",1);a.setdefault("spent",0.0)
        a.setdefault("budget",{"tokens":0,"usd":0.0});a.setdefault("usage",{"calls":0,"in":0,"out":0});a.setdefault("notes",[]);a.setdefault("task","");a.setdefault("last","")
fix_all()
for _a in S["agents"]:_a["task"]="";_a["status"]="Idle"
def mkroom(name,place=True,kind="work",reuse=True):
    name=str(name).strip()[:40] or "New room"
    for r in S["rooms"]:
        if r["name"].lower()==name.lower():return r
    for r in S["rooms"]:
        if reuse and r.get("spare") and not any(a.get("room")==r["id"] for a in S["agents"]):
            r["name"]=name;r["kind"]=kind;r.pop("spare",None);return r
    r={"id":uuid.uuid4().hex[:6],"name":name,"color":ROOMPAL[len(S["rooms"])%len(ROOMPAL)],"kind":kind};S["rooms"].append(r)
    if place:place_room(r)
    return r
pend={};stop=[False];busy=[0]
def save():
    with L:
        tmp=F+".tmp"
        with open(tmp,"w",encoding="utf8") as f:json.dump(S,f,indent=1)
        os.replace(tmp,F)

def migrate_v91():
    h=S["hub"]
    if S.get("spare_v91"):return
    if h.get("shape")!="half":
        old=dict(h);h["shape"]="half"
        h["h"]=7 if (old["w"],old["h"])==(14,10) else max(5,min(old["h"],old["w"]//2))
        ob=old["y"]+old["h"];nb=h["y"]+h["h"]
        for q in S["halls"]:
            inx=old["x"]<=q["x"]<old["x"]+old["w"]
            if q["y"]==ob and inx and q["h"]>q["w"]:q["h"]+=ob-nb;q["y"]=nb
            elif q["y"]+q["h"]==old["y"] and inx and q["h"]>q["w"] and abs(q["x"]-(old["x"]+old["w"]//2))<3:q["x"]=h["x"]+2
            elif (q["x"]+q["w"]==old["x"] or q["x"]==old["x"]+old["w"]) and old["y"]<=q["y"]<ob and q["w"]>q["h"]:q["y"]=h["y"]+2
    S["spare_v91"]=True
migrate_v91()
def drop_room(r):
    """remove a room and the hallway that was built for its slot"""
    for sx,sy,hs in SLOTS:
        if r.get("x")==OX+sx and r.get("y")==OY+sy:
            for hx,hy,hw,hh in hs:
                q={"x":OX+hx,"y":OY+hy,"w":hw,"h":hh}
                S["halls"]=[h for h in S["halls"] if not all(h.get(k)==q[k] for k in q)]
    S["rooms"]=[x for x in S["rooms"] if x is not r]
    if S.get("settings",{}).get("auto_layout",True):arrange()
def migrate_v12():
    """v12: the 'Empty room N' spares are gone - delete any that nobody uses"""
    if S.get("spare_gone_v12"):return
    S["spare_gone_v12"]=True
    for r in [x for x in S["rooms"] if x.get("spare") or re.match(r"^Empty room \d+$",x["name"])]:
        if len(S["rooms"])>1 and not any(a.get("room")==r["id"] for a in S["agents"]):drop_room(r)
    fix_all();save()
migrate_v12()
def clip(t):
    t=str(t)
    if len(t)>800 and len(set(t[i:i+40] for i in range(0,len(t)-40,40)))<len(t)//40*0.5:return t[:300]+" ...[cut: the model got stuck repeating itself. Try a stronger model for this agent]"
    return t if len(t)<=2500 else t[:2500]+" ...[cut]"
for _m in S["board"]:_m["text"]=clip(_m["text"])
# ---------------------------------------------------------------- per-agent log
LOGS={};LD=[False]
try:LOGS=json.load(open(LF,encoding="utf8"))
except Exception:LOGS={}
def alog(a,k,t):
    with L:
        l=LOGS.setdefault(a["id"],[]);l.append({"t":int(time.time()),"k":k,"x":str(t)[:1200]});del l[:-300];LD[0]=True
def flush_logs(force=False):
    while True:
        if LD[0]:
            LD[0]=False
            try:
                with L:d=json.dumps(LOGS)
                open(LF,"w",encoding="utf8").write(d)
            except Exception:pass
        if force:return
        time.sleep(4)
atexit.register(lambda:flush_logs(True))
def _room(w):
    for a in S["agents"]:
        if a["name"]==w and not a["boss"]:return a.get("room","")
    return ""
CHD=os.path.join(DATA,"chat");os.makedirs(CHD,exist_ok=True)
def archive(m):
    try:
        with open(os.path.join(CHD,time.strftime("%Y-%m")+".jsonl"),"a",encoding="utf8") as fh:fh.write(json.dumps(dict(m,ts=int(time.time()),day=time.strftime("%Y-%m-%d")),ensure_ascii=False)+"\n")
    except Exception:pass
def post(who,text,kind="msg"):
    with L:
        m={"who":who,"text":clip(text),"t":time.strftime("%H:%M"),"kind":kind,"room":_room(who)}
        S["board"].append(m);S["board"]=S["board"][-300:];save();archive(m)
    if kind=="err":
        try:notify_err(str(text))
        except Exception:pass
def find(n):
    for a in S["agents"]:
        if a["name"].lower()==str(n).lower() or a["id"]==n:return a
def stat(a,s):a["status"]=str(s)[:90];a["st_t"]=int(time.time())
# ---------------------------------------------------------------- task board
def task_add(title,owner="",room="",status="todo",note=""):
    with L:
        o=find(owner) if owner else None
        t={"id":"t"+uuid.uuid4().hex[:5],"title":str(title)[:200],"owner":o["name"] if o else str(owner)[:30],"room":room or (o["room"] if o else ""),"status":status if status in("todo","doing","done","stuck") else "todo","notes":str(note)[:300],"created":int(time.time()),"updated":int(time.time())}
        S["tasks"].append(t);S["tasks"]=S["tasks"][-300:];save();return t
def task_set(tid,status=None,notes=None):
    with L:
        for t in S["tasks"]:
            if t["id"]==tid:
                if status in("todo","doing","done","stuck"):t["status"]=status
                if notes is not None:t["notes"]=str(notes)[:300]
                t["updated"]=int(time.time());save();return t
def board_text(owner=None):
    ts=[t for t in S["tasks"] if t["status"]!="done" and (not owner or t["owner"] in("",owner))][-15:]
    return "\n".join("[%s] %s (%s) owner=%s %s"%(t["id"],t["title"],t["status"],t["owner"] or "-",t["notes"][:60]) for t in ts) or "(no open tasks)"
# ---------------------------------------------------------------- models / llm
def models(prov):
    u=P[prov][0].replace("/chat/completions","/models")
    r=json.load(urllib.request.urlopen(urllib.request.Request(u,headers={"Authorization":"Bearer "+S["keys"].get(prov,""),"User-Agent":"StarCommand/7"}),timeout=30))
    return sorted(m["id"].replace("models/","") for m in r.get("data",[]))
BADM=r"allam|compound|whisper|guard|tts|embed|orpheus|playai|safeguard|image|moderation|dall|davinci|babbage|realtime|audio|transcribe"
PREF=("gpt-oss-120b","llama-3.3-70b","kimi-k2","llama-4","qwen3-32b","70b","120b","gpt-oss-20b","32b","gpt-4o","8b","20b")
CHEAP=("llama-3.1-8b","gpt-oss-20b","gemini-2.0-flash","mini","8b","20b","qwen3-32b","32b","70b")
def _rank(ms,order):
    ms=[m for m in ms if not re.search(BADM,m,re.I)]
    for k in order:
        for m in ms:
            if k in m:return m
    return ms[0] if ms else None
def best(ms):return _rank(ms,PREF)
def cheap(ms):return _rank(ms,CHEAP)
def pick_model(prov,bad):return best([m for m in models(prov) if m not in bad])
class ApiErr(Exception):
    def __init__(s,code,text):super().__init__(text);s.code=code;s.text=text
PH={}
def ph(prov,ok,err=""):
    with L:
        d=PH.setdefault(prov,{"ok":0,"fail":0,"err":"","t":0});d["ok" if ok else "fail"]+=1
        if not ok:d["err"]=str(err)[:160];d["t"]=int(time.time())
def call_api(prov,model,msgs):
    try:r=_call_api(prov,model,msgs);ph(prov,True);return r
    except ApiErr as e:ph(prov,False,"%s %s"%(e.code,e.text[:120]));raise
def _call_api(prov,model,msgs):
    h={"Content-Type":"application/json","Authorization":"Bearer "+S["keys"].get(prov,""),"User-Agent":"StarCommand/7"}
    body=json.dumps({"model":model,"messages":msgs,"temperature":0.4,"max_tokens":1500}).encode()
    try:
        r=json.load(urllib.request.urlopen(urllib.request.Request(P[prov][0],body,h),timeout=120))
        return r["choices"][0]["message"]["content"] or "",r.get("usage") or {}
    except urllib.error.HTTPError as e:raise ApiErr(e.code,e.read().decode("utf8","ignore")[:300])
    except Exception as e:raise ApiErr(0,"%s: %s"%(type(e).__name__,e))
def day_add(a,calls=0,i=0,o=0,usd=0.0):
    d=S["usage_days"].setdefault(time.strftime("%Y-%m-%d"),{});e=d.setdefault(a["id"],{"n":a["name"],"calls":0,"in":0,"out":0,"usd":0.0})
    e["n"]=a["name"];e["calls"]+=calls;e["in"]+=i;e["out"]+=o;e["usd"]=round(e["usd"]+usd,2)
    for k in sorted(S["usage_days"])[:-45]:S["usage_days"].pop(k,None)
def warn_budget(a):
    b=a.get("budget") or {};us=a["usage"];w=a.setdefault("warned",{})
    if b.get("tokens") and us["in"]+us["out"]>=.8*b["tokens"] and not w.get("t"):w["t"]=1;post("System","Heads up: %s has used 80%% of its token budget (%d of %d)."%(a["name"],us["in"]+us["out"],b["tokens"]),"err")
    if b.get("usd") and a.get("spent",0)>=.8*b["usd"] and not w.get("u"):w["u"]=1;post("System","Heads up: %s has spent 80%% of its money budget ($%.2f of $%.2f)."%(a["name"],a["spent"],b["usd"]),"err")
def rec(a,m,out,u):
    us=a["usage"];i=int(u.get("prompt_tokens") or sum(len(str(x["content"])) for x in m)//4);o=int(u.get("completion_tokens") or len(out)//4)
    us["calls"]+=1;us["in"]+=i;us["out"]+=o
    with L:day_add(a,1,i,o);warn_budget(a)
def over_budget(a):
    bt=(a.get("budget") or {}).get("tokens",0);us=a["usage"]
    if bt and us["in"]+us["out"]>=bt:return "Token budget reached (%d tokens). Raise or reset it in the agent editor."%bt
FBM={}
def fb_chain(prov):return [p for p in PROV_ORDER if p!=prov and S["keys"].get(p)] if S["settings"].get("fallback",True) else []
def fb_model(p):
    if p not in FBM:
        try:FBM[p]=best(models(p))
        except Exception:FBM[p]=None
    return FBM[p]
def llm(a,m):
    why=over_budget(a)
    if why:raise Exception(why)
    prov,model=a["provider"],a["model"];bad={model};last=None;fb=fb_chain(prov)
    for i in range(5):
        try:
            out,u=call_api(prov,model,m);rec(a,m,out,u);return out
        except ApiErr as e:
            last=e
            if stop[0]:break
            if e.code==429 and i<(1 if fb else 4):stat(a,"Rate limited, waiting");time.sleep(5*(i+1));continue
            if (e.code>=500 or e.code==0) and i<2:stat(a,"%s is busy, trying again"%prov);time.sleep(4*(i+1));continue
            if e.code in(400,404) and "model" in e.text.lower() and i<4:
                try:n=pick_model(prov,bad)
                except Exception:n=None
                if n:post("System","%s: model %s unavailable, switched to %s"%(a["name"],model,n));a["model"]=model=n;bad.add(n);save();continue
            break
    for fp in fb:
        fm=fb_model(fp)
        if not fm:continue
        try:
            out,u=call_api(fp,fm,m);rec(a,m,out,u);alog(a,"fallback","%s failed (%s %s) -> answered by %s/%s"%(prov,last.code,last.text[:80],fp,fm))
            post("System","%s: %s was unavailable, so %s/%s answered instead."%(a["name"],prov,fp,fm));return out
        except ApiErr:continue
    raise Exception("%s API error %s: %s"%(prov,last.code,last.text[:200]))
def js(t):
    t=re.sub(r"^```(?:json)?\s*|\s*```$","",(t or "").strip(),flags=re.I);s=t.find("{")
    if s<0:return None
    d=0;ins=False;esc=False
    for i in range(s,len(t)):
        c=t[i]
        if ins:
            if esc:esc=False
            elif c=="\\":esc=True
            elif c=='"':ins=False
        elif c=='"':ins=True
        elif c=="{":d+=1
        elif c=="}":
            d-=1
            if d==0:
                seg=t[s:i+1]
                for cand in(seg,re.sub(r",\s*([}\]])",r"\1",seg)):
                    try:return json.loads(cand)
                    except Exception:pass
                return None
    return None
def ask_json(a,m):
    o=llm(a,m)
    for _ in range(2):
        j=js(o)
        if isinstance(j,dict):return j,o
        alog(a,"repair","model did not return valid JSON, asking again")
        m=m+[{"role":"assistant","content":o},{"role":"user","content":"Your reply was not valid JSON. Reply again with ONLY the JSON object in the required format, nothing else."}];o=llm(a,m)
    j=js(o);return (j if isinstance(j,dict) else {"action":"done","text":o}),o
# ---------------------------------------------------------------- tools + permissions

# ---------------------------------------------------------------- v8: history, rules, sales, schedules
HD=os.path.join(DATA,"history");os.makedirs(HD,exist_ok=True)
def relw(p):return os.path.relpath(p,W).replace(os.sep,"/")
def _hdir(rel):return os.path.join(HD,hashlib.md5(rel.encode()).hexdigest()[:12])
def snap(p):
    """Keep the previous version of a file before it is overwritten (undo)."""
    try:
        if not os.path.isfile(p):return
        rel=relw(p);d=_hdir(rel);os.makedirs(d,exist_ok=True);open(os.path.join(d,"path.txt"),"w",encoding="utf8").write(rel)
        shutil.copy(p,os.path.join(d,"%d_%s"%(time.time()*1000,"v")));vs=sorted(x for x in os.listdir(d) if x.endswith("_v"))
        for x in vs[:-20]:os.remove(os.path.join(d,x))
    except Exception:pass
def versions(rel):
    d=_hdir(rel);out=[]
    if os.path.isdir(d):
        for x in sorted(os.listdir(d),reverse=True):
            if x.endswith("_v"):out.append({"v":x,"t":int(x.split("_")[0])//1000,"size":os.path.getsize(os.path.join(d,x))})
    return out
def wpath(rel):
    full=os.path.realpath(os.path.join(W,str(rel)));root=os.path.realpath(W)
    if full!=root and not full.startswith(root+os.sep):raise X.ToolError("outside the workspace")
    return full
def list_files():
    out=[]
    for root,ds,fs in os.walk(W):
        for f in fs:
            p=os.path.join(root,f);r=relw(p)
            try:out.append({"path":r,"size":os.path.getsize(p),"t":int(os.path.getmtime(p)),"versions":len(versions(r))})
            except Exception:pass
        if len(out)>600:break
    return sorted(out,key=lambda x:-x["t"])[:600]
RULE_TOOLS=("write_file","generate_image","browser_screenshot","youtube_upload")
def rule_for(n,g):
    if n not in RULE_TOOLS:return None
    pth=str(g.get("path") or g.get("file") or "").replace("\\","/").lstrip("/")
    if not pth or ".." in pth.split("/"):return None
    d=pth.rsplit("/",1)[0]+"/" if "/" in pth else pth
    return {"tool":n,"prefix":d}
def rule_ok(n,g):
    r=rule_for(n,g)
    if not r:return False
    pth=str(g.get("path") or g.get("file") or "").replace("\\","/").lstrip("/")
    return any(x["tool"]==n and (pth==x["prefix"] or (x["prefix"].endswith("/") and pth.startswith(x["prefix"]))) for x in S["rules"])
def sales_report():
    st=S["settings"];L=X.etsy_shop_stats(S["keys"].get("etsy"),st.get("etsy_shop"))
    prev=S["sales"][-1]["items"] if S["sales"] else {};pdate=S["sales"][-1]["date"] if S["sales"] else "?"
    snapnow={str(x["id"]):{"title":x["title"],"views":x["views"],"favs":x["favs"]} for x in L}
    today=time.strftime("%Y-%m-%d")
    if S["sales"] and S["sales"][-1]["date"]==today:S["sales"][-1]["items"]=snapnow
    else:S["sales"].append({"date":today,"items":snapnow})
    del S["sales"][:-90];save()
    rows=[]
    for x in sorted(L,key=lambda z:-(z["views"]+5*z["favs"])):
        p=prev.get(str(x["id"]));d="new" if not p else "views %+d, favs %+d since %s"%(x["views"]-p["views"],x["favs"]-p["favs"],pdate)
        rows.append("- %s | %s views | %s favs | %s"%(x["title"],x["views"],x["favs"],d))
    return ("Shop '%s': %d active listings. Best first (views + 5x favourites):\n"%(st.get("etsy_shop"),len(L)))+"\n".join(rows[:30])+"\nNote: Etsy's public API shows views and favourites, not orders. Use these to see which designs get attention."
SCH_LAST={}
def sched_loop():
    while True:
        time.sleep(20)
        try:
            now=time.localtime();hm=time.strftime("%H:%M",now);day=now.tm_wday;ds=time.strftime("%Y-%m-%d")
            for sc in list(S.get("schedules",[])):
                if not sc.get("on"):continue
                due=False
                if sc.get("every_min"):
                    last=SCH_LAST.get(sc["id"])
                    if last is None:SCH_LAST[sc["id"]]=time.time()
                    elif time.time()-last>=sc["every_min"]*60:due=True
                elif sc.get("at")==hm and (not sc.get("days") or day in sc["days"]) and sc.get("last")!=ds+hm:due=True
                if due:
                    if busy[0]>0:continue
                    SCH_LAST[sc["id"]]=time.time();sc["last"]=ds+hm;sc["ran"]=time.strftime("%d %b %H:%M")
                    with L:post("Schedule","Starting scheduled task: "+sc["text"][:200]);save()
                    go(sc["text"],sc.get("to") or None)
        except Exception as e:print("scheduler:",e)
def lan_ip():
    try:
        x=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);x.connect(("10.255.255.255",1));ip=x.getsockname()[0];x.close();return ip
    except Exception:return "127.0.0.1"
BAD=re.compile(r"\b(del|erase|rm|rmdir|rd|unlink|rmtree|remove-item|remove|format|shred|mkfs|truncate|diskpart|fdisk)\b|os\.(remove|rmdir|unlink)|shutil\.rmtree|Remove-Item|-delete\b|>\s*/dev/",re.I)
V.init(S=S,P=P,models=models,DATA=DATA,W=W);M.init(port=PORT)
TL={"http_get":(0,0,"url - read a web page as text"),"web_search":(0,0,"query - real web search (titles, urls, snippets)"),
"reddit_top":(0,0,"subreddit, period(day|week|month|year) - top posts, great for trends"),"trends_daily":(0,0,"geo e.g. US - Google trending searches today"),
"trends_interest":(0,0,"keywords(list), geo - interest over 3 months (needs pytrends)"),"etsy_search":(0,0,"keywords, limit - top Etsy listings with favorites and views (needs Etsy key)"),
"keyword_ideas":(0,0,"query - real search-autocomplete phrases people type (demand signal, tag ideas)"),"seo_check":(0,0,"title, tags(list), description - checks Etsy rules (140 char title, 13 tags of max 20 chars)"),"risk_check":(0,0,"text - flags trademarked or brand terms before you design or list"),"sales_report":(0,0,"- your Etsy shop listings with views and favourites, and change since last check (needs Etsy key and shop name in Settings)"),"read_file":(0,0,"path"),"list_files":(0,0,"path"),"remember":(0,0,"note, shared(true|false) - save a lesson to your own long-term notes (shared=true puts it in team memory too)"),
"task_list":(0,0,"- show the task board"),"task_add":(0,0,"title, owner(optional agent name)"),"task_update":(0,0,"id, status(todo|doing|done|stuck), notes"),
"printify_shops":(0,0,"- list connected shops"),"printify_catalog":(0,0,"query e.g. 'unisex tee'"),"printify_options":(0,0,"blueprint_id, print_provider_id(optional)"),
"browser_open":(1,0,"url - automated browser; returns text and numbered clickable items"),"browser_text":(1,0,"- re-read the current browser page"),
"write_file":(1,1,"path, content"),"generate_image":(1,1,"prompt, file(e.g. designs/cat.png), width, height"),
"browser_click":(1,1,"target - a number from the list, or visible text"),"browser_type":(1,1,"target, text, enter(true|false)"),"browser_screenshot":(1,1,"file"),
"printify_create_product":(1,1,"title, description, blueprint_id, print_provider_id, image_file, price_usd, tags(list) - creates an UNPUBLISHED product"),
"printify_publish":(1,1,"product_id - publishes to the connected store (Etsy); costs a listing fee"),
"vinted_items":(1,0,"- list the Vinted items and their status"),"vinted_look":(1,0,"item_id - study the item's photos with a vision model; returns what is visible (brand, size label, colour, flaws)"),
"vinted_save_pack":(1,0,"item_id, pack{title,description,category,brand,size,condition,colours[],material,price_gbp,parcel_size,hashtags[],questions[]} - saves the listing pack for the user to review"),
"vinted_fill":(1,1,"item_id - fills the new-listing form in the user's Vinted window from the saved pack. It NEVER publishes; the user presses the button"),"vinted_inspect":(1,1,"- saves a list of the Vinted form's fields to a file so the filler can be tuned"),
"make_pdf":(1,0,"html_file, file(e.g. printables/budget-planner/budget-planner.pdf), size(A4|Letter|both) - turns an HTML page you wrote into a print-ready PDF plus a preview PNG"),"make_video":(1,0,"script_file(e.g. video/scripts/topic.json), file(e.g. video/out/topic.mp4) - makes a vertical Short: AI voice, stock clips, captions. Takes a few minutes"),"youtube_upload":(1,1,"file(the .mp4 made by make_video), ai_visuals(true only if it shows realistic AI-made people or events) - uploads to the user's YouTube channel with the privacy set in Settings"),
"run_command":(2,1,"cmd - runs in the workspace folder"),"open_url":(2,1,"url - opens in the user's own browser")}
def tools_for(a):return [n for n,v in TL.items() if v[0]<=a.get("perm",1) and (not n.startswith("vinted_") or a.get("boss") or a.get("vinted")) and (n!="youtube_upload" or a.get("boss") or a.get("unit")=="publisher")]
def yt_log():
    try:return json.load(open(os.path.join(W,"video","uploads.json"),encoding="utf8"))
    except Exception:return []
def yt_meta(rel):
    try:return json.load(open(wpath(str(rel)).rsplit(".",1)[0]+".json",encoding="utf8"))
    except Exception:return {}
def tools_prompt(a):
    return "Tools (args are JSON): "+"; ".join("%s{%s}"%(n,TL[n][2]) for n in tools_for(a))+". Relative paths live in the workspace folder. Use real data: search with web_search, reddit_top, trends_daily or etsy_search instead of guessing web addresses. Deleting files is forbidden. Spending money needs the user's budget and approval."
def cost_of(n,g):
    if n=="printify_publish":return 0.20
    if n=="generate_image" and S["settings"].get("image_provider")=="openai":return 0.04
    return 0.0
def safe_path(a,p):
    full=os.path.realpath(str(p) if os.path.isabs(str(p)) else os.path.join(W,str(p)))
    if a.get("perm",1)<2:
        root=os.path.realpath(W)
        if full!=root and not full.startswith(root+os.sep):raise X.ToolError("That path is outside the workspace folder (%s). This agent only has '%s' access; the user can raise it in the agent editor."%(root,PERMS[a.get("perm",1)]))
    return full
def ask(a,desc,detail="",force=False,rule=None):
    if not S["ask"] and not force:return True
    i=uuid.uuid4().hex[:6];pend[i]={"who":a["name"],"desc":desc,"detail":detail[:900],"ev":threading.Event(),"ok":False,"rule":rule,"always":False};notify_kind("approvals","Approval needed","%s wants to %s"%(a["name"],desc),"warning",4);stat(a,"Waiting for your approval");alog(a,"approval","asked: "+desc)
    while not pend[i]["ev"].wait(1):
        if stop[0]:break
    q=pend.pop(i);ok=q["ok"]
    if ok and q.get("always") and q.get("rule") and q["rule"] not in [{"tool":x["tool"],"prefix":x["prefix"]} for x in S["rules"]]:S["rules"].append(dict(q["rule"],id=uuid.uuid4().hex[:5]));save()
    alog(a,"approval","approved" if ok else "denied");return ok
def describe(a,n,g,cost):
    if n=="write_file":c=str(g.get("content",""));return "write file "+str(g.get("path")),"%d characters\n---\n%s"%(len(c),c[:700])
    if n=="run_command":return "run a command","cwd: %s\n$ %s"%(W,g.get("cmd"))
    if n=="open_url":return "open "+str(g.get("url"))+" in your browser",""
    if n=="generate_image":return "generate an image -> "+str(g.get("file") or "images/"),"prompt: %s\nsize: %sx%s%s"%(str(g.get("prompt"))[:500],g.get("width",1024),g.get("height",1024),"\nCOST $%.2f"%cost if cost else "")
    if n=="printify_create_product":return "create a Printify product (unpublished)",json.dumps({k:g.get(k) for k in("title","blueprint_id","print_provider_id","image_file","price_usd","tags")},indent=1)
    if n=="printify_publish":return "PUBLISH Printify product %s to your store (listing fee about $%.2f)"%(g.get("product_id"),cost),"This puts a real listing on your connected shop."
    if n=="vinted_fill":
        try:it=V.get_item(str(g.get("item_id")));pk=it.get("pack",{});return "fill the Vinted listing form for: %s (it will NOT press Publish)"%(pk.get("title") or it["id"]),"Opens your Vinted window and types in the pack: %s, %s, size %s, %s, GBP %s, %d photos. You press the upload button yourself."%(pk.get("brand") or "no brand",pk.get("category") or "?",pk.get("size") or "?",pk.get("condition") or "?",pk.get("price_gbp"),len(it["photos"]))
        except Exception:return "fill a Vinted listing form (will not publish)",""
    if n=="vinted_inspect":return "open Vinted and save a list of the listing form's fields (no changes made)",""
    if n=="youtube_upload":
        m=yt_meta(g.get("file",""));pv=S["settings"].get("yt_privacy","private")
        return "upload %s to YouTube as %s"%(g.get("file"),pv.upper()),"Title: %s\nLength: %s seconds\nAI visuals label: %s\n\n%s\n\nTick 'Always allow' to let the Video Studio upload without asking (fully automatic)."%(m.get("title","?"),m.get("seconds","?"),"yes" if str(g.get("ai_visuals","")).lower()=="true" else "no",str(m.get("description",""))[:400])
    if n=="browser_click":return "click '%s' in the browser"%g.get("target"),""
    if n=="browser_type":return "type into '%s' in the browser"%g.get("target"),"text: %s"%str(g.get("text"))[:300]
    if n=="browser_screenshot":return "save a browser screenshot to "+str(g.get("file")),""
    return n,json.dumps(g)[:300]
def run_tool(a,n,g):
    k=S["keys"];st=S["settings"]
    if n=="http_get":return X.http_get(g.get("url",""))
    if n=="web_search":return X.web_search(str(g.get("query","")))
    if n=="reddit_top":return X.reddit_top(g.get("subreddit",""),g.get("period","week"))
    if n=="trends_daily":return X.trends_daily(g.get("geo","US"))
    if n=="trends_interest":return X.trends_interest(g.get("keywords",[]),g.get("geo","US"))
    if n=="etsy_search":return X.etsy_search(k.get("etsy"),g.get("keywords",""),g.get("limit",10))
    if n=="read_file":return open(safe_path(a,g.get("path","")),encoding="utf8",errors="ignore").read()[:6000]
    if n=="list_files":return "\n".join(sorted(os.listdir(safe_path(a,g.get("path","."))))) [:3000] or "(empty folder)"
    if n=="remember":
        nt=str(g.get("note",""))[:300].strip()
        if not nt:return "empty note"
        if nt not in a["notes"]:a["notes"].append(nt);del a["notes"][:-40]
        if str(g.get("shared","")).lower()=="true":S["memory"].append("%s: %s"%(a["name"],nt));del S["memory"][:-60]
        save();return "saved to your long-term notes"
    if n=="keyword_ideas":return X.keyword_ideas(g.get("query",""))
    if n=="seo_check":return X.seo_check(g.get("title",""),g.get("tags",[]),g.get("description",""))
    if n=="risk_check":
        h=X.risk_check(g.get("text",""));return "Possible brand or trademark terms: %s. Replace them with original wording."%", ".join(h) if h else "No known brand terms found (this is a simple word list, not legal advice)."
    if n=="sales_report":return sales_report()
    if n=="task_list":return board_text()
    if n=="task_add":t=task_add(g.get("title","untitled"),g.get("owner",""),a.get("room",""));return "added task %s"%t["id"]
    if n=="task_update":
        t=task_set(str(g.get("id","")),g.get("status"),g.get("notes"));return "updated %s -> %s"%(t["id"],t["status"]) if t else "no such task id"
    if n=="printify_shops":return X.printify_shops(k.get("printify"))
    if n=="printify_catalog":return X.printify_catalog(k.get("printify"),g.get("query",""))
    if n=="printify_options":return X.printify_options(k.get("printify"),g.get("blueprint_id"),g.get("print_provider_id"))
    if n=="browser_open":return X.BR.call(X.b_open,str(g.get("url","")))
    if n=="browser_text":return X.BR.call(X.b_text)
    if n=="browser_click":return X.BR.call(X.b_click,g.get("target",""))
    if n=="browser_type":return X.BR.call(X.b_type,g.get("target",""),g.get("text",""),str(g.get("enter","")).lower()=="true")
    if n=="browser_screenshot":d=safe_path(a,g.get("file") or "screenshots/shot-%d.png"%time.time());os.makedirs(os.path.dirname(d),exist_ok=True);X.BR.call(X.b_shot,d);return "saved screenshot "+d
    if n=="write_file":
        p=safe_path(a,g.get("path",""));os.makedirs(os.path.dirname(p),exist_ok=True);snap(p);open(p,"w",encoding="utf8").write(str(g.get("content","")));return "written "+p
    if n=="generate_image":
        d=safe_path(a,g.get("file") or "images/img-%d.png"%time.time());snap(d)
        sz=X.gen_image(st.get("image_provider","pollinations"),k.get("openai"),g.get("prompt",""),d,g.get("width",1024),g.get("height",1024));return "saved image %s (%d bytes)"%(d,sz)
    if n=="printify_create_product":
        img=safe_path(a,g.get("image_file",""))
        if not os.path.isfile(img):raise X.ToolError("image_file not found in the workspace: %s"%g.get("image_file"))
        tok=k.get("printify");return X.printify_create(tok,X.printify_shop_id(tok,st.get("printify_shop")),g,img)
    if n=="printify_publish":tok=k.get("printify");return X.printify_publish(tok,X.printify_shop_id(tok,st.get("printify_shop")),g.get("product_id",""))
    if n=="run_command":
        if BAD.search(str(g.get("cmd",""))):return "BLOCKED: deleting is disabled"
        r=subprocess.run(str(g.get("cmd","")),shell=True,cwd=W,capture_output=True,text=True,timeout=120);return (r.stdout+r.stderr)[-3000:] or "(no output)"
    if n=="vinted_items":return json.dumps([{"id":i["id"],"status":i["status"],"title":(i.get("pack") or {}).get("title",""),"photos":len(i["photos"]),"notes":i.get("notes","")} for i in V.list_items()][:30])
    if n=="vinted_look":return json.dumps(V.look(str(g.get("item_id","")),cache=True))
    if n=="vinted_save_pack":
        it=V.save_pack(str(g.get("item_id","")),g.get("pack") or {});pk=it["pack"];return "saved. %s. Missing: %s. Open Menu > Vinted to review it."%("Pack looks complete" if not it["missing"] else "Pack is incomplete",", ".join(it["missing"]) or "nothing")+(" Questions for the user: "+"; ".join(pk["questions"]) if pk["questions"] else "")
    if n=="vinted_fill":return V.fill(str(g.get("item_id","")))
    if n=="vinted_inspect":return V.inspect()
    if n=="open_url":webbrowser.open(str(g.get("url","")));return "opened"
    if n=="make_pdf":
        h=safe_path(a,g.get("html_file",""))
        if not os.path.isfile(h):raise X.ToolError("html_file not found: %s. Write the page with write_file first."%g.get("html_file"))
        out=safe_path(a,g.get("file") or h.rsplit(".",1)[0]+".pdf")
        try:made,pages=M.make_pdf(h,out,g.get("size","A4"))
        except M.MediaError as e:raise X.ToolError(str(e))
        return "made %s. Pages per PDF: %s. Open the preview PNG to check the layout."%(", ".join(relw(x) for x in made),pages)
    if n=="make_video":
        sf=safe_path(a,g.get("script_file",""))
        if not os.path.isfile(sf):raise X.ToolError("script_file not found: %s. The scriptwriter must save it with write_file first."%g.get("script_file"))
        out=safe_path(a,g.get("file") or "video/out/%s.mp4"%os.path.basename(sf).rsplit(".",1)[0])
        if not out.lower().endswith(".mp4"):out+=".mp4"
        gi=lambda pr,d:X.gen_image("pollinations",None,pr,d,768,1344)
        try:m=M.make_video(sf,out,k.get("pexels",""),st.get("yt_voice",""),gi,os.path.join(W,"video","ready-for-tiktok"),log=lambda t:alog(a,"result",t))
        except M.MediaError as e:raise X.ToolError(str(e))
        return "made %s (%.0f seconds) titled '%s'. A copy and a caption are in video/ready-for-tiktok/ for posting on TikTok.%s"%(relw(out),m["seconds"],m["title"],"" if k.get("pexels") else " Tip: add a free Pexels key in API keys for real video clips instead of pictures.")
    if n=="youtube_upload":
        p=safe_path(a,g.get("file",""))
        if not os.path.isfile(p):raise X.ToolError("video not found: %s"%g.get("file"))
        lg=yt_log();rel=relw(p);today=time.strftime("%Y-%m-%d")
        old=next((x for x in lg if x["file"]==rel),None)
        if old:return "ALREADY UPLOADED on %s: %s"%(old["day"],old["url"])
        mx=int(st.get("yt_daily_max",2) or 0)
        if mx and sum(1 for x in lg if x["day"]==today)>=mx:raise X.ToolError("Today's limit of %d uploads is reached (Settings > Video Studio). A steady pace keeps the channel safe; try tomorrow."%mx)
        m=yt_meta(rel)
        try:vid,pv=M.yt_upload(k.get("youtube_id"),k.get("youtube_secret"),(S.get("yt") or {}).get("refresh"),p,m.get("title") or g.get("title",""),m.get("description") or g.get("description",""),m.get("tags") or g.get("tags",[]),st.get("yt_privacy","private"),str(g.get("ai_visuals","")).lower()=="true")
        except M.MediaError as e:raise X.ToolError(str(e))
        u="https://youtube.com/shorts/%s"%vid;lg.append({"file":rel,"id":vid,"url":u,"title":m.get("title",""),"privacy":pv,"day":today,"t":int(time.time())})
        os.makedirs(os.path.join(W,"video"),exist_ok=True);json.dump(lg,open(os.path.join(W,"video","uploads.json"),"w",encoding="utf8"),indent=1)
        return "uploaded as %s: %s"%(pv,u)
LEDGER_KINDS={"printify_create_product":("product","made a product"),"printify_publish":("published","published a product"),"make_pdf":("pdf","made a PDF"),"make_video":("video","made a video"),"youtube_upload":("upload","uploaded to YouTube"),"generate_image":("image","made an image"),"vinted_save_pack":("listing","wrote a Vinted listing"),"vinted_fill":("vinted","filled in a Vinted listing")}
def ledger_add(a,k,text):
    with L:
        l=S.setdefault("ledger",[]);l.append({"t":int(time.time()),"k":k,"who":a["name"],"room":a.get("room",""),"x":str(text)[:200]});del l[:-400]
    if k in("published","upload","pdf","video","listing","product"):notify_kind("shipped","%s %s"%(a["name"],str(text)[:60]),str(text)[:300],"package",3)
def ledger_tool(a,n,g,r):
    if n not in LEDGER_KINDS:return
    r=str(r)
    if r.startswith(("ERROR","DENIED","BLOCKED","ALREADY")):return
    k,verb=LEDGER_KINDS[n]
    what=g.get("title") or g.get("file") or g.get("html_file") or g.get("script_file") or g.get("item_id") or g.get("product_id") or ""
    if n=="youtube_upload":
        m=re.search(r"https://\S+",r);what=(m.group(0) if m else what)
    ledger_add(a,k,"%s %s"%(verb,str(what)[:90]) if what else verb)
    save()
def tool(a,n,g):
    try:
        if n not in TL:return "ERROR: unknown tool '%s'. Your tools: %s"%(n,", ".join(tools_for(a)))
        if not isinstance(g,dict):g={}
        if n not in tools_for(a) and n.startswith("vinted_"):return "DENIED: %s is only for the Vinted Station agents."%n
        if n not in tools_for(a) and n=="youtube_upload":return "DENIED: only the Video Studio publisher or the boss may upload to YouTube."
        mp,needs,_=TL[n];pm=a.get("perm",1)
        if pm<mp:return "DENIED: %s needs permission level '%s' but this agent only has '%s'. Tell the boss or the user."%(n,PERMS[mp],PERMS[pm])
        if n=="run_command" and BAD.search(str(g.get("cmd",""))):return "BLOCKED: deleting is disabled"
        if n in("read_file","list_files","write_file","generate_image","browser_screenshot","make_pdf","make_video","youtube_upload"):safe_path(a,g.get("path") or g.get("file") or ".")
        cost=cost_of(n,g)
        if cost>0:
            left=float(a["budget"].get("usd",0))-float(a.get("spent",0))
            if left+1e-9<cost:return "DENIED: this agent has $%.2f left in its budget but this costs $%.2f. Ask the user to raise the budget in the agent editor."%(max(left,0),cost)
            cap=float(S["settings"].get("day_cap_usd",0) or 0);today=spent_today()
            if cap and today+cost>cap+1e-9:return "DENIED: the whole team's daily spending limit of $%.2f is reached ($%.2f spent today). The user can change it in Settings > Safety."%(cap,today)
        if S["settings"].get("risk_guard",True) and n in("printify_create_product","printify_publish","generate_image"):
            hit=X.risk_check(" ".join(str(g.get(k,"")) for k in("title","description","prompt","tags")))
            if hit:return "BLOCKED by the brand-safety check: contains %s. Use original wording. (The user can switch this check off in Settings.)"%", ".join(hit)
        if needs and cost==0 and rule_ok(n,g):alog(a,"approval","auto-approved by your 'always allow' rule: %s"%describe(a,n,g,cost)[0])
        elif needs or cost>0:
            d,dt=describe(a,n,g,cost)
            if not ask(a,d,dt,force=cost>0,rule=rule_for(n,g) if cost==0 else None):return "DENIED by user"
        r=run_tool(a,n,g)
        try:ledger_tool(a,n,g,r)
        except Exception:pass
        if cost>0:a["spent"]=round(float(a.get("spent",0))+cost,2);warn_budget(a);day_add(a,0,0,0,cost);save();alog(a,"spend","$%.2f for %s (spent $%.2f of $%.2f)"%(cost,n,a["spent"],a["budget"]["usd"]))
        return str(r)[:6000]
    except X.ToolError as e:return "ERROR: "+str(e)
    except Exception as e:return "ERROR: %s: %s"%(type(e).__name__,e)
# ---------------------------------------------------------------- agents at work
def ctx(a=None):
    Bd=S["board"][-80:]
    if a and not a["boss"]:Bd=[m for m in Bd if m.get("room","") in("",a.get("room",""))]
    return "\n".join("[%s] %s"%(m["who"],m["text"][:600]) for m in Bd[-40:])
def room_notes(a):
    r=next((x for x in S["rooms"] if x["id"]==a.get("room")),None)
    if a.get("boss"):
        ns=["%s: %s"%(x["name"],x["notes"][:400]) for x in S["rooms"] if x.get("notes")]
        return ("\nRoom notes written by the user (follow them):\n"+"\n".join(ns)) if ns else ""
    return ("\nNotes for your room (%s), written by the user. Always follow them:\n%s"%(r["name"],r["notes"])) if r and r.get("notes") else ""
def sysmsg(a):
    rn={r["id"]:r["name"] for r in S["rooms"]}
    return room_notes(a)+"\n"+"You are %s. Role: %s\nToday is %s.\nTeam: %s\nShared team memory: %s\nYour own long-term notes (lessons you saved earlier): %s\nYour open tasks:\n%s\n%s"%(a["name"],a["role"],time.strftime("%A %d %B %Y"),", ".join("%s (%s, room: %s)"%(x["name"],x["role"][:40],rn.get(x.get("room"),"hub")) for x in S["agents"]),S["memory"][-20:],a.get("notes",[])[-20:],board_text(a["name"]),tools_prompt(a))
FLOWS=[]
def work(a,task):
    a["t0"]=int(time.time());a["step"]=0;a["tool"]=""
    try:return _work(a,task)
    finally:a["t0"]=0;a["step"]=0;a["tool"]=""
def _work(a,task):
    a["runs"]=a.get("runs",0)+1;a["task"]=str(task)[:160];alog(a,"task",task)
    m=[{"role":"system","content":sysmsg(a)+'\nReply ONLY with JSON: {"status":"<one short sentence on what you are doing>","action":"tool|done|stuck","tool":"name","args":{},"text":"result summary, or the problem if stuck"}\nNever claim you did something unless a tool result confirms it. To save a file you MUST call write_file first.'},{"role":"user","content":"Shared board:\n"+ctx(a)+"\n\nYour task: "+task}]
    for i in range(10):
        a["step"]=i+1;a["steps"]=10
        if stop[0]:stat(a,"Idle");return "STOPPED"
        try:j,o=ask_json(a,m)
        except Exception as e:a["task"]="";stat(a,"Error");alog(a,"error",e);post("System","%s: %s"%(a["name"],e),"err");return "STUCK: "+str(e)
        st=j.get("status","Working");stat(a,st)
        if j.get("action")=="tool":
            n=j.get("tool");g=j.get("args") or {};a["tool"]=str(n)[:40];alog(a,"tool","%s %s"%(n,json.dumps(g,ensure_ascii=False)[:400]));r=tool(a,n,g);alog(a,"result",str(r)[:700]);stat(a,st)
            m+=[{"role":"assistant","content":o},{"role":"user","content":"Tool result: "+str(r)}]
        else:
            k=j.get("action")=="stuck";a["done"]=a.get("done",0)+(0 if k else 1);txt=j.get("text","");alog(a,"stuck" if k else "done",txt)
            post(a["name"],txt,"stuck" if k else "msg");a["task"]="";a["last"]=str(txt)[:160];stat(a,"Stuck, asked boss" if k else "Idle");return ("STUCK: " if k else "DONE: ")+str(txt)
    post(a["name"],"Ran out of steps.");a["task"]="";stat(a,"Idle");alog(a,"error","ran out of steps");return "DONE: ran out of steps"
BOSS_RULES='\nYou are the boss. Workers run in parallel and use tools. Tasks must be self-contained; dependent work goes in a later round. Reply ONLY with JSON: {"status":"short sentence","say":"message to the user/team","create_agents":[{"name":"","role":"","emoji":"","room":""}],"assign":[{"agent":"Name","task":"..."}],"tasks":[{"title":"","owner":"Name"}],"finished":false}. Assigned work is tracked automatically on the task board; use "tasks" to add to-do items for later. Each business or project has its own room: give new agents a room name (a new room is created if the name is new). Before anything is created or published in a shop, have a reviewer or Critic agent (if the team has one) check it with risk_check and seo_check. Set finished true when the goal is done or you need the user.'
def boss(b,prompt):
    b["t0"]=int(time.time())
    try:return _boss(b,prompt)
    finally:b["t0"]=0
def _boss(b,prompt):
    s=sysmsg(b)+BOSS_RULES
    for _ in range(8):
        if stop[0]:break
        stat(b,"Planning")
        try:j,o=ask_json(b,[{"role":"system","content":s},{"role":"user","content":"Shared board:\n"+ctx()+"\n\nTask board:\n"+board_text()+"\n\n"+prompt}])
        except Exception as e:alog(b,"error",e);post("System","%s: %s"%(b["name"],e),"err");break
        if "action" in j and "assign" not in j and "say" not in j:j={"say":j.get("text",""),"finished":True}
        stat(b,j.get("status","Planning"))
        if j.get("say"):post(b["name"],j["say"])
        for n in j.get("create_agents") or []:
            if isinstance(n,dict) and n.get("name") and not find(n["name"]):
                with L:
                    r=mkroom(n["room"]) if n.get("room") else S["rooms"][0];x=ag(str(n["name"])[:20],n.get("role",""),n.get("emoji","🤖"),False,b["provider"],r["id"]);x["model"]=b["model"];S["agents"].append(x);save()
        for t in j.get("tasks") or []:
            if isinstance(t,dict) and t.get("title"):task_add(t["title"],str(t.get("owner","")))
        asg=[(find(x.get("agent")),x.get("task")) for x in j.get("assign") or [] if isinstance(x,dict)];asg=[(a,t) for a,t in asg if a and t and a is not b]
        if j.get("finished") or not asg:break
        res={};tk={a["name"]:task_add(t[:150],a["name"],status="doing") for a,t in asg}
        for a,t in asg:FLOWS.append({"to":a["id"],"t":time.time(),"task":t[:120]})
        del FLOWS[:-30]
        ts=[threading.Thread(target=lambda a=a,t=t:res.__setitem__(a["name"],work(a,t))) for a,t in asg];[t.start() for t in ts];[t.join() for t in ts]
        for nm,r in res.items():task_set(tk[nm]["id"],"done" if r.startswith("DONE") else "todo" if r.startswith("STOPPED") else "stuck",r[:200])
        prompt="Workers reported: "+json.dumps(res)+"\nReview. If anyone is STUCK, solve it and reassign. Otherwise assign more work or set finished true."
    stat(b,"Idle")
def job(fn,*a):
    def r():
        busy[0]+=1;stop[0]=False
        try:fn(*a)
        except Exception as e:post("System",e,"err")
        finally:busy[0]-=1
    threading.Thread(target=r,daemon=True).start()
def go(text,to=None):
    a=find(to) if to else None
    if a and not a["boss"]:return job(work,a,text)
    b=a or next((x for x in S["agents"] if x["boss"]),None)
    job(boss,b,"The user says: "+text) if b else post("System","No boss agent. Edit an agent and tick Boss.","err")
# ---------------------------------------------------------------- business templates
TREND_ROLE="Trend Scout for the print-on-demand shirt shop. Each day, watch free trend sources for RISING niches and slogans: trends_daily (geo GB and US), reddit_top (hobby, job and humour subreddits such as r/teachers, r/nursing, r/gardening, r/cats, r/dadjokes), keyword_ideas (what people type, e.g. 'funny nurse shirt'), etsy_search (what already sells and how crowded it is) and web_search for upcoming dates and events. Prefer evergreen niches with a fresh angle, and dates 4 to 8 weeks ahead. For each pick write a DESIGN BRIEF: niche, who buys it and why, the slogan or concept in ORIGINAL wording, visual style, colours, best product (tee, sweatshirt, hoodie, mug), 5 seed tags, and the evidence with links. Save briefs to research/briefs/YYYY-MM-DD.md with write_file, then add one task per brief owned by Pixel with task_add. Run risk_check on every slogan and skip anything with brands, characters, celebrities, sports teams, song lyrics or film quotes. Once a week run sales_report and save what worked with remember (shared=true). Never invent numbers, sources or URLs."
TEMPLATES={
"pod":{"name":"Print-on-demand store (Etsy + Printify)","desc":"Research real trends, design ORIGINAL artwork, prepare Printify products for your Etsy shop.","room":"POD Store","kind":"work","agents":[
 ("Trend Scout",TREND_ROLE,"📈",1),
 ("Pixel","Designer. Turn researched trends into ORIGINAL design ideas (no trademarks, no copying other sellers). Create artwork with generate_image into designs/.","🎨",1),
 ("Critic","Quality and safety reviewer. Before anything is listed, check every design prompt, title, tag and description with risk_check and seo_check, read the design files, and reply APPROVED or a clear list of fixes. Be strict about trademarks, copying other sellers, typos and weak titles.","🧐",1),
 ("Lister","Listing operator. Write SEO titles, 13 tags and descriptions using keyword_ideas for real phrases, and verify with seo_check. Use printify_catalog, printify_options and printify_create_product to prepare UNPUBLISHED products. Only call printify_publish when the boss says so.","📦",1)],
 "tasks":["Write 5 design briefs from rising trends","Create 3 original designs for the best ideas","Have the Critic review the designs and listing text","Prepare Printify products (unpublished) for the designs"],
 "schedules":[("Every morning: trend briefs","Trend Scout: find today's rising niches and slogans, write 3 design briefs and add a task for Pixel for each one.","08:00"),("Weekly sales review","Trend Scout: run sales_report, work out which designs get views and favourites and why, and save the lessons with remember (shared=true).","09:00")]},
"content":{"name":"Content channel (blog / YouTube)","desc":"Find topics people search for, write scripts or articles, and plan a publishing calendar.","room":"Content Studio","kind":"work","agents":[
 ("Seeker","Topic researcher. Use web_search, reddit_top and trends_daily to find topics with real demand. Save a ranked list to research/topics.md.","🧭",1),
 ("Scribe","Writer. Turn the best topics into outlines and full drafts saved in drafts/. Original wording only.","✍️",1),
 ("Planner","Editor and scheduler. Review drafts, suggest titles and thumbnails, keep a publishing calendar in calendar.md.","🗓️",1)],
 "tasks":["Rank 10 topics by demand","Draft the first article or script","Create a 4-week publishing calendar"]},
"writing":{"name":"Freelance writing agency","desc":"Find clients' needs, draft pitches and deliver written work with a review step.","room":"Writing Agency","kind":"work","agents":[
 ("Hunter","Lead finder. Use web_search to find small businesses that need content and draft short personalised pitches in leads/.","🎯",1),
 ("Writer","Writer. Produce drafts for accepted jobs in drafts/. Clear, original, well structured.","📝",1),
 ("Checker","Reviewer. Proofread drafts, check facts against sources, and report problems.","🔍",1)],
 "tasks":["Find 10 potential clients","Write 3 pitches","Draft a sample article to show clients"]},
"dropship":{"name":"Online store research","desc":"Research products and suppliers, compare prices, write product pages.","room":"Product Lab","kind":"work","agents":[
 ("Prospector","Product researcher. Use web_search, reddit_top and etsy_search to find products with demand and low competition. Record evidence in research/products.md.","🛰️",1),
 ("Analyst","Analyst. Compare costs, margins and risks for the shortlisted products in research/margins.md. Show your sums.","📊",1),
 ("Copywriter","Copywriter. Write honest, original product pages for the best products in pages/.","💬",1)],
 "tasks":["Shortlist 5 products with evidence","Calculate margins and risks","Write a product page for the best one"]},
"vinted":{"name":"Vinted station (photo to listing)","desc":"You add photos of an item you bought. The Appraiser writes the listing, the Poster fills in the Vinted form and stops so you press the button.","room":"Vinted Station","kind":"work","agents":[
 ("Appraiser","Vinted photo analyst. For a new item: call vinted_look{item_id} to read the photos, then write the listing pack and save it with vinted_save_pack. UK Vinted style: title = Brand + item + size + colour, max 100 chars (e.g. 'Ralph Lauren navy polo shirt M'). Description: 3 to 6 short lines covering what it is, size and fit, colour, fabric, condition, and EVERY flaw honestly, then hashtags. Never invent a brand, size, fabric or measurement: if the photos do not show it, leave the field empty and add a question for the user in questions[]. condition must be one of: New with tags, New without tags, Very good, Good, Satisfactory. category is a path like 'Men > Clothing > T-shirts'. colours max 2. parcel_size Small for tees and polos, Medium for jumpers and joggers. price_gbp is a sensible UK resale suggestion based on brand and condition; say in questions[] that the price is a suggestion. If the item notes include what the user paid, mention the margin in your reply. Finish by telling the user the pack is ready in Menu > Vinted.","🔎",1,"appraiser"),
 ("Poster","Vinted listing operator. When asked to fill an item, call vinted_fill{item_id}. Report what the tool says field by field and tell the user exactly which fields they need to fix. If it says NOT_LOGGED_IN, tell the user to log in to Vinted in the window that opened and ask again. You never press Publish and you never try to: the user checks the form and presses it. Do not retry more than once.","📮",1,"poster")],
 "tasks":["Add your first item in Menu > Vinted"]},
"printables":{"name": "Digital printables shop (Etsy)", "desc": "Agents design planners, checklists, wall art and templates as print-ready PDFs and write the Etsy listing. You upload them to Etsy as digital downloads.", "room": "Printables Shop", "kind": "work", "agents": [["Finder", "Printables researcher. Find printables people really buy on Etsy (planners, trackers, checklists, budget sheets, kids activity sheets, wall art, wedding and party templates). Use etsy_search, keyword_ideas, reddit_top and web_search. For each idea record: what it is, who buys it, typical price, how crowded the search is, and a fresh angle. Save ranked ideas with evidence to printables/ideas.md and add the best ones as tasks for Maker. Never invent numbers or URLs.", "🧭", 1], ["Maker", "Printables designer. For each idea make a folder printables/<short-name>/. Write a clean, original, print-friendly HTML page with write_file (design.html): one <section class=page> per printed page, CSS @page{size:A4;margin:0} and .page{width:210mm;height:297mm;padding:14mm;box-sizing:border-box;page-break-after:always}, web-safe fonts, light ink use, generous writing space. For wall art, make the picture with generate_image into the same folder and place it full-page in the HTML. Then call make_pdf{html_file, file, size:both} so buyers get A4 and US Letter, and check the preview PNG it reports. Original designs only: no brands, characters or copied layouts.", "🖨️", 1], ["Proof", "Printables checker. Read each design.html and its make_pdf result. Check spelling, page count, that nothing is cut off, that the layout is genuinely useful, and run risk_check on all the text. Reply APPROVED or a clear list of fixes for Maker.", "🧐", 1], ["Seller", "Etsy listing writer for digital downloads. For each approved printable write printables/<short-name>/listing.md with: a title up to 140 characters, exactly 13 tags of max 20 characters (find real phrases with keyword_ideas, then check with seo_check), a price suggestion with reasons, and a description that says clearly it is a DIGITAL DOWNLOAD, no physical item is sent, which files and sizes are included (A4 and US Letter PDF) and how to print. Tell the user the listing is ready to upload on Etsy.", "🏷️", 1]], "tasks": ["Find 5 printable ideas with evidence", "Make the first printable as A4 and US Letter PDFs", "Check it and write the Etsy listing"]},
"video":{"name": "Video Studio (faceless Shorts)", "desc": "Finds topics, writes scripts, makes vertical videos with an AI voice, stock clips and captions, uploads to YouTube and saves a copy for TikTok.", "room": "Video Studio", "kind": "work", "agents": [["Spark", "Video topic finder. Read video/channel.md for the channel's niche, audience and style (if it is missing, propose 3 niches to the user and stop). Find topics people care about right now with web_search, reddit_top, trends_daily and keyword_ideas. Read video/uploads.json and video/ideas.md so you never repeat a topic. Pick ONE topic with a strong hook, note 2 to 3 reliable sources, append it to video/ideas.md and hand it to Quill.", "💡", 1, "ideas"], ["Quill", "Shorts scriptwriter. Write ONE script as JSON with write_file to video/scripts/<short-name>.json in exactly this shape: {\"title\":\"under 70 characters, curiosity-driven, no clickbait lies\",\"description\":\"2 to 3 sentences plus the source links\",\"tags\":[\"5 to 10 tags\"],\"scenes\":[{\"say\":\"one or two spoken sentences\",\"search\":\"2 to 4 words for a stock clip, e.g. city street night\",\"image_prompt\":\"vertical photo description, used if no clip is found\"}]} Use 5 to 9 scenes and 90 to 160 words in total (35 to 60 seconds). Scene 1 is a hook that makes people keep watching; the last scene gives a reason to follow. Plain spoken English, your own words and opinions, and only facts from the sources. No brands, celebrity likeness, song lyrics, or medical or financial advice. Every script must differ in structure and angle from the last ones.", "✒️", 1, "script"], ["Reel", "Video producer. When a script is ready, call make_video{script_file, file:video/out/<same-short-name>.mp4} and report the length and title. If it fails, read the error; if the problem is in the script, fix it with write_file and try once more.", "🎬", 1, "producer"], ["Beacon", "YouTube publisher. When a video is made, call youtube_upload{file}. Set ai_visuals true only if the video shows realistic AI-made people or events (stock clips and an AI voice alone do not count). Report the link. If the upload fails because YouTube is not connected, tell the user to open Settings > Video Studio. Never upload the same video twice or more than the daily limit.", "📡", 1, "publisher"]], "tasks": ["Choose the channel niche and write it in video/channel.md", "Connect YouTube in Settings > Video Studio", "Make a first test video (uploads stay private until you change Settings)"], "schedules": [["Daily Short", "Video Studio: make and upload today's Short. Spark picks one fresh topic, then Quill writes the script, then Reel makes the video, then Beacon uploads it. One step per round.", "17:00"]]},
"social":{"name": "Social media studio (TikTok, Instagram, lives)", "desc": "Plans posts and live streams, writes hooks, captions and scripts, keeps a posting calendar. You post them.", "room": "Social Studio", "kind": "work", "agents": [["Pulse", "Social trend researcher. Use trends_daily, reddit_top, keyword_ideas and web_search to find formats, sounds-style trends and topics people engage with right now in the user's niche (read social/brand.md; if missing, ask the user what the account is about). Save findings with sources to social/trends.md. Never invent numbers, sources or URLs.", "📊", 1], ["Hook", "Content writer. Turn the best trends into post ideas: for each, a 1-second hook, a short script or shot list, an on-screen caption, a post caption and 3 to 5 hashtags. Original wording, no copyrighted music or lyrics. Save to social/posts/<date>.md.", "🪝", 1], ["Host", "Live stream planner. For each planned live: a title, a run-sheet (opening, segments, products or talking points, calls to action, closing), answers to likely viewer questions, and safe moderation rules. Save to social/lives/<date>.md.", "🎙️", 1], ["Calendar", "Scheduler. Keep social/calendar.md: what to post on which day and time, which platform, and status. Add a task for each post. Check what got posted and what worked when the user reports results, and save the lessons with remember.", "🗓️", 1]], "tasks": ["Write social/brand.md: what the account is about and who it is for", "Plan a week of posts", "Plan the first live stream"]},
"reviews":{"name": "Review manager (monitor and respond)", "desc": "Collects your reviews, sorts them, drafts polite replies for you to post, and reports common complaints.", "room": "Review Desk", "kind": "work", "agents": [["Watcher", "Review collector. Read reviews/sources.md for where the business is reviewed (Google, Etsy, Trustpilot, Vinted feedback). Collect new reviews using browser_open and browser_text on public pages, or from reviews/inbox.md where the user pastes them. Save each new review to reviews/log.md with date, rating, source and text. Never make up reviews. Never invent numbers, sources or URLs.", "👀", 1], ["Replier", "Reply writer. For each new review draft a short, warm, specific reply in reviews/replies.md: thank them, answer the point, and for complaints apologise, offer a fix and move the conversation to private messages. Never argue, never share private details, never offer refunds or discounts unless reviews/policy.md allows it. The user posts the replies.", "💬", 1], ["Insight", "Analyst. Each week read reviews/log.md and write reviews/report.md: average rating, trend, the top 3 praises and complaints with examples, and 3 concrete fixes. Save key lessons with remember (shared=true).", "📈", 1]], "tasks": ["List where your reviews are in reviews/sources.md", "Draft replies to the latest reviews", "Write the first weekly review report"]},
"crosslist":{"name": "Cross-listing helper (Vinted, eBay, Depop, Etsy)", "desc": "Turns one item into ready-to-paste listings for several sites and tracks where each item is listed, so you can mark it sold everywhere.", "room": "Cross-list Hub", "kind": "work", "agents": [["Adapter", "Listing adapter. For each item in crosslist/items.md (or a Vinted listing pack the user points to), write a listing for each marketplace in crosslist/<item>.md following that site's rules: eBay (80-character title, item specifics, condition notes), Depop (casual description, 5 hashtags), Etsy (only for vintage items over 20 years old or handmade; 140-character title and 13 tags checked with seo_check), Vinted (brand + item + size + colour). Same honest condition and flaws on every site.", "🔁", 1], ["Pricer", "Pricer. Use web_search to find what similar items sold for on each site and suggest a price per site that covers that site's fees and postage. Show the sums. Never invent numbers, sources or URLs.", "💷", 1], ["Tracker", "Inventory tracker. Keep crosslist/inventory.md: each item, where it is listed, price per site, status. When the user says an item sold, list every OTHER site where it must be removed straight away so it cannot be sold twice.", "📋", 1]], "tasks": ["Add your first item to crosslist/items.md", "Write listings for 2 sites", "Set up the inventory list"]},
"travel":{"name": "Travel planner", "desc": "Researches trips, builds day-by-day itineraries with costs, and prepares bookings for you to make.", "room": "Travel Desk", "kind": "work", "agents": [["Scout Air", "Trip researcher. Read travel/trip.md for dates, budget, who is going and what they like (ask the user if missing). Use web_search and http_get to compare destinations, travel options, areas to stay and things to do, with real prices and links. Save to travel/research.md. Never invent numbers, sources or URLs.", "✈️", 1], ["Planner", "Itinerary planner. Build travel/itinerary.md day by day: morning, afternoon, evening, travel times between stops, opening hours, booking-needed flags and a cost estimate per day. Keep within budget and leave rest time.", "🗺️", 1], ["Booker", "Booking preparer. Write travel/bookings.md: what to book, in which order, the exact options and links, deadlines and cancellation terms, plus a packing list and documents checklist (passport validity, visas, insurance). You never book or pay; the user does.", "🧳", 1]], "tasks": ["Write travel/trip.md: where, when, budget, who", "Research options", "Build the day-by-day plan"]},
"website":{"name": "Website builder (domain + site)", "desc": "Plans and builds a fast, simple website as files you can host for free, and walks you through getting a domain.", "room": "Web Studio", "kind": "work", "agents": [["Architect", "Site planner. Read web/brief.md (business, audience, pages wanted; ask the user if missing). Research 3 similar sites with web_search for ideas, then write web/plan.md: pages, sections, key messages, and 5 domain name ideas with where to check and buy them (about 10 GBP a year). Never invent numbers, sources or URLs.", "📐", 1], ["Builder", "Web developer. Build the site as plain HTML and CSS files in web/site/ (index.html plus the planned pages, one styles.css), mobile-friendly, fast, accessible, with real contact details from web/brief.md only. No external trackers. Use generate_image for original pictures into web/site/img/.", "🧱", 1], ["Launcher", "Launch helper. Check the pages with read_file for broken links, missing alt text and typos. Write web/launch.md: step-by-step free hosting (Netlify Drop or GitHub Pages), how to connect a bought domain, and a short SEO checklist. The user buys the domain and uploads the site.", "🚀", 1]], "tasks": ["Write web/brief.md", "Plan the site and pick a domain", "Build the first version"]},
"receptionist":{"name": "AI receptionist (planning)", "desc": "Plans a 24/7 phone receptionist: call scripts, FAQs, booking rules and the paid services it would need. Phone calls themselves need a paid service.", "room": "Front Desk", "kind": "work", "agents": [["Concierge", "Receptionist designer. Read desk/business.md (opening hours, services, prices, FAQs, booking rules; ask the user if missing). Write desk/script.md: greeting, how to answer each FAQ, how to take a booking or message, when to hand over to a human, and what never to say. Write desk/faq.md with short, accurate answers.", "☎️", 1], ["Costing", "Setup researcher. Use web_search to compare current options for an AI phone line (telephony number plus AI voice agent services), with UK monthly and per-minute prices, setup steps and privacy points. Save to desk/options.md with links. Never invent numbers, sources or URLs.", "🧾", 1]], "tasks": ["Write desk/business.md", "Write the call script and FAQs", "Compare phone services and costs"]},
"break":{"name":"Break room","desc":"A lounge with couches and a coffee machine. Idle agents like to relax here.","room":"Break Room","kind":"break","agents":[],"tasks":[]}}
def apply_template(tid):
    t=TEMPLATES[tid];nm=t["room"];n=2
    while any(r["name"].lower()==nm.lower() for r in S["rooms"]):nm="%s %d"%(t["room"],n);n+=1
    r=mkroom(nm,kind=t["kind"]);b=next((x for x in S["agents"] if x["boss"]),None)
    for tup in t["agents"]:
        an,role,emoji,perm=tup[:4];u=an;k=2
        while find(u):u="%s%d"%(an,k);k+=1
        x=ag(u,role,emoji,False,b["provider"] if b else "groq",r["id"],perm)
        if b:x["model"]=b["model"]
        if len(tup)>4:x["vinted" if tup[4] in("appraiser","poster") else "unit"]=tup[4]
        S["agents"].append(x)
    for title in t["tasks"]:task_add(title,room=r["id"])
    for nm_,tx,at in t.get("schedules",[]):S["schedules"].append({"id":"s"+uuid.uuid4().hex[:5],"name":nm_,"text":tx,"to":"","at":at,"days":[],"every_min":0,"on":False,"last":"","ran":""})
    return r
UD=os.path.join(DATA,"updates");UPD_GO=[False];UPD_LOCK=threading.Lock()
def upd_state():
    try:return json.load(open(os.path.join(UD,"state.json"),encoding="utf8"))
    except Exception:return {}
def upd_bad():
    try:return [str(x) for x in json.load(open(os.path.join(UD,"bad.json"),encoding="utf8"))]
    except Exception:return []
def startup_on():
    try:return os.name=="nt" and os.path.exists(os.path.join(os.environ.get("APPDATA",""),"Microsoft","Windows","Start Menu","Programs","Startup","StarCommand.lnk"))
    except Exception:return False
def check_update():
    u=S["settings"].get("update_url","")
    if not u:return {"error":"No update address set. Paste the address of your version.json file in Settings > Updates."}
    if not UPDR:return {"error":"updater.py is missing from the StarCommand folder."}
    try:
        d=UPDR.check(u);UPD["checked"]=time.strftime("%d %b %H:%M");UPD.pop("error",None)
        newer=UPDR.is_newer(d["version"],VER)
        if newer and str(d["version"]) in upd_bad():newer=False;UPD["skipped"]=str(d["version"])
        else:UPD.pop("skipped",None)
        keep={k:UPD[k] for k in("staged","checked","skipped") if k in UPD}
        UPD.clear();UPD.update(keep,newer=newer,version=d["version"],url=d["url"],sha256=d.get("sha256",""),notes=str(d.get("notes",""))[:300]);return dict(UPD)
    except Exception as e:
        UPD["error"]="Could not check: %s"%str(e)[:150];return {"error":UPD["error"]}
def stage_update():
    """download + verify the newer version into updates/pending"""
    with UPD_LOCK:
        if UPD.get("staged")==UPD.get("version"):return True
        try:
            UPDR.stage(dict(version=UPD["version"],url=UPD["url"],sha256=UPD.get("sha256",""),notes=UPD.get("notes","")),DATA);UPD["staged"]=UPD["version"];UPD.pop("error",None);return True
        except Exception as e:
            UPD["error"]="Update %s was not installed: %s"%(UPD.get("version"),str(e)[:160]);UPD["staged"]="";UPD["newer"]=False;alog_sys(UPD["error"]);return False
def alog_sys(t):
    try:post("System",t,"err")
    except Exception:pass
def restart_for_update():
    post("System","Installing StarCommand %s. It will be back in a few seconds."%UPD.get("version"))
    save();flush_logs(True)
    def go():
        time.sleep(1.2);os._exit(42)
    threading.Thread(target=go,daemon=True).start()
def update_loop():
    time.sleep(float(os.environ.get("STARCOMMAND_UPDATE_DELAY") or 40));last=0;idle=None
    while True:
        try:
            st=S["settings"];go=UPD_GO[0];auto=bool(st.get("auto_update",True))
            if st.get("update_url") and UPDR and (auto or go):
                if go or time.time()-last>4*3600:
                    last=time.time();check_update()
                if UPD.get("newer") and SUP and (UPD.get("staged")!=UPD.get("version")):stage_update()
                if UPD.get("newer") and SUP and UPD.get("staged")==UPD.get("version"):
                    quiet=busy[0]==0 and not pend
                    idle=(idle or time.time()) if quiet else None
                    if idle and time.time()-idle>=(5 if go else float(os.environ.get("STARCOMMAND_UPDATE_IDLE") or 60)):UPD_GO[0]=False;restart_for_update();return
            elif UPD_GO[0]:UPD_GO[0]=False
        except Exception as e:UPD["error"]="Update check failed: %s"%str(e)[:120]
        time.sleep(15)
def announce_update():
    """tell the user in the chat how the last update went (once)"""
    st=upd_state()
    if not st or st.get("seen"):return
    if st.get("status")=="trying" and st.get("version")==VER:
        post("System","StarCommand updated itself to version %s (from %s). %s Your data was kept and a backup of the old version is stored in app-backups."%(VER,st.get("prev"),st.get("notes","")))
    elif st.get("status")=="rolled_back":
        post("System","The update to version %s did not start properly, so StarCommand put version %s back automatically and will not try %s again. Reason: %s"%(st.get("version"),VER,st.get("version"),str(st.get("error",""))[:300]),"err")
    elif st.get("status")=="ok" and st.get("version")==VER:return
    else:return
    st["seen"]=True
    try:
        t=os.path.join(UD,"state.json.tmp");json.dump(st,open(t,"w",encoding="utf8"));os.replace(t,os.path.join(UD,"state.json"))
    except Exception:pass
def migrate_vinted():
    if S.get("vinted_v12"):return
    S["vinted_v12"]=True
    if not any(a.get("vinted") for a in S["agents"]):
        r=apply_template("vinted");fix_all();save()
migrate_vinted()
def migrate_v13():
    """v13: Scout becomes Trend Scout; add the Printables Shop and Video Studio rooms once"""
    if S.get("rooms_v13"):return
    S["rooms_v13"]=True
    for a in [x for x in S["agents"] if re.match(r"^Scout\d*$",x["name"]) and not x.get("boss") and not x.get("vinted")]:
        old=a["name"];nm="Trend Scout";k=2
        while find(nm):nm="Trend Scout %d"%k;k+=1
        a.update(name=nm,role=TREND_ROLE,emoji="📈")
        for t in S["tasks"]:
            if t.get("owner")==old:t["owner"]=nm
        for sc in S["schedules"]:
            if sc.get("to")==old:sc["to"]=nm
    for sc in S["schedules"]:
        if re.match(r"^Scout\d*: research today's trends",sc.get("text","")):sc["text"]="Trend Scout: find today's rising niches and slogans, write 3 design briefs and add a task for Pixel for each one.";sc["name"]="Every morning: trend briefs"
        else:sc["text"]=re.sub(r"^Scout\d*:","Trend Scout:",sc.get("text",""))
    for tid in("printables","video"):
        if not any(r["name"].lower().startswith(TEMPLATES[tid]["room"].lower()) for r in S["rooms"]):apply_template(tid)
    fix_all();save()
migrate_v13()
if not S.get("colors_v149"):
    S["colors_v149"]=True
    for _i,_r in enumerate(S["rooms"]):_r["color"]=ROOMPAL[_i%len(ROOMPAL)]
if not S.get("layout_v149"):
    S["layout_v147"]=S["layout_v148"]=S["layout_v149"]=True
    try:arrange();save()
    except Exception as e:print("arrange:",e)
FAILS={}
# ---------------------------------------------------------------- http
LAN=[False];UPD={}
STATIC={"/manifest.webmanifest":("manifest.webmanifest","application/manifest+json"),"/icon-192.png":("icon-192.png","image/png"),"/icon-512.png":("icon-512.png","image/png"),"/apple-touch-icon.png":("apple-touch-icon.png","image/png"),"/favicon.ico":("icon.ico","image/x-icon")}
def state():
    return {"agents":S["agents"],"board":S["board"][-120:],"pending":[{"id":k,"who":v["who"],"desc":v["desc"],"detail":v.get("detail",""),"rule":v.get("rule")} for k,v in list(pend.items())],"busy":busy[0]>0,"ask":S["ask"],
            "rooms":S["rooms"],"hub":S["hub"],"halls":S["halls"],"tasks":S["tasks"][-200:],"settings":S["settings"],"version":VER,"data_dir":DATA,"imported":IMPORTED,
            "keys":{k:bool(S["keys"].get(k)) for k in list(P)+SERVICES},"models":{k:v[1] for k,v in P.items()},"services":SERVICES,
            "templates":{k:{"name":v["name"],"desc":v["desc"],"agents":[x[0] for x in v["agents"]]} for k,v in TEMPLATES.items()},
            "browser":{"installed":X.BR.avail(),"error":X.BR.err,"install":X.INSTALL},"perms":PERMS,"memory":S["memory"][-60:],"rules":S["rules"],"schedules":S["schedules"],"usage_days":S["usage_days"],"sales":S["sales"][-14:],
            "lan_url":"http://%s:%d"%(lan_ip(),PORT) if S["settings"].get("lan") else "","lan_on":LAN[0],"update":dict(UPD,supervised=SUP,auto=bool(S["settings"].get("auto_update",True)),ver=VER,last=upd_state(),startup=startup_on()),"setup_missing":setup_missing(),"flows":[dict(x,t=round(x["t"],1)) for x in FLOWS[-12:]],"now":round(time.time(),1),"ledger_tail":S.get("ledger",[])[-6:],"backups":backup_list()[:20],"last_backup":(backup_list() or [{}])[0].get("t",0),"digest_last":S.get("digest_last",""),"yt":{"connected":bool((S.get("yt") or {}).get("refresh")),"channel_ready":bool(S["keys"].get("youtube_id") and S["keys"].get("youtube_secret")),"voices":M.VOICES,"redirect":M.yt_redirect(),"uploads":yt_log()[-5:]}}

# ---------------------------------------------------------------- setup checklist and home dashboard
SETUPJOB={}
NEEDS={"printify":r"printify","etsy":r"etsy_search|sales_report","pexels":r"make_video","youtube":r"youtube_upload","browser":r"browser_|vinted_fill|vinted_inspect","video":r"make_video","pdf":r"make_pdf","vision":r"vinted_look|vinted_items|vinted_save_pack"}
def need_rooms(item):
    rx=re.compile(NEEDS.get(item,"$^"),re.I);rn={r["id"]:r["name"] for r in S["rooms"]};out=[]
    for a in S["agents"]:
        if a.get("boss") and item not in("vision",):continue
        if rx.search(a.get("role","")):
            n=rn.get(a.get("room"),"")
            if n and n not in out:out.append(n)
    return out
def have_mod(m):
    try:return importlib.util.find_spec(m) is not None
    except Exception:return False
def setup_items():
    k=S["keys"];st=S["settings"];it=[]
    def add(id,group,title,status,detail,need=None,act=None,test=False,optional=False):
        rooms=need_rooms(need or id) if (need or id) in NEEDS else []
        it.append({"id":id,"group":group,"title":title,"status":status,"detail":detail,"rooms":rooms,"act":act,"test":test,"needed":bool(rooms)})
    prov=[p for p in P if k.get(p) and p!="ollama"]
    hl=[" %s had %d failed call%s recently (last: %s)."%(p,PH[p]["fail"],"" if PH[p]["fail"]==1 else "s",PH[p]["err"][:70]) for p in prov if PH.get(p,{}).get("fail")]
    add("brain","The AI brain","AI provider key","ok" if prov else "bad",("Connected: "+", ".join(prov)+"."+"".join(hl)) if prov else "No AI key yet. Without one nobody can think. A free Groq key works well (console.groq.com/keys).",act="key",test=bool(prov))
    miss=sorted({a["provider"] for a in S["agents"] if a.get("provider")!="ollama" and not k.get(a.get("provider"))})
    if prov and miss:add("agentprov","The AI brain","Every agent has a working provider","warn","These agents use a provider with no key: %s. Open the agent and pick another provider, or add that key."%", ".join(miss),act="key")
    add("printify","Shops and products","Printify key","ok" if k.get("printify") else ("off" if not need_rooms("printify") else "bad"),"Lets the shirt room create and publish products." if k.get("printify") else "Add your Printify API token to let agents create products.",act="key",test=bool(k.get("printify")))
    add("etsy","Shops and products","Etsy key (for trend research)","ok" if k.get("etsy") else "off","Optional. Shows what really sells on Etsy." if not k.get("etsy") else "Saved.",act="key",test=bool(k.get("etsy")))
    add("pexels","Video","Pexels key (free stock clips)","ok" if k.get("pexels") else "warn" if need_rooms("pexels") else "off","Videos use real stock clips." if k.get("pexels") else "Optional but recommended: without it videos use AI pictures or plain backgrounds. Free at pexels.com/api.",act="key",test=bool(k.get("pexels")))
    ytk=bool(k.get("youtube_id") and k.get("youtube_secret"));yc=bool((S.get("yt") or {}).get("refresh"))
    add("youtube","Video","YouTube connected","ok" if yc else "warn" if ytk else ("warn" if need_rooms("youtube") else "off"),"Connected. Uploads are %s."%st.get("yt_privacy","private") if yc else ("Keys saved. Press Connect YouTube in Settings." if ytk else "Not connected. Needed only if you want agents to upload videos."),act="settings",test=yc)
    ff=bool(shutil.which("ffmpeg")) or have_mod("imageio_ffmpeg")
    vm=ff and have_mod("edge_tts") and have_mod("PIL")
    add("video","Video","Video tools (ffmpeg, voice, pictures)","ok" if vm else "warn","Ready." if vm else "Not installed yet. They install themselves the first time a video is made, or press Install now (about 1 minute).",act="install" if not vm else None)
    pdf=X.BR.avail()
    add("browser","Tools on this computer","Browser tool","ok" if pdf else ("bad" if need_rooms("browser") or need_rooms("pdf") else "off"),"Installed." if pdf else "Not installed. Needed for PDFs, screenshots, web pages and Vinted. One-time download of about 150 MB.",need="browser",act="browser" if not pdf else None)
    vis=[p for p in("gemini","groq","openai","openrouter") if k.get(p)]
    if any(a.get("vinted") for a in S["agents"]):add("vision","Tools on this computer","Photo reading (Vinted)","ok" if vis else "bad","Uses your %s key to read item photos."%vis[0] if vis else "Needs a Gemini, Groq, OpenAI or OpenRouter key to look at photos.",act="key")
    u=S["settings"].get("update_url","")
    add("updates","The app itself","Automatic updates","ok" if (u and SUP and st.get("auto_update",True)) else "warn" if not u else "bad" if not SUP else "warn","Checking %s."%("every 4 hours" ) if (u and SUP and st.get("auto_update",True)) else ("No update address yet. Paste it in Settings > Updates once the GitHub steps are done." if not u else ("Start StarCommand with its desktop icon so it can restart itself." if not SUP else "Automatic updates are switched off.")),act="settings")
    add("startup","The app itself","Start with Windows","ok" if startup_on() else "off","Starts by itself when you sign in." if startup_on() else "Optional. Handy if schedules should run every day.",act="settings")
    lb=(backup_list() or [{}])[0].get("t",0)
    add("backups","The app itself","Automatic backups","ok" if lb and time.time()-lb<50*3600 else ("warn" if st.get("auto_backup",True) else "bad"),("Last backup %s. 14 daily copies are kept."%time.strftime("%d %b %H:%M",time.localtime(lb))) if lb else ("The first backup is made in a few minutes." if st.get("auto_backup",True) else "Automatic backups are switched off. Turn them on in Settings > Backups."),act="settings")
    add("alerts","The app itself","Phone alerts","ok" if st.get("ntfy_topic") else "off","Alerts go to the ntfy app, topic %s."%st.get("ntfy_topic") if st.get("ntfy_topic") else "Optional. Get a ping on your phone when something needs you or is shipped (free ntfy app).",act="settings",test=bool(st.get("ntfy_topic")))
    add("phone","The app itself","Phone access","ok" if st.get("lan") else "off","On at %s (PIN needed)."%("http://%s:%d"%(lan_ip(),PORT)) if st.get("lan") else "Optional. Lets your phone open StarCommand on your home Wi-Fi. Away from home: install the free Tailscale app on this PC and your phone, then use the PC's Tailscale address.",act="settings")
    return it
def setup_test(id):
    k=S["keys"]
    try:
        if id=="brain":
            ps=[x for x in P if k.get(x) and x!="ollama"]
            if not ps:return {"error":"No key saved yet."}
            p=ps[0];m=models(p);return {"ok":1,"info":"%s works (%d models)."%(p,len(m))}
        if id=="printify":return {"ok":1,"info":X.printify_shops(k.get("printify"))[:160]}
        if id=="etsy":X.etsy_search(k.get("etsy"),"mug",1);return {"ok":1,"info":"Etsy answered."}
        if id=="alerts":
            r=notify("StarCommand test","If you can read this on your phone, alerts work.","white_check_mark",3,sync=True)
            return {"ok":1,"info":"Sent. Check your phone."} if r is True else {"error":r}
        if id=="pexels":
            r=urllib.request.urlopen(urllib.request.Request("https://api.pexels.com/v1/search?query=city&per_page=1",headers={"Authorization":k.get("pexels",""),"User-Agent":"StarCommand"}),timeout=15);json.loads(r.read());return {"ok":1,"info":"Pexels answered."}
        if id=="youtube":
            rt=(S.get("yt") or {}).get("refresh")
            if not rt:return {"error":"Not connected yet."}
            body=urllib.parse.urlencode({"client_id":k.get("youtube_id",""),"client_secret":k.get("youtube_secret",""),"refresh_token":rt,"grant_type":"refresh_token"}).encode()
            r=urllib.request.urlopen(urllib.request.Request("https://oauth2.googleapis.com/token",data=body),timeout=15);json.loads(r.read());return {"ok":1,"info":"YouTube login is still valid."}
        return {"error":"Nothing to test here."}
    except urllib.error.HTTPError as e:return {"error":"%s %s"%(e.code,"The key was refused." if e.code in(401,403) else e.reason)}
    except Exception as e:return {"error":str(e)[:200]}
def setup_install_video():
    SETUPJOB["video"]={"running":True,"msg":"Installing video tools..."}
    def f():
        try:
            M._need("PIL","pillow","captions");M._need("edge_tts","edge-tts","the AI voice");M.ffmpeg()
            SETUPJOB["video"]={"running":False,"msg":"Video tools are ready."}
        except Exception as e:SETUPJOB["video"]={"running":False,"msg":"Failed: "+str(e)[:200]}
    threading.Thread(target=f,daemon=True).start()
_SM=[0,0]
def setup_missing():
    if time.time()-_SM[0]>8:
        _SM[0]=time.time()
        try:_SM[1]=sum(1 for x in setup_items() if x["status"]=="bad" and (x["needed"] or x["id"]=="brain"))
        except Exception:_SM[1]=0
    return _SM[1]
def next_run(sc):
    if sc.get("every_min"):return "every %d min"%sc["every_min"]
    at=sc.get("at","")
    if not at:return ""
    now=time.localtime();days=sc.get("days") or list(range(7))
    for d in range(8):
        wd=(now.tm_wday+d)%7
        if wd in days and (d>0 or time.strftime("%H:%M")<at):return ("today " if d==0 else "tomorrow " if d==1 else ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"][wd]+" ")+at
    return at
def home_data():
    mid=time.mktime(time.strptime(time.strftime("%Y-%m-%d"),"%Y-%m-%d"));ds=time.strftime("%Y-%m-%d")
    rooms=[]
    for r in S["rooms"]:
        ag=[a for a in S["agents"] if a.get("room")==r["id"] and not a.get("boss")]
        if not ag:continue
        tk=[t for t in S["tasks"] if t.get("room")==r["id"]]
        runs=sum(1 for a in ag for e in LOGS.get(a["id"],[]) if e["k"]=="task" and e["t"]>=mid)
        ev={}
        for e in S.get("ledger",[]):
            if e["room"]==r["id"] and e["t"]>=mid:ev[e["k"]]=ev.get(e["k"],0)+1
        lm=next((m for m in reversed(S["board"]) if m.get("room")==r["id"] and m["who"] not in("System","Schedule")),None)
        rooms.append({"id":r["id"],"name":r["name"],"color":r["color"],"agents":[{"name":a["name"],"emoji":a.get("emoji",""),"status":a.get("status","Idle"),"task":a.get("task","")} for a in ag],
          "working":sum(1 for a in ag if a.get("task")),"open":sum(1 for t in tk if t["status"] in("todo","doing")),"stuck":sum(1 for t in tk if t["status"]=="stuck"),"done_today":sum(1 for t in tk if t["status"]=="done" and t.get("updated",0)>=mid),
          "runs":runs,"events":ev,"last":(lm["who"]+": "+lm["text"][:160]) if lm else ""})
    needs=[]
    for a in S["agents"]:
        if str(a.get("status","")).startswith(("Stuck","Error")):needs.append({"k":"agent","id":a["id"],"room":a.get("room",""),"text":"%s is %s"%(a["name"],a["status"].lower()),"sub":(a.get("last") or "")[:140]})
    st=[x for x in setup_items() if x["status"]=="bad" and (x["needed"] or x["id"]=="brain")]
    for x in st:needs.append({"k":"setup","text":"Setup needed: "+x["title"],"sub":x["detail"][:140]})
    rn={r["id"]:r["name"] for r in S["rooms"]}
    feed=[dict(e,room_name=rn.get(e["room"],"")) for e in reversed(S.get("ledger",[])[-40:])]
    files=[f for f in list_files() if not f["path"].startswith(".") and not f["path"].endswith((".json",".tmp")) and "/screenshots/" not in f["path"]][:12]
    sch=[{"id":x["id"],"name":x["name"],"on":bool(x.get("on")),"next":next_run(x) if x.get("on") else "off","ran":x.get("ran","")} for x in S["schedules"]]
    u=S["usage_days"].get(ds,{});calls=sum(v.get("calls",0) for v in u.values());usd=round(sum(v.get("usd",0) for v in u.values()),2)
    cnt={}
    for e in S.get("ledger",[]):
        if e["t"]>=mid:cnt[e["k"]]=cnt.get(e["k"],0)+1
    tl=[]
    for a in S["agents"]:
        for e in LOGS.get(a["id"],[]):
            if e["k"]=="task" and e["t"]>=mid:tl.append({"t":e["t"],"room":"hub" if a.get("boss") else a.get("room",""),"k":"run","who":a["name"]})
    for e in S.get("ledger",[]):
        if e["t"]>=mid:tl.append({"t":e["t"],"room":e["room"],"k":e["k"],"who":e["who"],"x":e["x"][:80]})
    return {"timeline":tl[-600:],"mid":int(mid),"now":int(time.time()),"rooms":rooms,"needs":needs,"feed":feed,"files":files,"schedules":sch,"calls":calls,"usd":usd,"today":cnt,"busy":busy[0]>0}

# ---------------------------------------------------------------- v14: phone alerts, backups, digest, search, problem report
NT={"err":0}
def notify(title,msg,tags="",prio=3,sync=False):
    st=S["settings"];tp=st.get("ntfy_topic","")
    if not tp:return "No alert topic set. Choose one in Settings > Phone alerts."
    url=(st.get("ntfy_server") or "https://ntfy.sh").rstrip("/")+"/"+tp
    hd={"Title":title.encode("ascii","ignore").decode()[:120] or "StarCommand","Priority":str(prio),"User-Agent":"StarCommand"}
    if tags:hd["Tags"]=tags
    lu="http://%s:%d"%(lan_ip(),PORT) if st.get("lan") else ""
    if lu:hd["Click"]=lu
    def send():
        try:urllib.request.urlopen(urllib.request.Request(url,data=str(msg)[:3500].encode("utf8"),headers=hd,method="POST"),timeout=15);return True
        except Exception as e:return "Could not send: %s"%str(e)[:160]
    if sync:return send()
    threading.Thread(target=send,daemon=True).start();return True
def notify_kind(kind,title,msg,tags="",prio=3):
    st=S["settings"]
    if st.get("ntfy_topic") and st.get("ntfy_"+kind,True):notify(title,msg,tags,prio)
def notify_err(text):
    if time.time()-NT["err"]<600:return
    NT["err"]=time.time();notify_kind("errors","StarCommand problem",text[:400],"warning",3)
def spent_today():
    u=S["usage_days"].get(time.strftime("%Y-%m-%d"),{});return round(sum(v.get("usd",0) for v in u.values()),2)
BKD=os.path.join(DATA,"backups");os.makedirs(BKD,exist_ok=True)
BK_SKIP=("backups","app-backups","updates","browser-profile","vinted-profile","history","__pycache__")
BK_MAXFILE=25_000_000;BK_MAXTOTAL=400_000_000
def backup_list():
    out=[]
    try:
        for n in os.listdir(BKD):
            if n.endswith(".zip"):
                p=os.path.join(BKD,n);out.append({"name":n,"t":int(os.path.getmtime(p)),"size":os.path.getsize(p),"kind":"auto" if "-auto" in n else "before-restore" if "-before" in n else "manual"})
    except Exception:pass
    return sorted(out,key=lambda x:-x["t"])
def make_backup(kind="auto"):
    with L:
        save();d=json.dumps(S);lg=json.dumps(LOGS)
    n="StarCommand-backup-%s-%s.zip"%(time.strftime("%Y-%m-%d_%H%M%S"),kind);tmp=os.path.join(BKD,n+".tmp");total=0;skipped=0
    with zipfile.ZipFile(tmp,"w",zipfile.ZIP_DEFLATED) as z:
        z.writestr("data.json",d);z.writestr("logs.json",lg)
        z.writestr("backup.json",json.dumps({"version":VER,"made":time.strftime("%Y-%m-%d %H:%M"),"kind":kind}))
        for root,ds,fs in os.walk(DATA):
            rel=os.path.relpath(root,DATA).replace(os.sep,"/")
            top=rel.split("/")[0]
            if top in BK_SKIP:ds[:]=[];continue
            for fn in fs:
                if rel=="." and fn in("data.json","logs.json") or fn.endswith((".tmp",".lock")):continue
                p=os.path.join(root,fn)
                try:sz=os.path.getsize(p)
                except Exception:continue
                if sz>BK_MAXFILE or total+sz>BK_MAXTOTAL:skipped+=1;continue
                total+=sz
                try:z.write(p,(fn if rel=="." else rel+"/"+fn))
                except Exception:skipped+=1
        if skipped:z.writestr("SKIPPED.txt","%d very large files (over 25 MB each, such as videos) were not included in this backup."%skipped)
    os.replace(tmp,os.path.join(BKD,n))
    autos=[b for b in backup_list() if b["kind"]=="auto"]
    for b in autos[14:]:
        try:os.remove(os.path.join(BKD,b["name"]))
        except Exception:pass
    others=[b for b in backup_list() if b["kind"]!="auto"]
    for b in others[20:]:
        try:os.remove(os.path.join(BKD,b["name"]))
        except Exception:pass
    return n
def restore_backup(name):
    name=os.path.basename(name);p=os.path.join(BKD,name)
    if not(name.endswith(".zip") and os.path.isfile(p)):raise Exception("Backup not found.")
    if busy[0]>0:raise Exception("Your team is working. Press Stop all, wait a moment, then restore.")
    z=zipfile.ZipFile(p)
    try:nd=json.loads(z.read("data.json").decode("utf8"))
    except Exception:raise Exception("This backup is damaged (no readable data.json).")
    if not isinstance(nd,dict) or not isinstance(nd.get("agents"),list):raise Exception("This backup does not look like StarCommand data.")
    make_backup("before-restore")
    base=os.path.realpath(DATA)
    for i in z.infolist():
        n=i.filename.replace("\\","/")
        if i.is_dir() or n in("data.json","logs.json","backup.json","SKIPPED.txt") or n.startswith("/") or ".." in n.split("/"):continue
        if n.split("/")[0] in BK_SKIP:continue
        dst=os.path.realpath(os.path.join(DATA,n))
        if not dst.startswith(base+os.sep):continue
        os.makedirs(os.path.dirname(dst),exist_ok=True)
        with open(dst,"wb") as fh:fh.write(z.read(i))
    with L:
        keep_keys=dict(S.get("keys",{}))
        S.clear();S.update(nd)
        for k,v in keep_keys.items():S.setdefault("keys",{}).setdefault(k,v)
        fix_all()
        for a in S["agents"]:a["task"]="";a["status"]="Idle"
        try:
            LOGS.clear();LOGS.update(json.loads(z.read("logs.json").decode("utf8")));LD[0]=True
        except Exception:pass
        save()
    post("System","Restored the backup from %s. A copy of how things were just before is kept in Settings > Backups."%name.replace("StarCommand-backup-","").replace(".zip",""))
def digest_text():
    mid=time.mktime(time.strptime(time.strftime("%Y-%m-%d"),"%Y-%m-%d"));rn={r["id"]:r["name"] for r in S["rooms"]}
    lines=["Daily summary for %s"%time.strftime("%A %d %B")]
    led=[e for e in S.get("ledger",[]) if e["t"]>=mid]
    for r in S["rooms"]:
        ag=[a for a in S["agents"] if a.get("room")==r["id"] and not a.get("boss")]
        if not ag:continue
        runs=sum(1 for a in ag for e in LOGS.get(a["id"],[]) if e["k"]=="task" and e["t"]>=mid)
        done=sum(1 for t in S["tasks"] if t.get("room")==r["id"] and t["status"]=="done" and t.get("updated",0)>=mid)
        stuck=sum(1 for t in S["tasks"] if t.get("room")==r["id"] and t["status"]=="stuck")
        made=[e["x"] for e in led if e["room"]==r["id"]]
        if not(runs or done or made or stuck):continue
        bits=["%d run%s"%(runs,"" if runs==1 else "s")] if runs else []
        if done:bits.append("%d task%s done"%(done,"" if done==1 else "s"))
        if stuck:bits.append("%d stuck"%stuck)
        lines.append("- %s:%s"%(r["name"],(" "+", ".join(bits)+".") if bits else "")+((" "+"; ".join(m[:70] for m in made[-4:])+"."+(" (+%d more)"%(len(made)-4) if len(made)>4 else "")) if made else ""))
    if len(lines)==1:lines.append("- A quiet day: no agent ran.")
    u=S["usage_days"].get(time.strftime("%Y-%m-%d"),{});calls=sum(v.get("calls",0) for v in u.values())
    lines.append("AI calls: %d. Spent: $%.2f."%(calls,spent_today()))
    if pend:lines.append("Waiting for you: %d approval%s."%(len(pend),"" if len(pend)==1 else "s"))
    nx=[x for x in S["schedules"] if x.get("on")]
    if nx:lines.append("Scheduled next: "+", ".join("%s (%s)"%(x["name"],next_run(x)) for x in nx[:4])+".")
    return "\n".join(lines)
def maint_loop():
    """backups, the daily summary and clearing old stuck states"""
    time.sleep(90)
    while True:
        try:
            st=S["settings"]
            if st.get("auto_backup",True):
                last=next((b["t"] for b in backup_list() if b["kind"]=="auto"),0)
                if time.time()-last>20*3600 and busy[0]==0:make_backup("auto")
            da=st.get("digest_at","");ds=time.strftime("%Y-%m-%d")
            nm=time.localtime().tm_hour*60+time.localtime().tm_min;dm=int(da[:2])*60+int(da[3:]) if da else -999
            if da and 0<=nm-dm<120 and S.get("digest_last")!=ds:
                with L:S["digest_last"]=ds;t=digest_text();save()
                post("Digest",t);notify_kind("digest","StarCommand daily summary",t,"bar_chart",3)
            with L:
                for a in S["agents"]:
                    if re.match(r"^(Stuck|Error)",a.get("status","")) and time.time()-a.get("st_t",time.time())>12*3600:a["status"]="Idle"
        except Exception as e:print("maintenance:",e)
        time.sleep(60)
def search_all(q):
    q=str(q).strip().lower()[:80]
    if len(q)<2:return {"chat":[],"files":[],"tasks":[]}
    chat=[]
    try:
        for fn in sorted(os.listdir(CHD),reverse=True):
            if not fn.endswith(".jsonl"):continue
            for line in reversed(open(os.path.join(CHD,fn),encoding="utf8",errors="ignore").read().splitlines()):
                if q in line.lower():
                    try:m=json.loads(line)
                    except Exception:continue
                    if q in (m.get("text","")+" "+m.get("who","")).lower():chat.append({"who":m.get("who"),"text":m.get("text","")[:600],"day":m.get("day",""),"t":m.get("t","")})
                if len(chat)>=30:break
            if len(chat)>=30:break
    except Exception:pass
    with L:
        files=[f for f in list_files() if q in f["path"].lower()][:20]
        tasks=[{"title":t["title"],"status":t["status"],"owner":t.get("owner",""),"room":t.get("room","")} for t in S["tasks"] if q in t["title"].lower()][:15]
    return {"chat":chat,"files":files,"tasks":tasks}
def problem_report():
    import platform
    with L:
        st={k:v for k,v in S["settings"].items() if k not in("pin","ntfy_topic","update_url")}
        lines=["StarCommand problem report","Version %s, %s, Python %s, supervised=%s"%(VER,platform.platform(),platform.python_version(),SUP),
               "Keys saved: "+", ".join(k for k,v in S["keys"].items() if v),"Settings: "+json.dumps(st)[:900],
               "Browser tool installed: %s %s"%(X.BR.avail(),("error: "+str(X.BR.err)[:200]) if X.BR.err else ""),"Provider health: "+json.dumps(PH)[:600],
               "Update: "+json.dumps(dict(UPD,last=upd_state()))[:400],"","Setup checklist:"]
        lines+=["  [%s] %s: %s"%(x["status"],x["title"],x["detail"][:140]) for x in setup_items()]
        lines+=["","Recent problems in the chat:"]
        lines+=["  %s %s: %s"%(m.get("t",""),m["who"],str(m["text"])[:400]) for m in S["board"] if m.get("kind") in("err","stuck")][-25:]
        lines+=["","Recent agent errors:"]
        ev=[]
        for a in S["agents"]:
            for e in LOGS.get(a["id"],[]):
                if e["k"] in("error","stuck","fallback") or (e["k"]=="result" and str(e["x"]).startswith(("ERROR","DENIED"))):ev.append((e["t"],a["name"],e["k"],e["x"]))
        lines+=["  %s %s [%s] %s"%(time.strftime("%d %b %H:%M",time.localtime(t)),n,k,str(x)[:400]) for t,n,k,x in sorted(ev)[-30:]]
    try:
        vi=[i for i in V.list_items() if i.get("report") or i.get("status") not in("listed","archived")][:8]
        if vi:
            lines+=["","Vinted items:"]+["  %s status=%s photos=%d vision=%s report=%s"%(i["id"],i.get("status"),len(i.get("photos",[])),i.get("vision",""),str(i.get("report",""))[:300]) for i in vi]
    except Exception as e:lines.append("Vinted: could not read items (%s)"%e)
    t="\n".join(lines)
    for v in S["keys"].values():
        if v and len(str(v))>6:t=t.replace(str(v),"[key hidden]")
    return t
def vagent(kind):return next((a for a in S["agents"] if a.get("vinted")==kind),None)
def vrun(kind,item_id,text,busy_status,back,pre=None):
    a=vagent(kind)
    if not a:post("System","The Vinted Station is not set up. Open Menu > Business builder and add the Vinted station.","err");return False
    def setit(**k):
        try:
            it=V.get_item(item_id);it.update(k);V.put_item(it)
        except Exception:pass
    def f():
        setit(status=busy_status,report="")
        try:
            if pre:pre()
            r=work(a,text)
            if str(r).startswith(("STUCK","STOPPED")):setit(report="%s could not finish: %s"%(a["name"],str(r)[:500]))
        except Exception as e:
            msg=str(e)[:500];setit(report=msg);post("System","Vinted: "+msg,"err")
        finally:
            try:
                it=V.get_item(item_id)
                if it["status"]==busy_status:it["status"]=back;V.put_item(it)
            except Exception:pass
    job(f);return True
def v_analyse(item_id):
    return vrun("appraiser",item_id,"New Vinted item %s. Step 1: call vinted_look with item_id (the photos have already been read, so this is instant). Step 2: write the listing pack following your rules and call vinted_save_pack. Step 3: reply with a two-line summary and any questions for the user."%item_id,"analysing","new",pre=lambda:V.look(item_id))
class H(BaseHTTPRequestHandler):
    def log_message(s,*a):pass
    def out(s,o,c="application/json"):
        b=o if isinstance(o,bytes) else json.dumps(o).encode();s.send_response(200);s.send_header("Content-Type",c);s.send_header("Cache-Control","no-store");s.end_headers();s.wfile.write(b)
    def blob(s,b,ct,name=None):
        s.send_response(200);s.send_header("Content-Type",ct);s.send_header("Cache-Control","no-store")
        if name:s.send_header("Content-Disposition",'attachment; filename="%s"'%name)
        s.end_headers();s.wfile.write(b)
    def ranged(s,p,ct):
        """big files (videos, PDFs) with byte ranges so phones can play and save them"""
        n=os.path.getsize(p);a,b=0,n-1;m=re.match(r"bytes=(\d*)-(\d*)",s.headers.get("Range") or "")
        if m and (m.group(1) or m.group(2)):
            if m.group(1):a=int(m.group(1));b=min(int(m.group(2)),n-1) if m.group(2) else n-1
            else:a=max(0,n-int(m.group(2)))
            s.send_response(206);s.send_header("Content-Range","bytes %d-%d/%d"%(a,b,n))
        else:s.send_response(200)
        s.send_header("Content-Type",ct);s.send_header("Accept-Ranges","bytes");s.send_header("Content-Length",str(b-a+1));s.send_header("Cache-Control","no-store");s.end_headers()
        with open(p,"rb") as fh:
            fh.seek(a);left=b-a+1
            while left>0:
                c=fh.read(min(1<<16,left))
                if not c:break
                try:s.wfile.write(c)
                except Exception:return
                left-=len(c)
    def auth(s):
        ip=s.client_address[0]
        if ip in("127.0.0.1","::1","::ffff:127.0.0.1"):return True
        if not S["settings"].get("lan"):s.send_response(403);s.end_headers();return False
        pin=S["settings"].get("pin","");ck=s.headers.get("Cookie","")
        if ("sc_pin="+pin) in ck.replace(" ",""):return True
        now=time.time();f=FAILS.get(ip,[0,0])
        if f[1]>now:s.send_response(429);s.end_headers();s.wfile.write(b"Too many tries. Wait a minute.");return False
        q=s.path.split("pin=")[1][:6] if "pin=" in s.path and not s.path.startswith("/api/") else ""
        if q and q==pin:
            s.send_response(302);s.send_header("Set-Cookie","sc_pin=%s; Path=/; HttpOnly; SameSite=Strict"%pin);s.send_header("Location","/");s.end_headers();return False
        if q:
            f[0]+=1
            if f[0]>=5:f[1]=now+60;f[0]=0
            FAILS[ip]=f
        if s.path.startswith("/api/"):s.send_response(401);s.end_headers();return False
        s.send_response(200);s.send_header("Content-Type","text/html; charset=utf-8");s.end_headers()
        s.wfile.write(b"<meta name=viewport content='width=device-width,initial-scale=1'><body style='font-family:sans-serif;background:#0b1020;color:#eee;padding:24px'><h2>StarCommand</h2><p>Enter the 6-digit PIN shown in Settings on the computer.</p><form><input name=pin inputmode=numeric maxlength=6 autofocus style='font-size:28px;width:9em;padding:8px'> <button style='font-size:24px;padding:8px 16px'>Go</button></form>");return False
    def do_GET(s):
        if not s.auth():return
        if s.path.startswith("/api/files"):
            with L:s.out({"files":list_files()});return
        if s.path.startswith("/api/history"):
            from urllib.parse import unquote
            rel=unquote(s.path.split("path=")[1]) if "path=" in s.path else "";s.out({"versions":versions(rel)});return
        if s.path.startswith("/api/file?") or s.path.startswith("/api/version?"):
            from urllib.parse import unquote,parse_qs,urlparse
            q={k:v[0] for k,v in parse_qs(urlparse(s.path).query).items()}
            try:
                if "v" in q:
                    d=_hdir(q["path"]);vv=os.path.basename(q["v"])
                    p=os.path.join(d,vv) if vv.endswith("_v") else ""
                else:p=wpath(q.get("path",""))
                if not os.path.isfile(p):raise X.ToolError("no such file")
                ct=mimetypes.guess_type(q.get("path",""))[0] or "text/plain"
                if ct.startswith("video/") or ct=="application/pdf":return s.ranged(p,ct)
                data=open(p,"rb").read(3000000)
                if ct.startswith("text") or ct in("application/json",):ct="text/plain; charset=utf-8"
                s.blob(data,ct)
            except Exception as e:s.blob(str(e).encode(),"text/plain")
            return
        if s.path.startswith("/api/export"):
            buf=io.BytesIO()
            with zipfile.ZipFile(buf,"w",zipfile.ZIP_DEFLATED) as z:
                tot=0
                for root,ds,fs in os.walk(W):
                    for f in fs:
                        p=os.path.join(root,f)
                        try:
                            sz=os.path.getsize(p)
                            if tot+sz>60000000:continue
                            tot+=sz;z.write(p,"workspace/"+relw(p))
                        except Exception:pass
                with L:
                    rep=["# StarCommand report - %s\n"%time.strftime("%d %B %Y %H:%M"),"## Task board"]+["- [%s] %s (%s) %s"%(t["status"],t["title"],t["owner"] or "-",t["notes"]) for t in S["tasks"]]
                    rep+=["\n## Team memory"]+["- "+m for m in S["memory"]]+["\n## Agent notes"]
                    for a in S["agents"]:rep+=["### "+a["name"]]+["- "+n for n in a.get("notes",[])]
                    rep+=["\n## Recent chat"]+["%s %s: %s"%(m["t"],m["who"],m["text"]) for m in S["board"][-60:]]
                z.writestr("REPORT.md","\n".join(rep))
            s.blob(buf.getvalue(),"application/zip","StarCommand-export-%s.zip"%time.strftime("%Y%m%d"));return
        if s.path.startswith("/oauth/youtube") or (s.path.startswith("/?") and "state=" in s.path and ("code=" in s.path or "error=" in s.path)):
            from urllib.parse import parse_qs,urlparse
            q={k:v[0] for k,v in parse_qs(urlparse(s.path).query).items()}
            try:
                if q.get("error"):raise M.MediaError("Google said: %s. Nothing was connected."%q["error"])
                rt=M.yt_exchange(S["keys"].get("youtube_id"),S["keys"].get("youtube_secret"),q.get("code",""),q.get("state",""))
                with L:S["yt"]={"refresh":rt,"since":time.strftime("%Y-%m-%d %H:%M")};post("System","YouTube is connected. The Video Studio can now upload.");save()
                msg="YouTube is connected. You can close this tab and go back to StarCommand."
            except Exception as e:msg="Could not connect YouTube: %s"%e
            s.send_response(200);s.send_header("Content-Type","text/html; charset=utf-8");s.end_headers()
            import html as _h;s.wfile.write(("<body style='font-family:sans-serif;background:#0b1020;color:#eee;padding:30px'><h2>StarCommand</h2><p>%s</p>"%_h.escape(msg)).encode());return
        if s.path.startswith("/api/vinted/"):
            from urllib.parse import parse_qs,urlparse
            u=urlparse(s.path);q={k:v[0] for k,v in parse_qs(u.query).items()}
            try:
                if u.path.endswith("/items"):
                    prov=V._pick_provider() or ("test" if os.environ.get("STARCOMMAND_FAKE_VISION") else "")
                    s.out({"items":V.list_items(),"vision":prov,"browser":X.BR.avail(),"agents":{k:bool(vagent(k)) for k in("appraiser","poster")},"busy":busy[0]>0});return
                if u.path.endswith("/photo"):
                    nm=os.path.basename(q.get("n","01.jpg"));s.blob(open(os.path.join(V.idir(q.get("id","")),"photos",nm),"rb").read(),"image/jpeg");return
                if u.path.endswith("/shot"):
                    s.blob(open(os.path.join(V.idir(q.get("id","")),"form.png"),"rb").read(),"image/png");return
            except Exception as e:s.out({"error":str(e)[:200]});return
        if s.path.startswith("/api/search"):
            q=urllib.parse.unquote_plus(s.path.split("q=")[1]) if "q=" in s.path else ""
            s.out(search_all(q));return
        if s.path.startswith("/api/report"):
            s.out({"text":problem_report()});return
        if s.path.startswith("/api/digest"):
            with L:s.out({"text":digest_text()})
            return
        if s.path.startswith("/api/backup/download"):
            n=os.path.basename(urllib.parse.unquote(s.path.split("name=")[1])) if "name=" in s.path else ""
            p=os.path.join(BKD,n)
            if not (n.endswith(".zip") and os.path.isfile(p)):s.send_response(404);s.end_headers();return
            s.send_response(200);s.send_header("Content-Type","application/zip");s.send_header("Content-Disposition",'attachment; filename="%s"'%n);s.send_header("Content-Length",str(os.path.getsize(p)));s.end_headers()
            with open(p,"rb") as fh:shutil.copyfileobj(fh,s.wfile)
            return
        if s.path.startswith("/api/setup"):
            with L:items=setup_items()
            s.out({"items":items,"jobs":SETUPJOB,"missing":sum(1 for x in items if x["status"]=="bad" and x["needed"] or x["id"]=="brain" and x["status"]=="bad")});return
        if s.path.startswith("/api/home"):
            with L:s.out(home_data())
            return
        if s.path.startswith("/api/ping"):
            s.out({"starcommand":1,"ver":VER});return
        if s.path.startswith("/api/checkupdate"):
            s.out(check_update());return
        if s.path=="/api/state":
            with L:s.out(state())
        elif s.path.startswith("/api/models"):
            try:s.out({"models":models(s.path.split("provider=")[1])})
            except Exception as e:s.out({"error":str(e)})
        elif s.path.startswith("/api/log"):
            i=s.path.split("agent=")[1] if "agent=" in s.path else ""
            with L:s.out({"log":LOGS.get(i,[])[-200:]})
        elif s.path.startswith("/api/testservice"):
            n=s.path.split("name=")[1] if "name=" in s.path else ""
            try:
                if n=="printify":r=X.printify_shops(S["keys"].get("printify"))
                elif n=="etsy":r=X.etsy_search(S["keys"].get("etsy"),"mug",1)
                else:raise X.ToolError("unknown service")
                s.out({"ok":1,"info":r[:200]})
            except Exception as e:s.out({"error":str(e)[:300]})
        elif s.path.split("?")[0] in STATIC:
            fn,ct=STATIC[s.path.split("?")[0]]
            try:s.out(open(os.path.join(B,fn),"rb").read(),ct)
            except Exception:s.send_response(404);s.end_headers()
        elif s.path.split("?")[0]=="/gfx.js":s.out(open(os.path.join(B,"gfx.js"),"rb").read(),"application/javascript; charset=utf-8")
        else:s.out(open(os.path.join(B,"index.html"),"rb").read(),"text/html; charset=utf-8")
    def do_POST(s):
        if not s.auth():return
        d=json.loads(s.rfile.read(int(s.headers.get("Content-Length",0))) or b"{}");p=s.path[5:];RES={"ok":1}
        if p=="automodels":
            rep=[]
            for a in list(S["agents"]):
                try:ms=models(a["provider"])
                except Exception as e:rep.append("%s: could not list models (%s)"%(a["name"],str(e)[:60]));continue
                m=best(ms) if a["boss"] else cheap(ms)
                if m:a["model"]=m;rep.append("%s -> %s / %s"%(a["name"],a["provider"],m))
            with L:save()
            RES["report"]=rep;return s.out(RES)
        if p=="quit":
            if s.client_address[0] not in("127.0.0.1","::1","::ffff:127.0.0.1"):return s.out({"ok":0})
            s.out(RES);
            with L:save()
            flush_logs(True);threading.Timer(.4,lambda:os._exit(0)).start();return
        if p=="install_browser":X.install_browser();return s.out(RES)
        if p=="setup/test":return s.out(setup_test(str(d.get("id",""))))
        if p=="backup/now":
            try:n=make_backup("manual");return s.out({"ok":1,"name":n})
            except Exception as e:return s.out({"ok":0,"error":str(e)[:200]})
        if p=="backup/restore":
            try:restore_backup(str(d.get("name","")));return s.out(RES)
            except Exception as e:return s.out({"ok":0,"error":str(e)[:300]})
        if p=="backup/delete":
            n=os.path.basename(str(d.get("name","")))
            if n.endswith(".zip") and os.path.isfile(os.path.join(BKD,n)):os.remove(os.path.join(BKD,n))
            return s.out(RES)
        if p=="ntfy/test":
            r=notify("StarCommand test","If you can read this on your phone, alerts work.","white_check_mark",3,sync=True)
            return s.out({"ok":1} if r is True else {"ok":0,"error":r})
        if p=="digest/now":
            with L:t=digest_text()
            post("Digest",t);notify_kind("digest","StarCommand daily summary",t,"bar_chart",3);return s.out(RES)
        if p=="agent/clear":
            with L:
                for a in S["agents"]:
                    if (not d.get("id") or a["id"]==d.get("id")) and re.match(r"^(Stuck|Error)",a.get("status","")):a["status"]="Idle"
                save()
            return s.out(RES)
        if p=="setup/install":setup_install_video();return s.out(RES)
        if p=="update/now":
            if not S["settings"].get("update_url"):return s.out({"ok":0,"error":"Paste the update address in Settings > Updates first."})
            if not SUP:return s.out({"ok":0,"error":"Updates need StarCommand to be started with its desktop icon (or start.bat), not by running server.py directly."})
            UPD_GO[0]=True;return s.out(RES)
        if p=="startup":
            if os.name!="nt":return s.out({"ok":0,"error":"Start-with-Windows is only available on Windows."})
            subprocess.run([sys.executable,os.path.join(B,"launcher.py"),"--startup-on" if d.get("on") else "--startup-off"],timeout=60,creationflags=0x08000000)
            return s.out(dict(RES,on=startup_on()))
        if p=="youtube/connect":
            if not(S["keys"].get("youtube_id") and S["keys"].get("youtube_secret")):return s.out({"ok":0,"error":"First paste your Google OAuth client ID and secret in API keys (youtube_id and youtube_secret)."})
            return s.out({"ok":1,"url":M.yt_auth_url(S["keys"]["youtube_id"])})
        if p=="youtube/disconnect":
            with L:S.pop("yt",None);save()
            return s.out(RES)
        if p.startswith("vinted/"):
            try:
                op=p[7:]
                if op=="new":
                    it=V.new_item(d.get("files",[]),d.get("notes",""));RES["id"]=it["id"]
                    with L:post("You","New Vinted item added (%d photos). Please analyse it."%len(it["photos"]));RES["started"]=v_analyse(it["id"])
                elif op=="analyse":
                    with L:RES["started"]=v_analyse(d["id"])
                elif op=="save":
                    it=V.get_item(d["id"])
                    if "notes" in d:it["notes"]=str(d["notes"])[:600];V.put_item(it)
                    it=V.save_pack(d["id"],d.get("pack") or {},by_user=True);RES["status"]=it["status"];RES["missing"]=it["missing"]
                elif op=="fill":
                    it=V.get_item(d["id"])
                    if not (it.get("pack") or {}).get("title"):raise X.ToolError("Write or generate the listing pack first.")
                    with L:post("You","Fill in the Vinted form for item %s (do not publish)."%d["id"]);RES["started"]=vrun("poster",d["id"],"Fill the Vinted listing form for item %s: call vinted_fill with item_id '%s'. Report which fields were filled and which the user must fix. Never publish."%(d["id"],d["id"]),"filling",it["status"])
                elif op=="listed":
                    it=V.get_item(d["id"]);it["status"]="listed";V.put_item(it)
                elif op=="archive":
                    it=V.get_item(d["id"]);it["status"]="archived";V.put_item(it)
                elif op=="inspect":
                    a=vagent("poster")
                    if a:
                        with L:post("You","Save a list of the Vinted form fields (calibration).");job(work,a,"Call vinted_inspect once and tell the user where the file was saved.")
                return s.out(RES)
            except X.ToolError as e:return s.out({"ok":0,"error":str(e)})
            except Exception as e:return s.out({"ok":0,"error":"%s: %s"%(type(e).__name__,str(e)[:200])})
        with L:
            if p=="say":post("You",d["text"]);go(d["text"],d.get("to"))
            elif p=="business":post("You","Help me build this business: "+d["text"]);go("The user wants to start this business: %s\nDesign it: create the specialist agents it needs (create_agents) and give every one the same room value (the business name) so the business gets its own room, explain the plan, add starter tasks, ask any key questions, and start the first research/setup tasks."%d["text"])
            elif p=="agent":
                a=find(d["id"]) if d.get("id") else None
                if not a:a=ag("x","","🤖");S["agents"].append(a)
                for k in("name","role","emoji","provider","model","room"):
                    if d.get(k):a[k]=d[k]
                if d.get("look"):a["look"]=clean_look(d["look"])
                if "perm" in d:a["perm"]=max(0,min(2,int(d["perm"])))
                try:
                    if "budget_tokens" in d:a["budget"]["tokens"]=max(0,int(float(d["budget_tokens"] or 0)))
                    if "budget_usd" in d:a["budget"]["usd"]=max(0.0,round(float(d["budget_usd"] or 0),2))
                except Exception:pass
                if "notes" in d and isinstance(d["notes"],list):a["notes"]=[str(x)[:300] for x in d["notes"] if str(x).strip()][:40]
                a["warned"]={}
                if d.get("reset_usage"):a["usage"]={"calls":0,"in":0,"out":0};a["spent"]=0.0
                a["boss"]=bool(d.get("boss"))
                if a["boss"]:
                    for x in S["agents"]:x["boss"]=x is a
                fix_all()
            elif p=="room":
                r=next((x for x in S["rooms"] if x["id"]==d.get("id")),None)
                if not r:r=mkroom(d.get("name") or "New room",place=not("x" in d))
                if d.get("name"):
                    if str(d["name"])[:40]!=r["name"]:r.pop("spare",None)
                    r["name"]=str(d["name"])[:40]
                if d.get("color") and HEX.match(str(d["color"])):r["color"]=d["color"]
                if d.get("kind") in("work","break"):r["kind"]=d["kind"]
                if "notes" in d:r["notes"]=str(d["notes"])[:4000]
                if "x" in d:r.update(cleanrect(d,3))
                RES["id"]=r["id"]
            elif p=="layout":
                if d.get("hub"):S["hub"].update(cleanrect(d["hub"],6))
                for q in d.get("rooms",[]):
                    r=next((x for x in S["rooms"] if x["id"]==q.get("id")),None)
                    if r:
                        r.update(cleanrect(q,3))
                        if "fur" in q:
                            if q["fur"] is None:r.pop("fur",None)
                            else:r["fur"]=clean_fur(q["fur"])
                if "halls" in d:S["halls"]=[dict(cleanrect(q,1),id=str(q.get("id") or "h"+uuid.uuid4().hex[:5])[:12]) for q in d["halls"]][:200]
            elif p=="arrange":arrange()
            elif p=="roomdel":
                r=next((x for x in S["rooms"] if x["id"]==d["id"]),None)
                if r and len(S["rooms"])>1:drop_room(r);fix_all()
            elif p=="delete":S["agents"]=[x for x in S["agents"] if x["id"]!=d["id"]]
            elif p=="keys":S["keys"].update({k:str(v).strip() for k,v in d["keys"].items() if v and (k in P or k in SERVICES)});FBM.clear()
            elif p=="approve":
                q=pend.get(d["id"])
                if q:q["ok"]=bool(d["ok"]);q["always"]=bool(d.get("always"));q["ev"].set()
            elif p=="stop":
                stop[0]=True
                for q in pend.values():q["ev"].set()
            elif p=="ask":S["ask"]=bool(d["ask"])
            elif p=="clear":S["board"]=[]
            elif p=="task":
                op=d.get("op")
                if op=="add" and d.get("title"):RES["id"]=task_add(d["title"],d.get("owner",""),d.get("room",""))["id"]
                elif op=="update":task_set(d.get("id"),d.get("status"),d.get("notes"))
                elif op=="delete":S["tasks"]=[t for t in S["tasks"] if t["id"]!=d.get("id")]
                elif op=="clear_done":S["tasks"]=[t for t in S["tasks"] if t["status"]!="done"]
            elif p=="settings":
                st=S["settings"]
                if "fallback" in d:st["fallback"]=bool(d["fallback"])
                if "standup_min" in d:st["standup_min"]=max(0,min(480,int(float(d["standup_min"] or 0))))
                if d.get("image_provider") in("pollinations","openai"):st["image_provider"]=d["image_provider"]
                if "printify_shop" in d:st["printify_shop"]=re.sub(r"[^0-9]","",str(d["printify_shop"]))
                if "etsy_shop" in d:st["etsy_shop"]=re.sub(r"[^A-Za-z0-9_\-]","",str(d["etsy_shop"]))[:40]
                if "risk_guard" in d:st["risk_guard"]=bool(d["risk_guard"])
                if "daynight" in d:st["daynight"]=bool(d["daynight"])
                if "auto_update" in d:st["auto_update"]=bool(d["auto_update"])
                if d.get("yt_privacy") in("private","unlisted","public"):st["yt_privacy"]=d["yt_privacy"]
                if d.get("yt_voice") in M.VOICES:st["yt_voice"]=d["yt_voice"]
                if "yt_daily_max" in d:st["yt_daily_max"]=max(0,min(10,int(float(d["yt_daily_max"] or 0))))
                if "lan" in d:st["lan"]=bool(d["lan"])
                if "auto_layout" in d:
                    st["auto_layout"]=bool(d["auto_layout"])
                    if st["auto_layout"]:arrange()
                if "ntfy_topic" in d:st["ntfy_topic"]=re.sub(r"[^A-Za-z0-9_\-]","",str(d["ntfy_topic"]))[:64]
                if "ntfy_server" in d:
                    u=str(d["ntfy_server"]).strip().rstrip("/")[:120]
                    st["ntfy_server"]=u if u.startswith("https://") else "https://ntfy.sh"
                for k in("ntfy_approvals","ntfy_shipped","ntfy_errors","ntfy_digest","auto_backup"):
                    if k in d:st[k]=bool(d[k])
                if "digest_at" in d:st["digest_at"]=d["digest_at"] if re.match(r"^\d\d:\d\d$",str(d["digest_at"])) else ""
                if "day_cap_usd" in d:
                    try:st["day_cap_usd"]=max(0.0,min(1000.0,round(float(d["day_cap_usd"] or 0),2)))
                    except Exception:pass
                if d.get("regen_pin"):st["pin"]="%06d"%random.randint(0,999999)
                if "update_url" in d:st["update_url"]=str(d["update_url"]).strip()[:300]
                if "owner_name" in d:st["owner_name"]=re.sub(r"[<>\"]","",str(d["owner_name"]))[:30].strip()
                if "browser_visible" in d:
                    st["browser_visible"]=bool(d["browser_visible"])
                    if X.BR.visible!=st["browser_visible"]:X.BR.visible=st["browser_visible"];X.BR.reset()
            elif p=="rule":
                if d.get("op")=="delete":S["rules"]=[x for x in S["rules"] if x["id"]!=d.get("id")]
                elif d.get("op")=="clear":S["rules"]=[]
            elif p=="schedule":
                op=d.get("op");sc=next((x for x in S["schedules"] if x["id"]==d.get("id")),None)
                if op=="delete":S["schedules"]=[x for x in S["schedules"] if x["id"]!=d.get("id")]
                elif op=="run" and sc:
                    if busy[0]>0:RES={"ok":0,"error":"The team is busy right now. Try again when it is idle."}
                    else:post("Schedule","Running now: "+sc["text"][:200]);sc["ran"]=time.strftime("%d %b %H:%M");go(sc["text"],sc.get("to") or None)
                elif op in("add","update"):
                    if op=="add":sc={"id":"s"+uuid.uuid4().hex[:5],"on":False,"last":"","ran":""};S["schedules"].append(sc)
                    if sc:
                        if "name" in d:sc["name"]=str(d["name"])[:60]
                        if "text" in d:sc["text"]=str(d["text"])[:800]
                        if "to" in d:sc["to"]=str(d["to"])[:30]
                        if "on" in d:sc["on"]=bool(d["on"])
                        if "at" in d and re.match(r"^\d\d:\d\d$",str(d["at"])):sc["at"]=d["at"];sc["every_min"]=0
                        if "days" in d:sc["days"]=[int(x) for x in d["days"] if str(x) in "0123456"][:7]
                        if d.get("every_min") not in(None,""):
                            try:
                                em=int(float(d["every_min"]));sc["every_min"]=max(0,min(10080,em))
                                if sc["every_min"]:sc["at"]=""
                            except Exception:pass
                        sc.setdefault("name",sc.get("text","")[:30]);sc.setdefault("text","");sc.setdefault("to","");sc.setdefault("at","08:00");sc.setdefault("days",[]);sc.setdefault("every_min",0)
            elif p=="restore":
                try:
                    rel=str(d["path"]);fp=wpath(rel);vv=os.path.basename(str(d["v"]));src=os.path.join(_hdir(rel),vv)
                    if not (vv.endswith("_v") and os.path.isfile(src)):raise X.ToolError("version not found")
                    snap(fp);os.makedirs(os.path.dirname(fp),exist_ok=True);shutil.copy(src,fp);post("System","Restored an earlier version of "+rel)
                except Exception as e:RES={"ok":0,"error":str(e)}
            elif p=="template":
                if d.get("id") in TEMPLATES:RES["id"]=apply_template(d["id"])["id"]
            save()
        s.out(RES)
if __name__=="__main__":
    threading.Thread(target=flush_logs,daemon=True).start();threading.Thread(target=sched_loop,daemon=True).start()
    LAN[0]=bool(S["settings"].get("lan"))
    threading.Thread(target=update_loop,daemon=True).start();threading.Thread(target=maint_loop,daemon=True).start()
    for _i in range(40):                      # after an update the old copy may still be closing: wait for the port
        try:srv=ThreadingHTTPServer(("0.0.0.0" if LAN[0] else "127.0.0.1",PORT),H);break
        except OSError:
            if _i==39:raise
            time.sleep(1)
    announce_update()
    if not os.environ.get("STARCOMMAND_NOBROWSER"):threading.Timer(1,lambda:webbrowser.open("http://127.0.0.1:%d"%PORT)).start()
    print("StarCommand v%s running at http://127.0.0.1:%d  (close this window to stop)"%(VER,PORT));print("Your data is stored in: "+DATA)
    if LAN[0]:print("Phone access is ON: open http://%s:%d on your phone (same Wi-Fi) and enter PIN %s"%(lan_ip(),PORT,S["settings"]["pin"]))
    if IMPORTED:print("Imported your earlier data from: "+IMPORTED)
    srv.serve_forever()
